#!/usr/bin/env python3
"""Render one modular, offline OptionHelper HTML research report from JSON."""

from __future__ import annotations

import argparse
import base64
from copy import deepcopy
import html
import json
import math
from pathlib import Path
import re
import shutil
import subprocess
import os
import tempfile
from typing import Any, Mapping, Sequence

from .components import render_formula, render_inline_formula
from .components.math_notation import render_delimited_math
from .config import DesignerConfig, load_designer_config
from .design_system_builder import build_design_system
from .design_tokens import DESIGN_SYSTEM_ID, TOKENS


SECTION_ORDER = ("conclusion", "recommendation", "parameters", "payoff", "pricing", "backtest", "risk")
SECTION_TITLES = {
    "conclusion": "核心结论",
    "recommendation": "结构推荐",
    "parameters": "合同参数",
    "payoff": "收益结构",
    "pricing": "估值定价",
    "backtest": "历史回测",
    "risk": "风险提示",
}
PUBLIC_BRAND = "光大证券 金融创新业务总部"
STATUS_LABELS = {name: str(state["label"]) for name, state in TOKENS.states.items()}
CHART_TYPES = {"line", "bar", "heatmap"}
GREEK_ORDER = ("Delta", "Gamma", "Vega", "Theta", "Rho")
_GREEK_KEY = {name.casefold(): name for name in GREEK_ORDER}
_PUBLIC_VALUE_STATUS = {
    "not_applicable": "不适用",
    "unsupported": "不适用",
}
PARAMETER_SOURCES = {"template_default", "user_override", "user_selection", "market_fixing", "schedule_derived"}
PARAMETER_SOURCE_LABELS = {
    "template_default": "模板默认",
    "user_override": "用户覆盖",
    "user_selection": "用户选择",
    "market_fixing": "市场定盘",
    "schedule_derived": "合约日程推导",
}
ASSET_MODES = {"shared", "portable"}
_NUMBER_TEXT = re.compile(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$")
_MATH_SUBSCRIPT_TOKEN = re.compile(
    r"[A-Za-zΠπ]+_[A-Za-z0-9]+|(?<![A-Za-z0-9_])(?:K[12]|S0)(?![A-Za-z0-9_])"
)
_MATH_EXPRESSION = re.compile(r"[A-Za-zΠπ]+(?:_[A-Za-z0-9]+)?|\d+(?:\.\d+)?|<=|>=|!=|[+\-×*/=(),<>]")
_SUPERSCRIPT_DIGITS = str.maketrans("-0123456789", "⁻⁰¹²³⁴⁵⁶⁷⁸⁹")
_PUBLIC_VALUE_TEXT = {
    "cny": "人民币",
    "rmb": "人民币",
    "points": "点",
    "point": "点",
    "cny_per_spot": "人民币/标的价格点",
    "cny_per_spot_squared": "人民币/标的价格点²",
    "cny_per_1pct_volatility": "人民币/波动率变化1个百分点",
    "cny_per_1pct_vol": "人民币/波动率变化1个百分点",
    "cny_per_volatility_point": "人民币/波动率点",
    "cny_per_year": "人民币/年",
    "cny_per_calendar_day": "人民币/日",
    "cny_per_1pct_rate": "人民币/利率变化1个百分点",
    "monthly": "每月",
    "weekly": "每周",
    "daily": "每日",
    "monthly_last": "每月最后一个交易日",
    "configured_paths": "固定路径数",
}

_PUBLIC_TEXT_REPLACEMENTS = {
    "configured_paths": "固定路径数",
}
_EXCLUDED_PUBLIC_PARAMETER_KEYS = frozenset({
    "N", "notional", "G", "monitor", "constraints", "derived_terms",
    "pricing_methods", "payoff_figure_basis",
})
_PUBLIC_PARAMETER_PRESENTATION = {
    "H_KI": ("敲入障碍", "H_in"),
    "H_KO": ("敲出障碍", "H_out"),
    "Hc": ("派息障碍", "H_c"),
    "Llock": ("锁定观察期数", "n_lock"),
    "O_KI": ("敲入观察频率", "O_in"),
    "O_KO": ("敲出观察频率", "O_out"),
    "Oc": ("派息观察频率", "O_c"),
    "c": ("年化票息", "c"),
    "g": ("保证金比例", "g"),
    "p": ("期权费率", "p"),
    "eta": ("敲出固定补偿", "r_out"),
}
_RATE_PARAMETER_KEYS = frozenset({"c", "g", "p", "eta"})
_GENERIC_CHART_SOURCE_NOTES = frozenset({
    "本次估值结果，按标准化百分比敏感度表示。",
    "本次冻结估值结果。",
})


def _mathematical_minus(value: str) -> str:
    return value.replace("-", "−", 1) if value.startswith("-") else value


def _number_text(value: int | float | str) -> str:
    """Use one public number notation in every reader-facing surface."""

    numeric = float(value)
    if numeric == 0:
        return "0"
    if round(numeric, 2) == 0:
        mantissa, exponent = f"{numeric:.2e}".split("e")
        rendered_mantissa = _mathematical_minus(mantissa.rstrip("0").rstrip("."))
        return f"{rendered_mantissa}×10{str(int(exponent)).translate(_SUPERSCRIPT_DIGITS)}"
    rendered = f"{numeric:,.2f}".rstrip("0").rstrip(".")
    return "0" if rendered in {"-0", "-0.0"} else _mathematical_minus(rendered)


def text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "是" if value else "否"
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return _number_text(value)
    if isinstance(value, str):
        known = _PUBLIC_VALUE_TEXT.get(value.casefold())
        if known:
            return known
        # Frozen strings may be security identifiers, instrument codes or
        # already-public dates.  Never infer a numeric type from their shape:
        # for example, ``000300`` must not become ``300`` in a contract table.
        return value
    return str(value)


def display_text(value: Any, value_format: Any = "number") -> str:
    """Format public numeric facts while preserving identifiers and formulas.

    Values arrive as frozen facts.  The formatter only affects reader-facing
    number notation: two decimal places at most, grouped thousands and
    meaningful percent signs.  Strings are intentionally left unchanged so
    dates, codes, formulas and already public labels are never reinterpreted.
    """

    status = text(value).casefold() if isinstance(value, str) else ""
    if status in _PUBLIC_VALUE_STATUS:
        return _PUBLIC_VALUE_STATUS[status]
    if value is None:
        return ""
    if isinstance(value, bool):
        return "是" if value else "否"
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return text(value)
    numeric = float(value)
    if str(value_format or "number").casefold() == "percent":
        numeric *= 100
        suffix = "%"
    elif str(value_format or "number").casefold() == "percent_points":
        suffix = "%"
    else:
        suffix = ""
    return _number_text(numeric) + suffix


def display_basis(row: Mapping[str, Any]) -> str:
    """Return the frozen reader-facing unit and methodological note once."""

    parts: list[str] = []
    for key in ("unit", "note"):
        value = text(row.get(key))
        if value and value not in parts:
            parts.append(value)
    return "；".join(parts)


def public_specialized_rows(rows: list[Any]) -> list[dict[str, Any]]:
    """Keep only reader-facing business metrics from stale report payloads."""

    visible: list[dict[str, Any]] = []
    for raw in rows:
        row = as_dict(raw)
        label = text(row.get("label"))
        if not label or "/" in label or not re.search(r"[\u3400-\u9fff]", label):
            continue
        if re.search(r"第\d+项", label) or any(token in label.casefold() for token in ("monthly distribution", "selected path", "coupon observations")):
            continue
        visible.append(row)
    return visible


def backtest_summary_rows(module: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Keep counts and coverage alongside returns in every brief summary."""

    metric_rows = list(as_list(module.get("metrics")))
    for table in (as_dict(item) for item in as_list(module.get("detail_tables"))):
        if text(table.get("title")) == "公共回测统计":
            metric_rows.extend(as_list(table.get("rows")))
    metrics_by_label = unique_metric_rows_by_label(metric_rows, "回测摘要")
    labels = (
        "样本数", "有效收益样本数", "历史正收益样本占比",
        "正收益样本数", "持平样本数", "负收益样本数",
        "平均合同结算收益率", "最低合同结算收益率", "最大历史损失", "历史损失样本覆盖",
    )
    rows = [metrics_by_label[label] for label in labels if label in metrics_by_label]
    rows.extend(public_specialized_rows(as_list(module.get("card_metrics")))[:4])
    return [row for row in rows if text(row.get("label")) and row.get("value") is not None]


def backtest_primary_rows(module: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Select the decision-useful full-report backtest summary."""

    rows = [as_dict(item) for item in as_list(module.get("metrics"))]
    metrics_by_label = unique_metric_rows_by_label(rows, "回测核心摘要")
    labels = (
        "样本数",
        "历史正收益样本占比",
        "平均合同结算收益率",
        "中位合同结算收益率",
        "最低合同结算收益率",
        "最大历史损失",
    )
    return [metrics_by_label[label] for label in labels if label in metrics_by_label]


def unique_metric_rows_by_label(rows: list[Any], context: str) -> dict[str, dict[str, Any]]:
    """Index reader metrics without silently overwriting conflicting facts."""

    result: dict[str, dict[str, Any]] = {}
    for raw in rows:
        row = as_dict(raw)
        label = text(row.get("label"))
        if not label:
            continue
        existing = result.get(label)
        if existing is not None and (
            existing.get("value") != row.get("value")
            or text(existing.get("value_format")) != text(row.get("value_format"))
            or display_basis(existing) != display_basis(row)
        ):
            raise ValueError(f"{context}存在同名但事实冲突的指标：{label}。")
        result.setdefault(label, row)
    return result


def _axis_text(value: Any, axis_name: Any = "") -> str:
    """Format a category label without corrupting calendar or code semantics.

    Numeric price and scenario axes still use the public two-decimal notation.
    Calendar, date and code axes are identifiers, so their frozen notation is
    preserved and a year such as ``2024`` never becomes ``2,024``.
    """

    if value is None:
        return ""
    label = text(axis_name)
    if any(token in label for token in ("年", "日期", "时间", "代码", "标识")):
        return str(value)
    return display_text(value)


def _cell_text(row: dict[str, Any], key: str) -> str:
    """Format a table cell without treating dates, codes or formulas as numbers."""

    value = row.get(key)
    if key in {"date", "year", "code", "symbol", "formula"}:
        # Identifiers retain their source notation: a calendar year is
        # ``2025``, never ``2,025``; a leading-zero code must likewise stay
        # intact.  Only display metrics receive grouped numeric formatting.
        return "" if value is None else str(value)
    if key == "value" and isinstance(row.get("value_display"), str):
        return row["value_display"]
    value_format = row.get(f"{key}_format")
    if value_format is None and key == "value":
        value_format = row.get("value_format")
    rendered = display_text(value, value_format or "number")
    return rendered + text(row.get(f"{key}_suffix")) if rendered else ""


_TABLE_IDENTIFIER_KEYS = frozenset({
    "asset", "asset_id", "code", "date", "formula", "symbol", "ticker", "underlying", "year",
})
_TABLE_NUMERIC_HINTS = frozenset({
    "amount", "barrier", "coupon", "delta", "fee", "gamma", "k", "maturity", "notional", "premium",
    "price", "quantity", "rate", "rho", "strike", "theta", "value", "vega", "volatility",
})
_TABLE_NARRATIVE_HINTS = frozenset({
    "description", "note", "observation", "reason", "rule", "settlement", "source", "text", "unit",
})


def table_column_role(key: Any, label: Any = "") -> str:
    """Classify a visible column for width and line-breaking policy.

    This is presentation metadata only.  It never changes the value or the
    order supplied by Reporter.
    """

    key_text = text(key).casefold()
    label_text = text(label)
    compact = re.sub(r"[\s_-]+", "", key_text + label_text.casefold())
    if key_text in _TABLE_IDENTIFIER_KEYS or any(token in compact for token in ("标的", "代码", "日期", "symbol")):
        return "identifier"
    if key_text in _TABLE_NARRATIVE_HINTS or any(token in compact for token in ("观察", "结算", "规则", "来源", "说明", "口径")):
        return "narrative"
    if key_text in _TABLE_NUMERIC_HINTS or any(token in compact for token in (
        "价格", "费", "票息", "比例", "数量", "期限", "执行价", "波动率", "现值", "收益", "亏损",
        "delta", "gamma", "vega", "theta", "rho",
    )):
        return "numeric"
    return "default"


def _plain_table_value(row: Any, key: str) -> str:
    item = as_dict(row)
    return _cell_text(item, key) if item else text(row)


def table_density(columns: Sequence[tuple[str, str]], rows: Sequence[Any]) -> str:
    """Return a bounded, table-level density tier.

    Column count is the primary signal.  Long prose remains readable and
    wraps inside the cell; it does not cause per-cell font shrinkage.
    """

    count = len(columns)
    if count >= 10:
        return "dense"
    if count >= 7:
        return "compact"
    narrative_lengths = []
    for key, label in columns:
        if table_column_role(key, label) == "narrative":
            narrative_lengths.extend(len(_plain_table_value(row, key)) for row in rows)
    if count >= 5 and narrative_lengths and max(narrative_lengths, default=0) >= 32:
        return "compact"
    return "normal"


def table_colgroup(columns: Sequence[tuple[str, str]]) -> str:
    """Emit semantic columns without embedding widths in the payload."""

    return "<colgroup>" + "".join(
        f'<col class="table-col table-col--{table_column_role(key, label)}" data-column-key="{html.escape(key, quote=True)}">'
        for key, label in columns
    ) + "</colgroup>"


_TABLE_PANEL_TITLES = {
    "identifier": "基础信息",
    "numeric": "数值指标",
    "narrative": "规则与说明",
    "default": "补充信息",
}


def semantic_table_panels(
    columns: Sequence[tuple[str, str]],
    *,
    split_at: int = 10,
    max_columns: int = 6,
) -> list[tuple[str, list[tuple[str, str]]]]:
    """Split only genuinely wide tables into readable semantic panels.

    The first column is the row identity and is repeated in every panel.  All
    other columns appear exactly once.  Tables below ``split_at`` retain their
    original order and rely on the bounded density tier instead.
    """

    visible = list(columns)
    if len(visible) < split_at or len(visible) <= 1:
        return [("", visible)]
    shared = visible[:1]
    groups: list[tuple[str, list[tuple[str, str]]]] = []
    for column in visible[1:]:
        role = table_column_role(*column)
        if groups and groups[-1][0] == role:
            groups[-1][1].append(column)
        else:
            groups.append((role, [column]))
    capacity = max(1, max_columns - len(shared))
    panels: list[tuple[str, list[tuple[str, str]]]] = []
    for role, group in groups:
        panel_count = max(1, math.ceil(len(group) / capacity))
        chunk_size = math.ceil(len(group) / panel_count)
        for offset in range(0, len(group), chunk_size):
            suffix = "" if offset == 0 else "（续）"
            panels.append((_TABLE_PANEL_TITLES.get(role, _TABLE_PANEL_TITLES["default"]) + suffix, [*shared, *group[offset:offset + chunk_size]]))
    return panels


def _table_cell_class(key: str, label: str, value: str) -> str:
    classes = ["table-cell", f"table-cell--{table_column_role(key, label)}"]
    if len(value) >= 24:
        classes.append("table-cell--long")
    return " ".join(classes)


def esc(value: Any) -> str:
    return html.escape(text(value), quote=True)


def esc_rendered(value: Any) -> str:
    """Escape presentation text without running numeric formatting twice."""

    return html.escape("" if value is None else str(value), quote=True)


def _is_formula_expression(value: str) -> bool:
    compact = re.sub(r"\s+", "", value)
    tokens = "".join(_MATH_EXPRESSION.findall(compact))
    return bool(compact and "_" in compact and tokens.replace("×", "*") == compact.replace("×", "*"))


def rich_text(value: Any) -> str:
    """Preserve prose and render explicitly delimited mathematics offline."""
    return render_delimited_math(text(value), _rich_prose)


def _rich_prose(value: Any) -> str:
    """Escape prose while replacing compact subscript notation with MathML."""

    source = text(value)
    for internal, public in _PUBLIC_TEXT_REPLACEMENTS.items():
        source = re.sub(rf"\b{re.escape(internal)}\b", public, source)
    source = re.sub(r"(?<![A-Za-z0-9])-(?=\d)", "−", source)
    source = re.sub(
        r"(?<![\d.])([+−-]?\d+(?:\.\d+)?)%",
        lambda match: "0%" if abs(float(match.group(1).replace("−", "-"))) < 0.005 else match.group(0),
        source,
    )
    if not source:
        return ""
    if _is_formula_expression(source):
        return render_inline_formula(source)
    pieces: list[str] = []
    cursor = 0
    for match in _MATH_SUBSCRIPT_TOKEN.finditer(source):
        pieces.append(html.escape(source[cursor:match.start()], quote=True))
        token = match.group(0)
        if "_" not in token and token in {"K1", "K2", "S0"}:
            token = f"{token[0]}_{token[1:]}"
        pieces.append(render_inline_formula(token))
        cursor = match.end()
    pieces.append(html.escape(source[cursor:], quote=True))
    return "".join(pieces)


def as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def as_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def module_headline(value: Any, section: str) -> str:
    """Avoid repeating the current section heading inside its own content."""

    headline = text(value)
    return "" if headline == SECTION_TITLES[section] else headline


def parameter_key(row: dict[str, Any]) -> str:
    return text(row.get("symbol") or row.get("en") or row.get("cn")).strip()


def public_parameter_rows(rows: list[Any]) -> list[dict[str, Any]]:
    """Project contract rows to the public terms table."""

    visible: list[dict[str, Any]] = []
    for raw in rows:
        row = as_dict(raw)
        key = text(row.get("en") or row.get("symbol") or row.get("cn")).strip()
        if not row or key in _EXCLUDED_PUBLIC_PARAMETER_KEYS:
            continue
        value = row.get("value")
        if value is None or text(value).strip() == "":
            continue
        label, symbol = _PUBLIC_PARAMETER_PRESENTATION.get(
            key,
            (text(row.get("cn")), text(row.get("symbol"))),
        )
        # Keep declared units and numeric types together until cell rendering.
        declared_percent = row.get("value_format") in {"percent", "percent_points"}
        if not declared_percent:
            if key in _RATE_PARAMETER_KEYS and isinstance(value, (int, float)) and not isinstance(value, bool):
                value = f"{_number_text(float(value) * 100)}%"
            value = text(value)
        visible.append({**row, "cn": label, "symbol": symbol, "value": value})
    return visible


def validate_chart(raw_spec: Any, location: str) -> None:
    spec = as_dict(raw_spec)
    required = ("title", "x_axis_name", "y_axis_name", "source_note")
    missing = [key for key in required if not text(spec.get(key))]
    if missing:
        raise ValueError(f"{location}缺少图表口径：{', '.join(missing)}")
    chart_type = text(spec.get("type") or "line").lower()
    if chart_type not in CHART_TYPES:
        raise ValueError(f"{location}图表类型仅支持：{', '.join(sorted(CHART_TYPES))}")
    x_values = as_list(spec.get("x"))
    if chart_type == "heatmap":
        missing = [key for key in ("z_axis_name",) if not text(spec.get(key))]
        if missing:
            raise ValueError(f"{location}缺少热力图口径：{', '.join(missing)}")
        y_values = as_list(spec.get("y"))
        cells = as_list(spec.get("data"))
        if not x_values or not y_values or not cells:
            raise ValueError(f"{location}热力图必须提供横轴、纵轴和二维数据。")
        for position, raw_cell in enumerate(cells, start=1):
            if not isinstance(raw_cell, list) or len(raw_cell) != 3:
                raise ValueError(f"{location}第{position}个热力图数据点必须为[x索引,y索引,数值]。")
            x_index, y_index, _ = raw_cell
            if not isinstance(x_index, int) or not isinstance(y_index, int) or not (0 <= x_index < len(x_values)) or not (0 <= y_index < len(y_values)):
                raise ValueError(f"{location}第{position}个热力图数据点索引超出坐标范围。")
        return
    series = as_list(spec.get("series"))
    if not x_values or not series:
        raise ValueError(f"{location}必须提供横轴和序列。")
    for position, raw_series in enumerate(series, start=1):
        item = as_dict(raw_series)
        if not text(item.get("name")) or not isinstance(item.get("data"), list):
            raise ValueError(f"{location}第{position}个序列缺少名称或数据。")
        if len(item["data"]) != len(x_values):
            raise ValueError(f"{location}第{position}个序列长度与横轴不一致。")


def validate_payload(payload: dict[str, Any]) -> None:
    highlights = as_list(payload.get("contract_highlights"))
    if len(highlights) > 6:
        raise ValueError("contract_highlights最多展示6项关键条款。")
    for position, raw in enumerate(highlights, start=1):
        item = as_dict(raw)
        if not text(item.get("label")) or not text(item.get("value")):
            raise ValueError(f"contract_highlights[{position}]必须包含条款名称和取值。")
    for module_name in ("payoff", "pricing", "backtest"):
        module = as_dict(payload.get(module_name))
        status = text(module.get("status") or "pending").lower()
        if status not in STATUS_LABELS:
            raise ValueError(f"{module_name}的status不支持：{status}")

    for module_name in ("pricing", "backtest"):
        module = as_dict(payload.get(module_name))
        if text(module.get("status") or "pending").lower() in {"ready", "partial"}:
            for position, raw_chart in enumerate(as_list(module.get("charts")), start=1):
                validate_chart(raw_chart, f"{module_name}.charts[{position}]")

    parameters = as_dict(payload.get("parameters"))
    parameter_groups = {
        key: [as_dict(row) for row in as_list(parameters.get(key)) if as_dict(row)]
        for key in ("common_input", "payoff_input", "pricing_input", "backtest_input")
    }
    for group_name, rows in parameter_groups.items():
        for position, row in enumerate(rows, start=1):
            if text(row.get("source")) not in PARAMETER_SOURCES:
                raise ValueError(f"{group_name}[{position}]的source不符合约定。")
    # The public report keeps shared contract terms once and only retains
    # genuinely module-specific rows in the three module groups. Preserve the
    # subset invariant for inputs without the shared contract group.
    if not parameter_groups["common_input"]:
        payoff_keys = {parameter_key(row) for row in parameter_groups["payoff_input"] if parameter_key(row)}
        for group_name in ("pricing_input", "backtest_input"):
            group_keys = {parameter_key(row) for row in parameter_groups[group_name] if parameter_key(row)}
            if payoff_keys and group_keys and not payoff_keys.issubset(group_keys):
                missing = ", ".join(sorted(payoff_keys.difference(group_keys)))
                raise ValueError(f"PayoffInput不是{group_name}的子集，缺少：{missing}")


def status_box(module: dict[str, Any]) -> str:
    status = text(module.get("status") or "pending").lower()
    note = text(module.get("note"))
    if not note:
        return ""
    label = STATUS_LABELS.get(status, "")
    return (
        f'<div class="module-state" data-status="{esc(status)}" role="status">'
        f'<strong>{esc(label)}：</strong><span>{esc(note)}</span>'
        '</div>'
    )


def metric_strip(rows: list[Any], *, distinct_notes: bool = False, show_basis: bool = True) -> str:
    items = []
    seen_notes: set[str] = set()
    for row in rows:
        item = as_dict(row)
        label = text(item.get("label"))
        value = display_text(item.get("value"), item.get("value_format"))
        if not label or not value:
            continue
        basis = display_basis(item) if show_basis else ""
        note_html = f'<div class="metric__note">{esc(basis)}</div>' if basis and (not distinct_notes or basis not in seen_notes) else ""
        if basis:
            seen_notes.add(basis)
        items.append(
            '<div class="metric">'
            f'<div class="metric__value">{esc_rendered(value)}</div>'
            f'<div class="metric__label">{esc(label)}</div>'
            f'{note_html}'
            '</div>'
        )
    return f'<div class="metric-strip">{"".join(items)}</div>' if items else ""


def item_list(items: list[Any], class_name: str = "plain-list") -> str:
    rows = [f"<li>{rich_text(item)}</li>" for item in items if text(item)]
    return f'<ul class="{class_name}">{"".join(rows)}</ul>' if rows else ""


def parameter_table(rows: list[Any], caption: str) -> str:
    table_rows = []
    visible_rows = public_parameter_rows(rows)
    for row in visible_rows:
        item = as_dict(row)
        if not item:
            continue
        source = text(item.get("source"))
        symbol = text(item.get("symbol"))
        value = _cell_text(item, "value")
        table_rows.append(
            "<tr>"
            f"<td>{esc(item.get('cn'))}</td>"
            f"<td class=\"symbol\">{render_inline_formula(symbol) if symbol else '-'}</td>"
            f"<td>{rich_text(value)}</td>"
            f"<td>{esc(PARAMETER_SOURCE_LABELS.get(source, source))}</td>"
            "</tr>"
        )
    if not table_rows:
        return ""
    parameter_columns = [("cn", "条款"), ("symbol", "符号"), ("value", "取值"), ("source", "来源")]
    density = table_density(parameter_columns, visible_rows)
    return (
        '<div class="table-wrap table-wrap--parameters">'
        f'<table class="parameter-table table-density-{density}" data-table-density="{density}"><colgroup>'
        '<col class="parameter-table__cn table-col table-col--narrative"><col class="parameter-table__symbol table-col table-col--identifier">'
        '<col class="parameter-table__value table-col table-col--narrative"><col class="parameter-table__source table-col table-col--narrative"></colgroup>'
        + ("<caption>" + esc(caption) + "</caption>" if caption else "") +
        '<thead><tr><th scope="col">条款</th><th scope="col">符号</th>'
        '<th scope="col">取值</th><th scope="col">来源</th></tr></thead>'
        f"<tbody>{''.join(table_rows)}</tbody></table></div>"
    )


def simple_table(rows: list[Any], columns: list[tuple[str, str]], caption: str = "", table_class: str = "result-table") -> str:
    rendered = []
    for row in rows:
        item = as_dict(row)
        if item:
            cells = []
            for key, label in columns:
                value = _cell_text(item, key)
                # Calendar and identifier columns must keep their literal
                # source notation.  Passing ``2025`` through rich_text would
                # legitimately apply numeric grouping and produce ``2,025``.
                cell = esc_rendered(value) if key in {"date", "year", "code"} else rich_text(value)
                cells.append(
                    f'<td class="{_table_cell_class(key, label, value)}" data-label="{esc(label)}">{cell}</td>'
                )
            rendered.append("<tr>" + "".join(cells) + "</tr>")
    if not rendered:
        return ""
    density = table_density(columns, rows)
    head = "".join(f'<th scope="col">{render_delimited_math(title, esc_rendered)}</th>' for _, title in columns)
    caption_html = f"<caption>{esc(caption)}</caption>" if caption else ""
    return (
        '<div class="table-wrap">'
        f'<table class="{esc(table_class)} table-density-{density}" data-table-density="{density}">'
        f'{table_colgroup(columns)}{caption_html}<thead><tr>{head}</tr></thead>'
        f'<tbody>{"".join(rendered)}</tbody></table></div>'
    )


def faceted_table(rows: list[Any], columns: list[tuple[str, str]], caption: str, table_class: str) -> str:
    """Render a wide detail table as consecutive complete-width panels."""

    panels = semantic_table_panels(columns)
    rendered: list[str] = []
    for panel_title, panel_columns in panels:
        panel_caption = caption if not panel_title else f"{caption}·{panel_title}"
        rendered.append(
            f'<div class="table-panel" data-table-panel="{esc(panel_title or "single")}">'
            f'{simple_table(rows, panel_columns, panel_caption, table_class)}</div>'
        )
    return "".join(rendered)


def chart_data_table(spec: dict[str, Any], x_values: list[Any], series: list[dict[str, Any]]) -> str:
    """Provide the complete visible data table for every chart.

    Reports are a4 documents.  The tabular equivalent is therefore
    rendered in full below its chart rather than hidden behind an expander.
    """

    if text(spec.get("type")).lower() == "heatmap":
        y_values = as_list(spec.get("y"))
        cells = {
            (int(item[0]), int(item[1])): item[2]
            for item in as_list(spec.get("data"))
            if isinstance(item, list) and len(item) == 3
        }
        title = text(spec.get("title") or "图表")
        axis_label = f"{text(spec.get('y_axis_name') or '纵轴')}/{text(spec.get('x_axis_name') or '横轴')}"
        panel_size = 5
        panels: list[str] = []
        for offset in range(0, len(x_values), panel_size):
            indexes = list(range(offset, min(offset + panel_size, len(x_values))))
            columns = [
                ("axis", axis_label),
                *[(f"x_{index}", _axis_text(x_values[index], spec.get("x_axis_name"))) for index in indexes],
            ]
            table_rows = [
                {
                    "axis": _axis_text(y_value, spec.get("y_axis_name")),
                    **{
                        f"x_{x_index}": display_text(cells.get((x_index, y_index)), spec.get("value_format"))
                        for x_index in indexes
                    },
                }
                for y_index, y_value in enumerate(y_values)
            ]
            suffix = "" if len(x_values) <= panel_size else f"（第{offset // panel_size + 1}组）"
            panels.append(simple_table(table_rows, columns, f"{title}数据{suffix}", "chart-data-table"))
        return f'<div class="chart-data" data-table-facets="{len(panels)}">' + "".join(panels) + "</div>"
    title = text(spec.get("title") or "图表")
    panel_size = 5
    panels = []
    for offset in range(0, len(series), panel_size):
        chunk = series[offset:offset + panel_size]
        columns = [("axis", text(spec.get("x_axis_name") or "横轴"))]
        columns.extend((f"series_{index}", text(item.get("name"))) for index, item in enumerate(chunk))
        table_rows = []
        for index, x_value in enumerate(x_values):
            row = {"axis": _axis_text(x_value, spec.get("x_axis_name"))}
            row.update({f"series_{series_index}": display_text(item["data"][index], spec.get("value_format")) for series_index, item in enumerate(chunk)})
            table_rows.append(row)
        suffix = "" if len(series) <= panel_size else f"（第{offset // panel_size + 1}组）"
        panels.append(simple_table(table_rows, columns, f"{title}数据{suffix}", "chart-data-table"))
    return f'<div class="chart-data" data-table-facets="{len(panels)}">' + "".join(panels) + "</div>"


def add_charts(charts: list[dict[str, Any]], section: str, specs: list[Any]) -> str:
    figures = []
    for position, raw_spec in enumerate(specs, start=1):
        spec = as_dict(raw_spec)
        x_values = as_list(spec.get("x"))
        chart_type = text(spec.get("type") or "line").lower()
        series = [as_dict(item) for item in as_list(spec.get("series")) if as_dict(item).get("name")]
        heatmap = chart_type == "heatmap"
        if not x_values or (not heatmap and not series):
            continue
        chart_id = text(spec.get("id")) or f"{section}-chart-{len(charts) + position}"
        clean_id = "".join(char if char.isalnum() or char in "-_" else "-" for char in chart_id)
        existing_ids = {item["id"] for item in charts}
        if clean_id in existing_ids:
            clean_id = f"{clean_id}-{len(charts) + 1}"
        chart = {
            "id": clean_id,
            "title": text(spec.get("title")),
            "type": chart_type,
            "x": deepcopy(x_values),
            "x_axis_name": text(spec.get("x_axis_name")),
            "y_axis_name": text(spec.get("y_axis_name")),
            "value_format": text(spec.get("value_format") or "number"),
            "value_suffix": text(spec.get("value_suffix")),
            "source_note": text(spec.get("source_note")),
            "accessibility_summary": text(spec.get("accessibility_summary")),
        }
        if heatmap:
            chart.update({
                "y": deepcopy(as_list(spec.get("y"))),
                "data": [list(item) for item in as_list(spec.get("data")) if isinstance(item, list) and len(item) == 3],
                "z_axis_name": text(spec.get("z_axis_name")),
            })
        else:
            chart["series"] = [
                {
                    "name": text(item.get("name")),
                    "data": item.get("data") if isinstance(item.get("data"), list) else [],
                }
                for item in series
            ]
        charts.append(chart)
        source_note = text(spec.get("source_note"))
        if source_note in _GENERIC_CHART_SOURCE_NOTES:
            source_note = ""
        source_html = f'<p class="source-note">{esc(source_note)}</p>' if source_note else ""
        summary = text(spec.get("accessibility_summary")) or (
            f'{text(spec.get("title") or "图表")}，横轴为{text(spec.get("x_axis_name"))}，'
            f'纵轴为{text(spec.get("y_axis_name"))}'
            + (f'，数值为{text(spec.get("z_axis_name"))}。' if heatmap else "。")
        )
        summary_id = f"{clean_id}-summary"
        figures.append(
            '<figure class="chart-figure">'
            f'<figcaption>{esc(spec.get("title") or "图表")}</figcaption>'
            f'<div class="chart" id="{esc(clean_id)}" role="img" '
            f'aria-label="{esc(spec.get("title") or "图表")}" aria-describedby="{esc(summary_id)}"></div>'
            f'<p id="{esc(summary_id)}" class="chart-summary">{esc(summary)}</p>'
            f'{source_html}'
            "</figure>"
        )
    return "".join(figures)


def _presentation_chart(node: dict[str, Any]) -> str:
    """Render a safe one-off chart as static SVG plus its full data table.

    Standard report charts continue to use offline ECharts. A presentation
    patch must also work in Card, Quote and PDF, so its explicit chart nodes
    use a deterministic SVG projection driven by the same fixed token palette.
    """

    chart_type = text(node.get("chart_type") or "line").lower()
    spec = deepcopy(node)
    spec["type"] = chart_type
    spec.pop("chart_type", None)
    x_values = as_list(spec.get("x"))
    series = [as_dict(item) for item in as_list(spec.get("series")) if text(as_dict(item).get("name"))]
    title = text(spec.get("title") or "图表")
    width, height = 720.0, 260.0
    left, right, top, bottom = 52.0, 18.0, 18.0, 42.0
    plot_width, plot_height = width - left - right, height - top - bottom
    colors = TOKENS.chart_palette
    svg: list[str] = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {int(width)} {int(height)}" role="img">',
        f"<title>{esc(title)}</title>",
        f'<line x1="{left}" y1="{top + plot_height}" x2="{left + plot_width}" y2="{top + plot_height}" stroke="{TOKENS.colors["rule_strong"]}"/>',
        f'<line x1="{left}" y1="{top}" x2="{left}" y2="{top + plot_height}" stroke="{TOKENS.colors["rule_strong"]}"/>',
    ]
    if chart_type == "heatmap":
        y_values = as_list(spec.get("y"))
        points = [item for item in as_list(spec.get("data")) if isinstance(item, list) and len(item) == 3]
        numeric = [float(item[2]) for item in points if isinstance(item[2], (int, float)) and math.isfinite(float(item[2]))]
        low, high = (min(numeric), max(numeric)) if numeric else (0.0, 1.0)
        cell_width = plot_width / max(1, len(x_values))
        cell_height = plot_height / max(1, len(y_values))
        for x_index, y_index, raw_value in points:
            if not isinstance(x_index, int) or not isinstance(y_index, int) or not isinstance(raw_value, (int, float)):
                continue
            ratio = 0.5 if high == low else max(0.0, min(1.0, (float(raw_value) - low) / (high - low)))
            colour = colors[0] if ratio >= 0.5 else colors[1]
            opacity = 0.22 + ratio * 0.72
            svg.append(
                f'<rect x="{left + x_index * cell_width:.2f}" y="{top + y_index * cell_height:.2f}" '
                f'width="{cell_width:.2f}" height="{cell_height:.2f}" fill="{colour}" fill-opacity="{opacity:.3f}"/>'
            )
    else:
        numeric_values = [
            float(value)
            for item in series
            for value in as_list(item.get("data"))
            if isinstance(value, (int, float)) and math.isfinite(float(value))
        ]
        low = min([0.0, *numeric_values]) if numeric_values else 0.0
        high = max([1.0, *numeric_values]) if numeric_values else 1.0

        def point(index: int, value: float) -> tuple[float, float]:
            x = left + (plot_width * index / max(1, len(x_values) - 1))
            y = top + plot_height - ((value - low) / max(high - low, 1e-12)) * plot_height
            return x, y

        for series_index, item in enumerate(series):
            values = [float(value) if isinstance(value, (int, float)) and math.isfinite(float(value)) else 0.0 for value in as_list(item.get("data"))]
            colour = colors[series_index % len(colors)]
            if chart_type == "bar":
                group_width = plot_width / max(1, len(x_values))
                bar_width = group_width * 0.72 / max(1, len(series))
                zero_y = point(0, 0.0)[1]
                for value_index, value in enumerate(values[: len(x_values)]):
                    _, value_y = point(value_index, value)
                    x = left + value_index * group_width + group_width * 0.14 + series_index * bar_width
                    svg.append(
                        f'<rect x="{x:.2f}" y="{min(zero_y, value_y):.2f}" width="{bar_width:.2f}" '
                        f'height="{abs(zero_y - value_y):.2f}" fill="{colour}"/>'
                    )
            else:
                points = [point(index, value) for index, value in enumerate(values[: len(x_values)])]
                if points:
                    path = " ".join(("M" if index == 0 else "L") + f"{x:.2f},{y:.2f}" for index, (x, y) in enumerate(points))
                    svg.append(f'<path d="{path}" fill="none" stroke="{colour}" stroke-width="2"/>')
                    svg.extend(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="3" fill="{colour}"/>' for x, y in points)
    svg.append("</svg>")
    encoded = base64.b64encode("".join(svg).encode("utf-8")).decode("ascii")
    summary = text(spec.get("accessibility_summary"))
    summary_html = f'<p class="chart-summary">{esc(summary)}</p>' if summary else ""
    return (
        '<figure class="chart-figure presentation-chart">'
        f'<figcaption>{esc(title)}</figcaption>'
        f'<img class="presentation-chart__image" src="data:image/svg+xml;base64,{encoded}" alt="{esc(title)}">'
        f'{summary_html}</figure>'
    )


def render_presentation_content(nodes: Sequence[dict[str, Any] | Any]) -> str:
    """Render validated generic presentation nodes without visual overrides."""

    blocks: list[str] = []
    for raw_node in nodes:
        node = as_dict(raw_node)
        node_type = text(node.get("type")).lower()
        if node_type == "paragraph" and text(node.get("text")):
            blocks.append(f'<p class="presentation-paragraph">{rich_text(node.get("text"))}</p>')
        elif node_type == "heading" and text(node.get("text")):
            level = node.get("level")
            if type(level) is not int or not 3 <= level <= 6:
                raise ValueError("presentation heading.level必须为3至6的整数。")
            blocks.append(f'<h{level}>{rich_text(node.get("text"))}</h{level}>')
        elif node_type == "metrics":
            rendered = metric_strip(as_list(node.get("items")))
            if rendered:
                blocks.append(rendered)
        elif node_type == "table":
            columns = [
                (text(as_dict(item).get("key")), text(as_dict(item).get("label")))
                for item in as_list(node.get("columns"))
                if text(as_dict(item).get("key")) and text(as_dict(item).get("label"))
            ]
            rendered = simple_table(as_list(node.get("rows")), columns, text(node.get("caption")), "presentation-table")
            if rendered:
                blocks.append(rendered)
        elif node_type == "formula" and text(node.get("formula")):
            blocks.append(render_formula(text(node.get("formula"))))
        elif node_type == "chart":
            blocks.append(_presentation_chart(node))
    return "".join(blocks)


def _normalise_svg_numeric_signs(payload: bytes) -> bytes:
    """Use a mathematical minus in SVG text without touching XML attributes."""

    def replace_text_element(match: re.Match[bytes]) -> bytes:
        body = re.sub(
            rb"(^|>)([^<]*)",
            lambda segment: segment.group(1)
            + re.sub(rb"(?<![A-Za-z0-9])-(?=\d)", "−".encode("utf-8"), segment.group(2)),
            match.group(2),
        )
        return match.group(1) + body + match.group(3)

    return re.sub(
        rb"(<text\b[^>]*>)(.*?)(</text\s*>)",
        replace_text_element,
        payload,
        flags=re.IGNORECASE | re.DOTALL,
    )


def embedded_svg(svg_path: Any, input_dir: Path) -> str:
    """Embed only a Reporter-provided, report-only Payoffer figure."""

    candidate = text(svg_path)
    if not candidate:
        return ""
    path = Path(candidate)
    if path.is_absolute() or ".." in path.parts:
        return ""
    root = input_dir.resolve()
    unresolved = root / path
    if unresolved.is_symlink():
        return ""
    path = unresolved.resolve()
    if path != root and root not in path.parents:
        return ""
    if not path.is_file() or path.suffix.lower() != ".svg":
        return ""
    payload = path.read_bytes()
    if (
        b"data-report-figure-profile" not in payload
        or re.search(rb"<\s*(?:title|desc)\b", payload, re.IGNORECASE)
        or re.search(rb"optionhelper", payload, re.IGNORECASE)
    ):
        return ""
    payload = _normalise_svg_numeric_signs(payload)
    encoded = base64.b64encode(payload).decode("ascii")
    return f'<figure class="payoff-figure"><img src="data:image/svg+xml;base64,{encoded}" alt="本次参数化收益图"></figure>'


def formula_block(module: dict[str, Any]) -> str:
    """Render a supplied formula as MathML without evaluating or rewriting it."""

    formula_mathml = text(module.get("formula_mathml"))
    formula = text(module.get("formula"))
    if not formula_mathml and not formula:
        return ""
    return render_formula(formula=formula or formula_mathml, formula_mathml=formula_mathml)


def comparison_formula_grid(module: Mapping[str, Any]) -> str:
    """Render each frozen comparison formula with its candidate attribution."""

    cards: list[str] = []
    for raw in as_list(module.get("comparison_formulas")):
        item = as_dict(raw)
        label = text(item.get("label"))
        formula_mathml = text(item.get("formula_mathml"))
        formula = text(item.get("formula"))
        if not label or (not formula_mathml and not formula):
            continue
        rendered = render_formula(
            formula=formula or formula_mathml,
            formula_mathml=formula_mathml,
        )
        cards.append(
            '<div class="comparison-payoff-figure comparison-payoff-formula">'
            f'<h3>{esc(label)}</h3>{rendered}</div>'
        )
    return f'<div class="comparison-payoff-grid">{"".join(cards)}</div>' if cards else ""


def canonical_greeks(rows: list[Any]) -> list[dict[str, Any]]:
    """Render the five core sensitivities in the contract's fixed reader order."""

    source: dict[str, dict[str, Any]] = {}
    for raw in rows:
        row = as_dict(raw)
        label = _GREEK_KEY.get(text(row.get("label")).casefold())
        if label and label not in source:
            source[label] = row
    if not source:
        return []
    ordered: list[dict[str, Any]] = []
    for label in GREEK_ORDER:
        if label not in source:
            continue
        row = dict(source[label])
        row["label"] = label
        status = text(row.get("status")).casefold()
        if row.get("value") is None or not text(row.get("value")):
            public_status = _PUBLIC_VALUE_STATUS.get(status, "")
            if not public_status:
                continue
            row["value"] = public_status
        ordered.append(row)
    return ordered


def detail_tables(tables: list[Any]) -> str:
    """Render Reporter-projected detail tables without inferring any metrics."""

    blocks: list[str] = []
    for raw in tables:
        table = as_dict(raw)
        title = text(table.get("title"))
        columns: list[tuple[str, str]] = []
        column_formats: dict[str, str] = {}
        for item in as_list(table.get("columns")):
            if isinstance(item, (list, tuple)) and len(item) == 2:
                columns.append((text(item[0]), text(item[1])))
            elif isinstance(item, dict) and text(item.get("key")) and text(item.get("label")):
                columns.append((text(item["key"]), text(item["label"])))
                value_format = text(item.get("value_format") or item.get("format"))
                if value_format:
                    column_formats[text(item["key"])] = value_format
        rows = [
            {**{f"{key}_format": value_format for key, value_format in column_formats.items()}, **as_dict(raw_row)}
            for raw_row in as_list(table.get("rows"))
        ]
        if not title or not columns or not rows:
            continue
        blocks.append(faceted_table(rows, columns, title, "result-table result-table--detail"))
    return "".join(block for block in blocks if block)


def render_recommendation(data: dict[str, Any], *, section_title: str = "") -> str:
    module = as_dict(data.get("recommendation"))
    blocks = []
    headline = module_headline(module.get("headline"), "recommendation")
    structure_name = text(module.get("structure_name"))
    if headline and headline != structure_name:
        blocks.append('<div class="recommendation-head">')
        blocks.append(f'<h3>{esc(headline)}</h3>')
        blocks.append("</div>")
    underlyings = text(module.get("underlyings"))
    if structure_name or underlyings:
        identities = []
        if structure_name:
            label = "研究结构" if module.get("has_recommendation") is False else "推荐结构"
            if label == section_title:
                blocks.append(f'<p class="structure-name">{esc(structure_name)}</p>')
            else:
                identities.append(f'<div><dt>{label}</dt><dd>{esc(structure_name)}</dd></div>')
        if underlyings:
            identities.append(f'<div><dt>挂钩标的</dt><dd>{esc(underlyings)}</dd></div>')
        if identities:
            blocks.append(
                '<dl class="identity-ledger">'
                + "".join(identities)
                + "</dl>"
            )
    # This is the frozen recommendation rationale. Designer displays the
    # provided market-view reasoning without deriving or extending it.
    reason = text(module.get("reason"))
    if reason and reason not in {headline, structure_name}:
        blocks.append(f'<div class="recommendation-head"><p>{rich_text(reason)}</p></div>')
    suitable = item_list(as_list(module.get("suitable_for")))
    not_suitable = item_list(as_list(module.get("not_suitable_for")))
    tradeoffs = item_list(as_list(module.get("tradeoffs")))
    if suitable:
        blocks.append(f"<h3>适用条件</h3>{suitable}")
    if not_suitable:
        blocks.append(f"<h3>不适用情形</h3>{not_suitable}")
    if tradeoffs:
        blocks.append(f"<h3>主要权衡</h3>{tradeoffs}")
    scenarios = []
    for item in as_list(module.get("scenarios")):
        row = as_dict(item)
        title = text(row.get("title"))
        rule = text(row.get("rule"))
        if title or rule:
            scenarios.append(f'<div class="scenario"><h4>{esc(title)}</h4><p>{rich_text(rule)}</p></div>')
    if scenarios:
        blocks.append('<div class="scenario-grid">' + "".join(scenarios) + "</div>")
    alternatives = []
    for item in as_list(module.get("alternatives")):
        row = as_dict(item)
        title = text(row.get("title"))
        summary = text(row.get("summary"))
        tags = [f'<span>{esc(tag)}</span>' for tag in as_list(row.get("tags")) if text(tag)]
        if title or summary or tags:
            card = '<article class="alternative">' + f'<h3>{esc(title) if title else "备选结构"}</h3>'
            if summary:
                card += f'<p>{rich_text(summary)}</p>'
            if tags:
                card += '<div class="alternative__tags">' + "".join(tags) + "</div>"
            alternatives.append(card + "</article>")
    if alternatives:
        blocks.append('<div class="alternative-grid">' + "".join(alternatives) + "</div>")
    comparison_candidates = []
    for raw in as_list(module.get("comparison_candidates")):
        item = as_dict(raw)
        label = text(item.get("label"))
        title = text(item.get("title"))
        if not label or not title:
            continue
        parts = [
            '<article class="alternative comparison-candidate-detail">',
            f'<h3>{esc(label)}：{esc(title)}{" · 首选方案" if item.get("is_primary") else ""}</h3>',
        ]
        underlyings = text(item.get("underlyings"))
        if underlyings:
            parts.append(f'<p>挂钩标的：{esc(underlyings)}</p>')
        reason_points = [value for value in as_list(item.get("reason_points")) if text(value)]
        if text(item.get("reason")) and item.get("reason") not in reason_points:
            reason_points.insert(0, item.get("reason"))
        for heading, values in (
            ("推荐理由", reason_points),
            ("适用条件", as_list(item.get("suitable_for"))),
            ("不适用情形", as_list(item.get("not_suitable_for"))),
            ("主要权衡", as_list(item.get("tradeoffs"))),
        ):
            rendered = item_list(values)
            if rendered:
                parts.append(f'<h4>{heading}</h4>{rendered}')
        for section in as_list(item.get("supplemental_sections")):
            supplemental = as_dict(section)
            rendered = render_presentation_content(as_list(supplemental.get("content")))
            if rendered:
                parts.append(f'<h4>{esc(label)}：{esc(supplemental.get("title"))}</h4>{rendered}')
        parts.append("</article>")
        comparison_candidates.append("".join(parts))
    if comparison_candidates:
        blocks.append('<div class="alternative-grid comparison-candidate-details">' + "".join(comparison_candidates) + "</div>")
    return "".join(block for block in blocks if block)


def render_payoff(data: dict[str, Any], input_dir: Path) -> str:
    module = as_dict(data.get("payoff"))
    status = text(module.get("status") or "pending").lower()
    comparison_view = bool(module.get("comparison_view"))
    if status not in {"ready", "partial"} and not comparison_view:
        return status_box(module)
    figures = []
    if text(module.get("report_svg_path")):
        figures.append({"label": "", "path": module.get("report_svg_path")})
    figures.extend(as_dict(item) for item in as_list(module.get("report_svg_paths")))
    rendered_figures = []
    for figure in figures:
        image = embedded_svg(figure.get("path"), input_dir)
        if not image:
            continue
        label = text(figure.get("label"))
        rendered_figures.append(
            f'<div class="comparison-payoff-figure">{f"<h3>{esc(label)}</h3>" if label else ""}{image}</div>'
        )
    blocks = [status_box(module) if status != "ready" else ""]
    blocks.append(f'<div class="comparison-payoff-grid">{"".join(rendered_figures)}</div>' if rendered_figures else "")
    formula_html = formula_block(module)
    if formula_html:
        blocks.append(formula_html)
    formulas_html = comparison_formula_grid(module)
    if formulas_html:
        blocks.append(formulas_html)
    scenarios = []
    for item in as_list(module.get("scenarios")):
        row = as_dict(item)
        if text(row.get("title")) or text(row.get("rule")):
            scenarios.append(f'<div class="scenario"><h3>{esc(row.get("title"))}</h3><p>{rich_text(row.get("rule"))}</p></div>')
    if scenarios:
        blocks.append('<div class="scenario-grid">' + "".join(scenarios) + "</div>")
    blocks.append(detail_tables(as_list(module.get("detail_tables"))))
    return "".join(block for block in blocks if block)


def render_pricing(data: dict[str, Any], charts: list[dict[str, Any]]) -> str:
    module = as_dict(data.get("pricing"))
    status = text(module.get("status") or "pending").lower()
    comparison_view = bool(module.get("comparison_view"))
    if status not in {"ready", "partial"} and not comparison_view:
        return status_box(module)
    blocks = [status_box(module) if status != "ready" else ""]
    method = text(module.get("method"))
    valuation_date = text(module.get("valuation_date"))
    if method or valuation_date:
        ledger = []
        if method:
            ledger.append(f'<div><dt>估值方法</dt><dd>{esc(method)}</dd></div>')
        if valuation_date:
            ledger.append(f'<div><dt>估值日</dt><dd>{esc(valuation_date)}</dd></div>')
        blocks.append('<dl class="identity-ledger">' + "".join(ledger) + "</dl>")
    blocks.append(metric_strip(as_list(module.get("metrics")), show_basis=False))
    pricing_parameters = as_list(as_dict(data.get("parameters")).get("pricing_input"))
    if pricing_parameters:
        pricing_parameter_table = parameter_table(pricing_parameters, "估值参数")
        if pricing_parameter_table:
            blocks.append("<h3>估值参数</h3>")
            blocks.append(pricing_parameter_table)
    greek_rows = canonical_greeks(as_list(module.get("greeks")))
    blocks.append(
        simple_table(
            greek_rows,
            [("label", "Greek"), ("value", "数值")],
            "Greeks",
            "result-table result-table--greeks",
        )
    )
    scenario_rows = as_list(module.get("scenario_rows"))
    if scenario_rows:
        blocks.append(
            simple_table(
                scenario_rows,
                [("scenario", "情景"), ("spot", "标的价格"), ("time", "剩余期限"), ("pv", "现值")],
                "定价情景",
                "result-table result-table--scenarios",
            )
        )
    blocks.append(add_charts(charts, "pricing", as_list(module.get("charts"))))
    blocks.append(detail_tables(as_list(module.get("detail_tables"))))
    assumptions = item_list(as_list(module.get("assumptions")))
    if assumptions:
        blocks.append(f"<h3>估值假设</h3>{assumptions}")
    return "".join(block for block in blocks if block)


def render_backtest(data: dict[str, Any], charts: list[dict[str, Any]]) -> str:
    module = as_dict(data.get("backtest"))
    status = text(module.get("status") or "pending").lower()
    comparison_view = bool(module.get("comparison_view"))
    if status not in {"ready", "partial"} and not comparison_view:
        return status_box(module)
    blocks = [status_box(module) if status != "ready" else ""]
    window = text(module.get("window"))
    entry_rule = text(module.get("entry_rule"))
    if window or entry_rule:
        ledger = []
        if window:
            ledger.append(f'<div><dt>样本区间</dt><dd>{esc(window)}</dd></div>')
        if entry_rule:
            ledger.append(f'<div><dt>入场规则</dt><dd>{esc(entry_rule)}</dd></div>')
        blocks.append('<dl class="identity-ledger">' + "".join(ledger) + "</dl>")
    blocks.append(metric_strip(backtest_primary_rows(module), show_basis=False))
    backtest_parameters = as_list(as_dict(data.get("parameters")).get("backtest_input"))
    if backtest_parameters:
        backtest_parameter_table = parameter_table(backtest_parameters, "回测参数")
        if backtest_parameter_table:
            blocks.append("<h3>回测参数</h3>")
            blocks.append(backtest_parameter_table)
    card_metrics = public_specialized_rows(as_list(module.get("card_metrics")))
    if card_metrics:
        blocks.append("<h3>结构统计</h3>")
        blocks.append(
            simple_table(
                card_metrics,
                [("label", "指标"), ("value", "统计值")],
                "结构统计",
                "result-table result-table--specialized",
            )
        )
    blocks.append(add_charts(charts, "backtest", as_list(module.get("charts"))))
    event_statistics = public_specialized_rows(as_list(module.get("event_statistics")))
    blocks.append(
        simple_table(
            event_statistics,
            [("label", "路径事件"), ("value", "统计值")],
            "路径事件统计",
            "result-table result-table--events",
        )
    )
    # KPI and specialized rows are also supplied in legacy detail tables.
    # Remove only identical rows already shown above; differing facts survive.
    visible_metrics = [*as_list(module.get("metrics")), *card_metrics]
    tables = []
    for raw_table in as_list(module.get("detail_tables")):
        table = as_dict(raw_table)
        if table.get("title") == "公共回测统计":
            continue
        rows = as_list(table.get("rows"))
        if table.get("title") == "产品专属统计":
            rows = public_specialized_rows(rows)
            table = {**table, "title": "结构统计"}
        if table.get("title") == "结构统计":
            rows = [row for row in rows if row not in visible_metrics]
        if rows:
            tables.append({**table, "rows": rows})
    blocks.append(detail_tables(tables))
    risk_notes = as_list(as_dict(data.get("risk")).get("limitations")) if "risk" in as_list(data.get("sections")) else []
    blocks.append(item_list([note for note in as_list(module.get("limitations")) if note not in risk_notes]))
    return "".join(block for block in blocks if block)


def render_parameters(data: dict[str, Any], *, section_title: str = "") -> str:
    module = as_dict(data.get("parameters"))
    seen: set[str] = set()

    def unique_rows(key: str) -> list[dict[str, Any]]:
        rows = []
        for raw in as_list(module.get(key)):
            row = as_dict(raw)
            marker = parameter_key(row) or json.dumps(row, ensure_ascii=False, sort_keys=True, default=str)
            if row and marker not in seen:
                seen.add(marker)
                rows.append(row)
        return rows

    rows = [*unique_rows("common_input"), *unique_rows("payoff_input")]
    visible = parameter_table(rows, "" if section_title == "合同参数" else "合同参数")
    return visible + detail_tables(as_list(module.get("detail_tables")))


def render_risk(data: dict[str, Any]) -> str:
    module = as_dict(data.get("risk"))
    items = item_list(as_list(module.get("items")), "risk-list")
    disclaimer = text(module.get("disclaimer"))
    suitable = item_list(as_list(module.get("suitable_for")))
    not_suitable = item_list(as_list(module.get("not_suitable_for")))
    suitability_block = (f"<h3>适用条件</h3>{suitable}" if suitable else "") + (f"<h3>不适用情形</h3>{not_suitable}" if not_suitable else "")
    missing_analysis = [label for key, label in (("payoff", "收益结构"), ("pricing", "估值定价"), ("backtest", "历史回测"))
                        if text(as_dict(data.get(key)).get("status")).lower() == "not_run"]
    limitation_items = [
        item for item in as_list(module.get("limitations"))
        if "configured_paths" not in text(item)
        and "固定路径数精度状态" not in text(item)
        and "分支覆盖存在额外限制" not in text(item)
    ]
    if missing_analysis:
        limitation_items.append("本次未运行" + "、".join(missing_analysis) + "，相关结论尚未验证。")
    limitations = item_list(limitation_items)
    limitation_block = f"<h3>数据与方法限制</h3>{limitations}" if limitations else ""
    disclaimer_block = f'<p class="disclaimer">{esc(disclaimer)}</p>' if disclaimer else ""
    return items + suitability_block + limitation_block + disclaimer_block


def render_conclusion(data: dict[str, Any]) -> str:
    """Render only the structured frozen digest supplied by Reporter."""

    module = as_dict(data.get("conclusion"))
    structure = text(module.get("structure_name"))
    underlyings = text(module.get("underlyings"))
    blocks: list[str] = ['<div class="conclusion-band">']
    recommended = module.get("has_recommendation") is not False
    if structure or underlyings:
        label = "推荐结论" if recommended else "研究结论"
        blocks.append(f'<p class="conclusion-band__label">{label}</p>')
        statement = (f"推荐{structure}" if recommended else f"本次研究结构为{structure}") if structure else ""
        if underlyings:
            statement += f"，挂钩{underlyings}"
        blocks.append(f"<p class=\"conclusion-band__statement\">{rich_text(statement + '。')}</p>")
    reasons = item_list(as_list(module.get("reasons")))
    if reasons:
        blocks.append(f"<h3>{'推荐理由' if recommended else '研究范围'}</h3>{reasons}")
    valuation = [*as_list(module.get("valuation_summary")), *as_list(module.get("greeks_summary"))]
    if valuation:
        blocks.append("<h3>估值摘要</h3>" + metric_strip(valuation, show_basis=False))
    backtest = as_list(module.get("backtest_summary"))
    if backtest:
        preferred = ("有效收益样本数", "历史正收益样本占比", "平均合同结算收益率", "最低合同结算收益率")
        selected = [row for label in preferred for row in backtest if as_dict(row).get("label") == label]
        shown = selected or backtest[:4]
        # The complete metrics and their basis remain in the backtest chapter.
        if "backtest" in as_list(data.get("sections")):
            shown = [{key: value for key, value in as_dict(row).items() if key not in {"note", "basis"}} for row in shown]
        blocks.append("<h3>回测摘要</h3>" + metric_strip(shown, distinct_notes=True))
        risk_notes = as_list(as_dict(data.get("risk")).get("limitations")) if "risk" in as_list(data.get("sections")) else []
        blocks.append(item_list([note for note in as_list(module.get("backtest_summary_notes")) if note not in risk_notes]))
    risk_items = as_list(as_dict(data.get("risk")).get("items")) if "risk" in as_list(data.get("sections")) else []
    risks = item_list([item for item in as_list(module.get("risk_summary")) if item not in risk_items], "risk-list")
    if risks:
        blocks.append(f"<h3>风险边界</h3>{risks}")
    blocks.append("</div>")
    return "".join(blocks) if len(blocks) > 2 else ""


def load_report_theme(config: DesignerConfig | None = None) -> str:
    """Read report CSS through the single Designer runtime configuration."""

    return (config or load_designer_config()).read_report_theme()


def validate_generated_javascript(source: str) -> None:
    """Reject malformed offline chart bootstrap code before delivery."""

    # A JavaScript compiler handles regex literals, comments and template
    # interpolation correctly; a character-stack parser cannot.
    script = re.sub(r"^\s*<script>|</script>\s*$", "", source, flags=re.IGNORECASE)
    runtime = os.environ.get("OPTIONHELPER_AGENT_RUNTIME_PATH", "")
    if runtime and Path(runtime).is_file():
        # The desktop app already ships a verified Node runtime. Finder/Explorer
        # launches do not inherit a developer shell or require system Node.
        request = {"jsonrpc": "2.0", "id": 1, "method": "runtime.validateJavascript", "params": {"source": script}}
        checked = subprocess.run([runtime], input=json.dumps(request) + "\n", capture_output=True,
                                 text=True, encoding="utf-8", check=False, timeout=30)
        replies = [json.loads(line) for line in checked.stdout.splitlines() if line.strip().startswith("{")]
        reply = next((item for item in replies if item.get("id") == 1), {})
        if checked.returncode or reply.get("result", {}).get("valid") is not True:
            detail = reply.get("error", {}).get("message") or "内置图表校验未返回结果"
            raise ValueError(f"生成的图表JavaScript语法校验失败：{detail}")
        return
    node = shutil.which("node")
    if node is None:
        raise ValueError("当前环境缺少JavaScript校验运行时，请检查App内置运行时或安装Node.js。")
    with tempfile.NamedTemporaryFile("w", suffix=".js", encoding="utf-8", delete=False) as stream:
        stream.write(script)
        candidate = Path(stream.name)
    try:
        checked = subprocess.run([node, "--check", str(candidate)], capture_output=True, text=True, check=False, timeout=30)
    finally:
        candidate.unlink(missing_ok=True)
    if checked.returncode:
        detail = checked.stderr.strip().splitlines()[-1] if checked.stderr.strip() else "未知语法错误"
        raise ValueError(f"生成的图表JavaScript语法无效，已阻止交付：{detail}")



def render_html(
    payload: dict[str, Any],
    input_dir: Path | None = None,
    echarts_path: str = "",
    *,
    design_system_id: str = DESIGN_SYSTEM_ID,
    config: DesignerConfig | None = None,
    section_definition: Sequence[tuple[str, str, str]] | None = None,
    appended_content: dict[str, Sequence[Mapping[str, Any]]] | None = None,
    template_shell: str = "report.html",
    product_sections: Sequence[Mapping[str, Any]] = (),
) -> str:
    validate_payload(payload)
    config = config or load_designer_config()
    input_dir = input_dir or Path.cwd()
    if not echarts_path:
        echarts_path = config.relative_echarts_path(input_dir)
    meta = as_dict(payload.get("meta"))
    # The standard seven chapters come from the selected template. A validated
    # one-off patch may adjust their presentation or insert a supplemental
    # block already frozen in the payload; it never creates financial facts.
    title = text(meta.get("title")) or "单个期权结构推荐报告"
    report_theme = load_report_theme(config)
    design_system = build_design_system()
    charts: list[dict[str, Any]] = []
    renderers = {
        "recommendation": lambda: render_recommendation(payload),
        "payoff": lambda: render_payoff(payload, input_dir),
        "pricing": lambda: render_pricing(payload, charts),
        "backtest": lambda: render_backtest(payload, charts),
        "risk": lambda: render_risk(payload),
        "conclusion": lambda: render_conclusion(payload),
        "parameters": lambda: render_parameters(payload),
        "supplemental": lambda: "",
    }
    section_definition = section_definition or tuple(
        (key, SECTION_TITLES[key], key) for key in SECTION_ORDER
    )
    appended_content = appended_content or {}
    sections = []
    for section_key, section_title, key in section_definition:
        if key in {"payoff", "pricing", "backtest"} and text(as_dict(payload.get(key)).get("status")).lower() in {"", "not_run", "pending", "unsupported"}:
            if not appended_content.get(section_key):
                continue
        if key == "recommendation" and as_dict(payload.get("recommendation")).get("has_recommendation") is False:
            section_title = "研究结构"
        if key == "recommendation":
            body = render_recommendation(payload, section_title=section_title)
        elif key == "parameters":
            body = render_parameters(payload, section_title=section_title)
        else:
            body = renderers[key]()
        appended = render_presentation_content(appended_content.get(section_key, ()))
        body += appended
        if not body:
            continue
        section_id = f"section-{section_key}"
        section_status = ""
        if key in {"payoff", "pricing", "backtest"}:
            section_status = text(as_dict(payload.get(key)).get("status") or "pending").lower()
        sections.append({
            "id": section_id,
            "title": section_title,
            "body": body,
            "status": section_status,
            "status_attr": f' data-status="{esc(section_status)}"' if section_status else "",
        })

    if product_sections:
        product_blocks = []
        for index, candidate in enumerate(product_sections, 1):
            facts = deepcopy(as_dict(candidate.get("facts")))
            validate_payload(facts)
            for module in ("pricing", "backtest"):
                for chart in as_list(as_dict(facts.get(module)).get("charts")):
                    if isinstance(chart, dict):
                        chart["id"] = f"product-{index}-{chart.get('id', 'chart')}"
            bodies = [("合同条款", render_parameters(facts, section_title="合同条款"))]
            for module, label, renderer in (("payoff", "收益结构", lambda: render_payoff(facts, input_dir)),
                                             ("pricing", "估值定价", lambda: render_pricing(facts, charts)),
                                             ("backtest", "历史回测", lambda: render_backtest(facts, charts))):
                if text(as_dict(facts.get(module)).get("status")).lower() in {"ready", "partial", "failed"}:
                    bodies.append((label, renderer()))
            body = "".join(f"<section><h3>{esc(label)}</h3>{value}</section>" for label, value in bodies if value)
            if not body:
                continue
            product_blocks.append({"id": f"product-{index}", "title": text(candidate.get("title")) or f"产品{index}",
                                   "body": body, "status_attr": ""})
        risk_sections = [item for item in sections if item["id"] == "section-risk"]
        sections = [item for item in sections if item["id"] != "section-risk"] + product_blocks + risk_sections

    content = "".join(
        f'<section id="{item["id"]}" class="report-section"{item["status_attr"]}>'
        f'<h2><span class="section-title">{esc(item["title"])}</span></h2>{item["body"]}</section>'
        for item in sections
    )
    toc = (
        '<aside class="report-toc" aria-label="报告目录"><nav>'
        + "".join(
            f'<a href="#{esc(item["id"])}"><span>{position}.</span>{esc(item["title"])}</a>'
            for position, item in enumerate(sections, start=1)
        )
        + "</nav></aside>"
    )
    chart_json = json.dumps(charts, ensure_ascii=False).replace("</", "<\\/")
    report_identity = [("报告日期", meta.get("as_of_date"))]
    identity = "".join(
        f'<div><dt>{esc(label)}</dt><dd>{esc_rendered(value)}</dd></div>'
        for label, value in report_identity
        if text(value)
    )
    echarts_head = f'<script src="{esc(echarts_path)}" defer></script>' if charts else ""
    chart_script = "" if not charts else r"""<script>
	const chartSpecs=__CHARTS__;
	const chartInstances=[];
	const palette=__CHART_PALETTE__;
	const chartTheme=__CHART_THEME__;
	const lineTypes=chartTheme.lineTypes;
	const symbols=chartTheme.symbols;
	function markChartUnavailable(id,message){const el=document.getElementById(id);if(!el)return;el.classList.add("chart--unavailable");el.textContent=message||"图表资源加载失败，请重新加载报告。";}
	function markChartsUnavailable(){chartSpecs.forEach(spec=>markChartUnavailable(spec.id));}
function publicNumber(value, valueFormat, digits = 2) {
  if (value === null || value === undefined || value === '') return '—';
  let number = Number(value);
  if (!Number.isFinite(number)) return String(value);
  if (valueFormat === 'percent') number *= 100;
  const suffix = ['percent', 'percent_points'].includes(valueFormat) ? '%' : '';
  const mathematicalSign = text => String(text).replace(/^-/, '−');
  if (number !== 0 && Math.round(Math.abs(number) * 10 ** digits) === 0) {
    const [mantissa, exponent] = number.toExponential(2).split('e');
    const superscript = {'-':'⁻','0':'⁰','1':'¹','2':'²','3':'³','4':'⁴','5':'⁵','6':'⁶','7':'⁷','8':'⁸','9':'⁹'};
    return `${mathematicalSign(mantissa.replace(/0+$/, '').replace(/\.$/, ''))}×10${[...String(Number(exponent))].map(char => superscript[char] || char).join('')}${suffix}`;
  }
  return mathematicalSign(new Intl.NumberFormat('zh-CN', {maximumFractionDigits: digits}).format(Object.is(number, -0) ? 0 : number)) + suffix;
}
function publicCategory(value, axisName, digits = 2) {
  return /年|日期|时间|代码|标识/.test(String(axisName || '')) ? String(value ?? '') : publicNumber(value, 'number', digits);
}
function axisPrecision(values, format) {
  const numbers = [...new Set(values.filter(value => value !== null && value !== '' && Number.isFinite(Number(value))).map(Number))].sort((a,b) => a-b);
  if (numbers.length < 2) return 2;
  let step = Infinity;
  for (let index = 1; index < numbers.length; index++) step = Math.min(step, numbers[index] - numbers[index-1]);
  if (format === 'percent') step *= 100;
  return Math.min(6, Math.max(2, Math.ceil(-Math.log10(step))));
}
function renderChart(spec) {
  const el = document.getElementById(spec.id);
  if (!el) return;
  const isHeatmap = spec.type === 'heatmap';
  const type = spec.type === 'bar' ? 'bar' : 'line';
  const points = spec.x.length;
  const series = Array.isArray(spec.series) ? spec.series : [];
  const hasLegend = !isHeatmap && series.length > 1;
  const chart = echarts.init(el, null, {renderer: 'svg'});
  const labelStyle = {color: chartTheme.axis.label, fontSize: chartTheme.textStyle.fontSize, hideOverlap: true, margin: 12};
  const categoryAxis = (values, name) => {
    const digits = axisPrecision(values, 'number');
    const longestLabel = Math.max(0, ...values.map(value => String(value ?? '').length));
    const labelRotation = values.length > 12 || longestLabel > 10 ? 32 : 0;
    return ({
    type: 'category', name: name || '', nameLocation: 'middle', nameGap: 38, data: values,
    axisLine: {show: true, lineStyle: {color: chartTheme.axis.line, width: 1.2}},
    axisTick: {show: true, alignWithLabel: true, interval: 'auto', lineStyle: {color: chartTheme.axis.line}},
    axisLabel: {...labelStyle, interval: 'auto', rotate: labelRotation,
      formatter: value => publicCategory(value, name, digits)}
    });
  };
  if (isHeatmap) {
    const values = spec.data.map(item => Number(item[2])).filter(Number.isFinite);
    const escapeLabel = value => String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
    chart.setOption({
      animation: false, color: palette,
      tooltip: {position: 'top', confine: true, formatter: item =>
        `${escapeLabel(spec.x_axis_name || '横轴')}：${escapeLabel(publicCategory(spec.x[item.data[0]], spec.x_axis_name, 4))}<br>${escapeLabel(spec.y_axis_name || '纵轴')}：${escapeLabel(publicCategory(spec.y[item.data[1]], spec.y_axis_name, 4))}<br>${escapeLabel(spec.z_axis_name || '数值')}：${escapeLabel(publicNumber(item.data[2], spec.value_format, 4))}${escapeLabel(spec.value_suffix || '')}`},
      grid: {left: 42, right: 24, top: 30, bottom: 105, containLabel: true},
      xAxis: categoryAxis(spec.x, spec.x_axis_name),
      yAxis: {...categoryAxis(spec.y, spec.y_axis_name), nameGap: 55},
      visualMap: {min: Math.min(...values), max: Math.max(...values), calculable: false,
        orient: 'horizontal', left: 'center', bottom: 4,
        formatter: value => publicNumber(value, spec.value_format),
        textStyle: {color: chartTheme.axis.label, fontSize: chartTheme.textStyle.fontSize},
        inRange: {color: [chartTheme.heatmap.low, palette[0], palette[1]]}},
      series: [{name: spec.z_axis_name || '数值', type: 'heatmap', data: spec.data,
        label: {show: false}, emphasis: {itemStyle: {shadowBlur: 8}}}]
    });
  } else {
    const yValues = series.flatMap(item => item.data).filter(value => value !== null && value !== '' && Number.isFinite(Number(value))).map(Number);
    const span = (Math.max(...yValues) - Math.min(0, ...yValues)) / 4;
    const yDigits = axisPrecision([0, span], spec.value_format);
    chart.setOption({
      animation: false, color: palette,
      tooltip: {trigger: 'axis', confine: true, valueFormatter: value => `${publicNumber(value, spec.value_format, Math.max(4, yDigits))}${spec.value_suffix || ''}`},
      legend: {show: hasLegend, type: 'scroll', top: 2, textStyle: chartTheme.textStyle},
      grid: {left: 24, right: 28, top: hasLegend ? 60 : 35, bottom: 78, containLabel: true},
      xAxis: categoryAxis(spec.x, spec.x_axis_name),
      yAxis: {type: 'value', name: spec.y_axis_name || '', splitNumber: 4,
        nameTextStyle: {color: chartTheme.axis.label},
        axisLine: {show: true, lineStyle: {color: chartTheme.axis.line, width: 1.2}},
        axisTick: {show: true, lineStyle: {color: chartTheme.axis.line}},
        axisLabel: {...labelStyle, formatter: value => publicNumber(value, spec.value_format, yDigits)},
        splitLine: {show: false}},
      series: series.map((item, index) => ({name: item.name, type, smooth: false,
        symbol: type === 'line' ? symbols[index % symbols.length] : 'none',
        showSymbol: type === 'line' && points <= 24, symbolSize: 5, barMaxWidth: 42,
        data: item.data, itemStyle: {color: palette[index % palette.length]},
        lineStyle: {width: 2, type: lineTypes[index % lineTypes.length]}}))
    });
  }
  chartInstances.push(chart);
}
	function initialiseCharts(){if(!window.echarts){markChartsUnavailable();return;}chartSpecs.forEach(spec=>{try{renderChart(spec);}catch(error){markChartUnavailable(spec.id,"图表初始化失败，请重新加载报告。");console.error("图表初始化失败",spec.id,error);}});}
	window.addEventListener("DOMContentLoaded",initialiseCharts);let resizeTimer;window.addEventListener("resize",()=>{window.clearTimeout(resizeTimer);resizeTimer=window.setTimeout(()=>chartInstances.forEach(chart=>chart.resize()),150)});
</script>"""
    chart_script = (
        chart_script.replace("__CHARTS__", chart_json)
        .replace("__CHART_PALETTE__", json.dumps(list(design_system.tokens["chart_palette"])))
        .replace("__CHART_THEME__", json.dumps(design_system.echarts_theme, ensure_ascii=False))
    )
    if chart_script:
        validate_generated_javascript(chart_script)
    template = config.read_template(template_shell)
    return (
        template.replace("__TITLE__", esc(title))
        .replace("__ECHARTS_HEAD__", echarts_head)
        .replace("__REPORT_THEME__", report_theme)
        .replace("__BRAND__", esc(PUBLIC_BRAND))
        .replace("__DESIGN_SYSTEM_ID__", esc(design_system_id))
        .replace("__IDENTITY__", identity)
        .replace("__REPORT_TOC__", toc)
        .replace("__CONTENT__", content)
        .replace("__CHARTS__", chart_json)
        .replace("__CHART_PALETTE__", json.dumps(list(design_system.tokens["chart_palette"])))
        .replace("__CHART_THEME__", json.dumps(design_system.echarts_theme, ensure_ascii=False))
        .replace("__CHART_SCRIPT__", chart_script)
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Render a modular OptionHelper HTML research report.")
    parser.add_argument("--input", required=True, type=Path, help="Report payload JSON path")
    parser.add_argument("--output", required=True, type=Path, help="Output filename, with or without .html")
    parser.add_argument("--output-type", choices=("card", "quote", "report"), default="report", help="Card, Quote or detailed Report")
    parser.add_argument("--format", choices=("html", "pdf"), help="Output format; .pdf also selects PDF")
    parser.add_argument(
        "--asset-mode",
        choices=tuple(sorted(ASSET_MODES)),
        default="shared",
        help="HTML asset mode: shared references the project ECharts file; portable copies it beside the HTML",
    )
    args = parser.parse_args()

    input_path = args.input.resolve()
    if not input_path.is_file():
        raise FileNotFoundError(f"找不到报告输入文件：{input_path}")
    with input_path.open("r", encoding="utf-8") as stream:
        payload = json.load(stream)
    if not isinstance(payload, dict):
        raise ValueError("报告输入必须是JSON对象。")
    requested_output = args.output.resolve()
    requested_format = args.format or ("pdf" if requested_output.suffix.lower() == ".pdf" else "html")
    if requested_format == "pdf" and requested_output.suffix.lower() != ".pdf":
        requested_output = requested_output.with_suffix(".pdf")
    output_path = (
        requested_output
        if requested_output.suffix.lower() == f".{requested_format}"
        else requested_output.with_suffix(f".{requested_format}")
    )
    asset_mode = args.asset_mode

    # Every CLI output uses the public handoff entry. Portable resources are
    # materialized only from the verified artifact manifest.
    from .design_renderer import materialize_portable_assets, render
    from .models import DesignerInput

    output_path.parent.mkdir(parents=True, exist_ok=True)
    artifact = render(
        DesignerInput(
            payload=payload,
            output_type=args.output_type,
            format=requested_format,
            asset_mode=asset_mode,
            input_dir=input_path.parent,
            output_dir=output_path.parent,
        )
    )
    if requested_format == "pdf":
        output_path.write_bytes(artifact["pdf"])
        print(f"已生成PDF：{output_path}")
        return
    output_path.write_text(artifact["html"], encoding="utf-8", newline="")
    if asset_mode == "portable":
        materialize_portable_assets(artifact.get("portable_assets", []), output_path.parent)
    print(f"已生成HTML：{output_path}")


if __name__ == "__main__":
    main()
