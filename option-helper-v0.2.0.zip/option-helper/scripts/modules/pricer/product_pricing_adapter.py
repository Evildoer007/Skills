"""ResolvedContract到Pricer内部统一数值入口的唯一产品适配边界。"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, replace
from datetime import date, timedelta
from typing import Any

from runtime.contracts.contract_api import ResolvedContract

from .calendar_policy import requires_future_trading_calendar
from .cashflow_lifecycle import (
    apply_cashflow_lifecycle,
    contractual_initial_cashflow,
    paths_include_initial_cashflow,
)
from .config import PricingConfig
from .engines.pricing_core.engine.derivatives.results import GreekValue, PricingResult
from .engines.pricing_core.main import price_option
from .engines.pricing_core.prepared_optionreg import PreparedOptionRegPricer
from .greeks import real_spot_greeks, scale_result
from .model_router import capability_for, resolve_route
from .observation_schedule import bind_accumulator_remaining_count
from .observed_state import ObservedContractState
from .observed_state_rebuilder import analytical_history_inputs


class ProductNotAvailable(ValueError):
    """冻结合同不能无歧义映射到正式基座时的显式结果。"""


@dataclass(frozen=True)
class ProductMapping:
    family: str
    structure: str
    status: str
    reason: str | None = None


_EXACT_MAPPINGS = {
    "1.1": ProductMapping("VANILLA", "EUROPEAN_VANILLA", "supported"),
    "1.2": ProductMapping("VANILLA", "EUROPEAN_VANILLA", "supported"),
    **{
        product_id: ProductMapping("AIRBAG", "AIRBAG", "supported")
        for product_id in ("2.1", "2.2", "2.3", "2.4", "3.1", "3.2", "3.3", "3.4")
    },
}

_ANALYTICAL_ADAPTERS = frozenset({
    "european_vanilla",
    "european_portfolio",
    "barrier",
    "binary",
    "touch_portfolio",
    "airbag_portfolio",
    "terminal_portfolio",
    "sharkfin",
    "worst_of",
    "variance_swap",
    "range_accrual",
})

def product_mapping(product_id: str) -> ProductMapping:
    """OptionReg产品的唯一正式基座归属。"""
    product_id = str(product_id)
    capability = capability_for(product_id)
    if capability is not None:
        return ProductMapping(capability.family, capability.structure, "supported")
    return ProductMapping("UNCLASSIFIED", "UNCLASSIFIED", "not_available", "产品未登记为OptionReg可执行MC结构")


class ProductPricingAdapter:
    """唯一适配器：只编译参数并调用正式``main.price_option``入口。

    产品级验证通过的结构编译到各自解析实现；其余entry_status=True产品统一
    编译成``OPTIONREG_PATH``并由同一离散路径、monitor、condition、
    cases/cash解释器进行Monte Carlo估值。
    """

    _EXACT_PRODUCT_IDS = tuple(_EXACT_MAPPINGS)

    def __init__(
        self,
        contract: ResolvedContract,
        config: PricingConfig,
        market_snapshot: Mapping[str, Any] | None,
        observed_state: ObservedContractState,
    ) -> None:
        self.contract = contract
        self.config = config
        self.market_snapshot = dict(market_snapshot or {})
        self.observed_state = observed_state
        if observed_state.knocked_out:
            raise ProductNotAvailable("合同已敲出并终止；已实现结算现金流只审计，不重新模拟")
        if (
            contract.product_id == "7.1"
            and observed_state.accumulated_count > 0
            and observed_state.accumulated_quantity <= 0.0
        ):
            raise ProductNotAvailable("存续累购必须提供已累计数量accumulated_quantity；观察次数不能代替数量")
        allowed = tuple(str(value) for value in contract.terms.get("pricing_methods", ()))
        self.route = resolve_route(contract.product_id, allowed, config.model_method)
        mapping = product_mapping(contract.product_id)
        if mapping.status != "supported":
            raise ProductNotAvailable(mapping.reason or _unavailable_reason(contract, allowed, config.model_method))
        if self.route is None:
            raise ProductNotAvailable(_unavailable_reason(contract, allowed, config.model_method))
        if self.route.capability.adapter not in _ANALYTICAL_ADAPTERS | {"optionreg_path"}:
            raise ProductNotAvailable(f"{contract.product_id}没有已验证的{self.route.capability.adapter}参数适配")
        self.trading_calendar = _validated_trading_calendar(
            self.market_snapshot.get("trading_calendar"),
            as_of=_as_of(self.config.valuation_date),
            demo_mode=self.config.demo_mode,
        ) if self.requires_trading_calendar else None
        if self.route.capability.adapter == "european_vanilla":
            observed_state.validate_european_vanilla()
        if self.method == "analytical" and self.route.capability.adapter in {
            "barrier", "touch_portfolio", "airbag_portfolio", "sharkfin"
        } and (observed_state.occurred_events or observed_state.knocked_in):
            raise ProductNotAvailable("存续路径事件已发生时请使用Monte Carlo，以冻结观察状态继续估值")
        start_value = contract.identity.get("contract_start_date")
        if _valuation_after_contract_start(observed_state, start_value) and observed_state.observation_history is None:
            if contract.product_id == "9.4":
                raise ProductNotAvailable("存续方差互换缺少估值日前已实现方差，不能只估算剩余观察期")
            if contract.product_id == "9.8":
                raise ProductNotAvailable("存续区间计息缺少估值日前累计区间内观察数，不能只估算剩余观察期")
        if self.method == "monte_carlo":
            if self.config.path_count is None:
                raise ProductNotAvailable("Monte Carlo必须显式提供path_count")
            observed_state.validate_path_events(
                contract_start_date=None if start_value is None else str(start_value),
                path_dependent=self.requires_trading_calendar,
                requires_accumulated_count="n_coupon" in contract.terms.get("monitor", {}),
                requires_accumulated_quantity="Q_acc" in contract.terms.get("monitor", {}),
                unsupported_midlife_aggregate="n_in" in contract.terms.get("monitor", {}),
            )
            if observed_state.occurred_events:
                history_sessions = _verified_state_sessions(self.market_snapshot, self.trading_calendar)
                observed_state.validate_observation_bounds(
                    contract_start_date=str(start_value),
                    contract_terms=contract.terms,
                    trading_sessions=history_sessions,
                )
        if self.method != "monte_carlo":
            expected_assets = 2 if self.route.capability.adapter == "worst_of" else 1
            if len(contract.underlyings) != expected_assets:
                raise ProductNotAvailable(f"该解析结构必须包含{expected_assets}个标的")
        self.asset = contract.underlyings[0]
        references = contract.identity.get("reference_prices")
        if not isinstance(references, Mapping) or set(references) != set(contract.underlyings):
            raise ProductNotAvailable("定价必须提供合同起始参考价reference_prices")
        self.reference_price = _number(references[self.asset], "reference_prices")
        self._basis = _cashflow_basis(self.contract, self.reference_price)
        self._analytical_history = analytical_history_inputs(contract, observed_state.observation_history) if self.method == "analytical" else {}
        self._valuation_state = (
            self.observed_state.valuation_state(
                contract_start_date=str(self.contract.identity.get("contract_start_date"))
            )
            if self.method == "monte_carlo"
            else {}
        )
        self._resolved_contract_by_maturity: dict[float, ResolvedContract] = {}
        self._prepared_optionreg = PreparedOptionRegPricer() if self.method == "monte_carlo" else None

    @property
    def family(self) -> str:
        return "OPTIONREG" if self.method == "monte_carlo" else self.route.capability.family

    @property
    def structure(self) -> str:
        return "OPTIONREG_PATH" if self.method == "monte_carlo" else self.route.capability.structure

    @property
    def method(self) -> str:
        return self.route.method

    @property
    def requires_trading_calendar(self) -> bool:
        """Use the one formal calendar policy for every adapter reprice."""
        return requires_future_trading_calendar(
            self.contract.product_id,
            self.contract.terms,
            self.method,
        )

    def reprice(self, *, spot: float | None = None, volatility: float | None = None, risk_free_rate: float | None = None, maturity_years: float | None = None, risk_greeks: frozenset[str] | None = None) -> PricingResult:
        """同一基座入口的受控重估；供PV、Greek和风险网格共同使用。"""
        parameters = self._parameters(
            spot=self._spot() if spot is None else spot,
            volatility=self._volatility() if volatility is None else volatility,
            risk_free_rate=float(self.config.risk_free_rate) if risk_free_rate is None else risk_free_rate,
            maturity_years=self._maturity() if maturity_years is None else maturity_years,
            risk_greeks=risk_greeks,
        )
        engine_method = (
            "MONTE_CARLO_CPU"
            if self.method == "monte_carlo"
            else self.route.capability.analytical_engine_method
        )
        if engine_method is None:
            raise ProductNotAvailable(f"{self.contract.product_id}没有已验证的解析引擎")
        if self.method == "monte_carlo":
            assert self._prepared_optionreg is not None
            result = _with_standard_error(self._prepared_optionreg.price(parameters))
        else:
            run = price_option(self.family, self.structure, parameters, engine_method, output="NONE")
            result = _from_run(run)
        quantity = _analytical_quantity(self.contract)
        numerical_contract = parameters["contract"].get("resolved_contract", self.contract)
        if self.method != "monte_carlo":
            result = scale_result(result, quantity)
        result = apply_cashflow_lifecycle(
            result,
            contract=self.contract,
            valuation_date=self.config.valuation_date,
            observed_state=self.observed_state,
            initial_cashflow=contractual_initial_cashflow(self.contract, quantity),
            cashflow_scale=self._basis["cashflow_scale"],
            numerical_value_includes_initial=(
                self.method == "monte_carlo"
                and paths_include_initial_cashflow(numerical_contract)
            ),
            numerical_initial_cashflow=(
                contractual_initial_cashflow(numerical_contract, quantity)
                if self.method == "monte_carlo" else None
            ),
        )
        if self.method != "monte_carlo":
            result = real_spot_greeks(result, self.reference_price)
        result = _apply_value_basis(result, self.contract.product_id)
        # ``reprice`` is an internal base/Greek/risk-grid primitive. It records
        # neither a public precision classification nor a quotation decision.
        return replace(
            result,
            precision_status="not_assessed",
            quote_eligible=False,
            path_count=int(self.config.path_count) if self.method == "monte_carlo" else None,
        )

    def _parameters(self, *, spot: float, volatility: float, risk_free_rate: float, maturity_years: float, risk_greeks: frozenset[str] | None = None) -> dict[str, Any]:
        if spot <= 0.0 or volatility <= 0.0 or maturity_years <= 0.0:
            raise ValueError("受控重估的spot、volatility和maturity_years必须为正数")
        config = {"greek_bumps": {
            "spot_relative_bump": float(self.config.greek_bumps["spot"]),
            "volatility_absolute_bump": float(self.config.greek_bumps["volatility"]),
            "risk_free_rate_absolute_bump": float(self.config.greek_bumps["rate"]),
        }}
        if self.method == "monte_carlo":
            config.update({"paths": int(self.config.path_count), "seed": int(self.config.random_seed)})
            if risk_greeks is not None:
                config["diagnostics"] = {"requested_greeks": tuple(sorted(risk_greeks))}
        basis = self._basis
        if self.method == "monte_carlo":
            maturity_key = float(maturity_years)
            resolved_contract = self._resolved_contract_by_maturity.get(maturity_key)
            if resolved_contract is None:
                resolved_contract = _contract_with_maturity(
                    self.contract,
                    maturity_key + self._elapsed_years(),
                    remaining_years=maturity_key,
                    trading_calendar=self.trading_calendar,
                    as_of=_as_of(self.config.valuation_date),
                    completed_observations=self._completed_accumulator_observations(),
                    replay_history=self.observed_state.observation_history is not None,
                )
                self._resolved_contract_by_maturity[maturity_key] = resolved_contract
            contract = {
                "resolved_contract": resolved_contract,
                "basis": basis,
                "asset_spots": [_asset_number(self.config.spot, asset, "spot") for asset in self.contract.underlyings],
                "asset_volatilities": [self._asset_volatility(asset) for asset in self.contract.underlyings],
                "asset_dividend_yields": [_asset_number(self.config.dividend_yield, asset, "dividend_yield") for asset in self.contract.underlyings],
                "correlation": self.config.correlation,
                "trading_sessions": [] if self.trading_calendar is None else list(self.trading_calendar["sessions"]),
                "calendar_id": "" if self.trading_calendar is None else self.trading_calendar["calendar_id"],
                "calendar_revision": "" if self.trading_calendar is None else self.trading_calendar["calendar_revision"],
            }
        elif self.route.capability.adapter == "european_vanilla":
            direction = "CALL" if self.contract.product_id == "1.1" else "PUT"
            contract = {
                "strike": float(self.contract.terms["K"]),
                "maturity_years": float(maturity_years),
                "call_put": direction,
                "basis": basis,
            }
        elif self.route.capability.adapter == "barrier":
            contract = _barrier_contract(self.contract, maturity_years, basis)
        elif self.route.capability.adapter == "binary":
            contract = _binary_contract(self.contract, maturity_years, basis)
        elif self.route.capability.adapter == "sharkfin":
            contract = _sharkfin_contract(self.contract, maturity_years, basis)
        elif self.route.capability.adapter == "worst_of":
            correlation = _two_asset_correlation(self.config.correlation)
            references = self.contract.identity["reference_prices"]
            contract = {
                "strike": float(self.contract.terms["K"]),
                "maturity_years": float(maturity_years),
                "normalized_spots": tuple(
                    _asset_number(self.config.spot, asset, "spot")
                    / float(references[asset])
                    * float(self.contract.terms["S0Vec"][index])
                    for index, asset in enumerate(self.contract.underlyings)
                ),
                "volatilities": tuple(self._asset_volatility(asset) for asset in self.contract.underlyings),
                "dividend_yields": tuple(
                    _asset_number(self.config.dividend_yield, asset, "dividend_yield")
                    for asset in self.contract.underlyings
                ),
                "correlation": correlation,
                "basis": basis,
            }
        elif self.route.capability.adapter == "variance_swap":
            contract = {
                **self._analytical_history,
                "strike_volatility": float(self.contract.terms["Ksig"]),
                "annualization_days": int(self.contract.terms["annualization_days"]),
                "observation_times": _analytical_observation_times(
                    self.trading_calendar, _as_of(self.config.valuation_date), maturity_years,
                ),
                "maturity_years": _analytical_settlement_maturity(self.contract, self.trading_calendar, _as_of(self.config.valuation_date), maturity_years),
                "basis": basis,
            }
        elif self.route.capability.adapter == "range_accrual":
            observation_times = _analytical_observation_times(
                self.trading_calendar, _as_of(self.config.valuation_date), maturity_years,
                contract=self.contract,
            )
            contract = {
                **self._analytical_history,
                "lower": float(self.contract.terms["Hlow"]),
                "upper": float(self.contract.terms["Hup"]),
                "maximum_coupon": float(self.contract.terms["c_max"]),
                "observation_times": observation_times,
                "maturity_years": _analytical_settlement_maturity(self.contract, self.trading_calendar, _as_of(self.config.valuation_date), maturity_years),
                "basis": basis,
            }
        else:
            contract = {
                "legs": _analytical_portfolio_legs(self.contract, maturity_years, basis),
                "basis": basis,
            }
        return {
            "contract": contract,
            "market": {
                "as_of": _as_of(self.config.valuation_date),
                "spot": spot if self.method == "monte_carlo" else spot / self.reference_price * float(self.contract.terms.get("S0", 100.0)),
                "volatility": float(volatility),
                "risk_free_rate": float(risk_free_rate),
                "dividend_yield": _asset_number(self.config.dividend_yield, self.asset, "dividend_yield"),
                "source": str(self.market_snapshot.get("source_ref") or self.market_snapshot.get("source") or "pricing_config"),
            },
            "config": config,
            "valuation_state": self._valuation_state,
        }

    def _spot(self) -> float:
        return _asset_number(self.config.spot, self.asset, "spot")

    def _volatility(self) -> float:
        value = self.config.volatility_override if self.config.volatility_override is not None else self.config.historical_volatility
        return _asset_number(value, self.asset, "volatility")

    def _asset_volatility(self, asset: str) -> float:
        value = self.config.volatility_override if self.config.volatility_override is not None else self.config.historical_volatility
        return _asset_number(value, asset, "volatility")

    def _maturity(self) -> float:
        return float(self.config.time_to_maturity if self.config.time_to_maturity is not None else self.contract.terms["T"])

    def _elapsed_years(self) -> float:
        if self.method != "monte_carlo":
            return 0.0
        state = self.observed_state.valuation_state(
            contract_start_date=str(self.contract.identity.get("contract_start_date"))
        )
        return (int(state["calendar_day"]) - 1) / 365.0

    def _completed_accumulator_observations(self) -> int:
        start_value = self.contract.identity.get("contract_start_date")
        if self.contract.product_id != "7.1" or not _is_midlife(self.observed_state, start_value):
            return 0
        sessions = _verified_state_sessions(self.market_snapshot, self.trading_calendar)
        return self.observed_state.completed_observation_count(
            contract_start_date=str(start_value),
            contract_terms=self.contract.terms,
            monitor_key="Q_acc",
            trading_sessions=sessions,
        )


def _from_run(run: Any) -> PricingResult:
    def greek(value: Any) -> GreekValue:
        return GreekValue(
            value=value.value, unit=value.unit, bump=value.bump, difference=value.difference,
            time_basis=value.time_basis, bump_details=dict(value.bump_details or {}),
            pv_amount_value=value.pv_amount_value, pv_amount_unit=value.pv_amount_unit,
            pv_percent_value=value.pv_percent_value, pv_percent_unit=value.pv_percent_unit,
            pv_points_100_value=value.pv_points_100_value, pv_points_100_unit=value.pv_points_100_unit,
            status=value.status.value.lower(),
        )
    return PricingResult(
        pv_amount=run.result.pv_amount, pv_percent=run.result.pv_percent,
        pv_points_100=run.result.pv_points_100, currency=run.result.currency,
        greeks={name.lower(): greek(value) for name, value in run.result.greeks.items()},
        extended_greeks={name.casefold().replace(" ", "_"): greek(value) for name, value in run.result.extended_risks.items()},
        method=run.result.method, implementation_id=run.result.implementation_id, warnings=run.result.warnings,
        diagnostics={**run.result.diagnostics, "pricing_run_id": run.run_id, "route_id": run.route_id},
        engine_raw=run.result.engine_raw,
        standard_error=None if run.result.diagnostics.get("standard_error_points_100") is None else float(run.result.diagnostics["standard_error_points_100"]),
        standard_error_points_100=(
            None if run.result.diagnostics.get("standard_error_points_100") is None
            else float(run.result.diagnostics["standard_error_points_100"])
        ),
        standard_error_percent=(
            None if run.result.diagnostics.get("standard_error_points_100") is None
            else float(run.result.diagnostics["standard_error_points_100"]) / 100.0
        ),
    )


def _with_standard_error(result: PricingResult) -> PricingResult:
    """Promote the kernel diagnostic onto the shared Pricer result contract."""
    value = result.diagnostics.get("standard_error_points_100")
    if value is None:
        return result
    standard_error = float(value)
    return replace(
        result,
        standard_error=standard_error,
        standard_error_points_100=standard_error,
        standard_error_percent=standard_error / 100.0,
    )


def _cashflow_basis(contract: ResolvedContract, reference_price: float) -> dict[str, Any]:
    """Build the only scale used to project a 100-point value into money.

    ``reference_price_basis`` is never a notional.  A contract without an
    explicit cashflow scale settles directly in normalized contract points:
    it deliberately has no private currency projection rather than inventing
    one from the start reference price.
    """
    terms = contract.terms
    if "N" in terms:
        scale = float(terms["N"])
        kind = "contract_notional"
    elif "Nvar" in terms:
        scale = float(terms["Nvar"])
        kind = "variance_notional"
    elif "Nvega" in terms:
        scale = float(terms["Nvega"])
        kind = "vega_notional"
    else:
        scale = None
        kind = "normalized_contract_points"
    return {
        "reference_price_basis": float(reference_price),
        "cashflow_scale": scale,
        "cashflow_scale_kind": kind,
        "currency": contract.currency,
    }


def _apply_value_basis(result: PricingResult, product_id: str) -> PricingResult:
    """Mark the only product whose 100 points are variance, not price points."""
    if product_id != "9.4":
        return replace(result, value_basis="pv_points_100")

    def variance_unit(unit: str | None) -> str | None:
        return None if unit is None else unit.replace("pv_points_100", "variance_points_100")

    def variance_percent_unit(unit: str | None) -> str | None:
        return None if unit is None else unit.replace("pv_percent", "variance_percent")

    def convert(value: GreekValue) -> GreekValue:
        return replace(
            value,
            unit=variance_unit(value.unit),
            pv_points_100_unit=variance_unit(value.pv_points_100_unit),
            pv_percent_unit=variance_percent_unit(value.pv_percent_unit),
        )

    return replace(
        result,
        value_basis="variance_points_100",
        greeks={name: convert(value) for name, value in result.greeks.items()},
        extended_greeks={name: convert(value) for name, value in result.extended_greeks.items()},
    )


def _unavailable_reason(contract: ResolvedContract, allowed: tuple[str, ...], requested_method: str) -> str:
    available = resolve_route(contract.product_id, allowed, None)
    if requested_method == "analytical" and "analytical" not in allowed and "monte_carlo" in allowed:
        return (
            f"{contract.product_id}尚无经过产品级验证的Analytical实现；"
            "请选择Monte Carlo"
        )
    if not requested_method and available is None:
        return f"{contract.product_id}尚未登记可执行定价模型，请检查OptionReg产品配置"
    available_methods = "、".join(allowed) if allowed else "无"
    return f"{contract.product_id}不支持所选定价方法{requested_method}；产品登记方法为{available_methods}"


def _portfolio_legs(contract: ResolvedContract) -> tuple[tuple[str, float, str, float], ...]:
    terms = contract.terms
    product_id = contract.product_id
    if product_id == "2.1": values = (("long_call_k1", 1.0, "CALL", "K1"), ("short_call_k2", -1.0, "CALL", "K2"))
    elif product_id == "2.2": values = (("long_put_k1", 1.0, "PUT", "K1"), ("short_put_k2", -1.0, "PUT", "K2"))
    elif product_id == "2.3": values = (("long_put_k2", 1.0, "PUT", "K2"), ("short_put_k1", -1.0, "PUT", "K1"))
    elif product_id == "2.4": values = (("short_call_k1", -1.0, "CALL", "K1"), ("long_call_k2", 1.0, "CALL", "K2"))
    elif product_id == "3.1": values = (("long_call", 1.0, "CALL", "K"), ("long_put", 1.0, "PUT", "K"))
    elif product_id == "3.2": values = (("long_put_kp", 1.0, "PUT", "Kp"), ("long_call_kc", 1.0, "CALL", "Kc"))
    elif product_id == "3.3": values = (("long_call_k1", 1.0, "CALL", "K1"), ("short_call_k2", -2.0, "CALL", "K2"), ("long_call_k3", 1.0, "CALL", "K3"))
    elif product_id == "3.4": values = (("long_call_k1", 1.0, "CALL", "K1"), ("short_call_k2", -1.0, "CALL", "K2"), ("short_call_k3", -1.0, "CALL", "K3"), ("long_call_k4", 1.0, "CALL", "K4"))
    else: raise ValueError(f"{product_id}没有欧式组合腿定义")
    return tuple((label, float(weight), call_put, float(terms[strike])) for label, weight, call_put, strike in values)


def _vanilla_leg(
    label: str,
    weight: float,
    call_put: str,
    strike: float,
    maturity_years: float,
    basis: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "weight": float(weight),
        "structure": "EUROPEAN_VANILLA",
        "method": "BLACK_SCHOLES",
        "label": label,
        "contract": {
            "strike": float(strike),
            "maturity_years": float(maturity_years),
            "call_put": call_put,
            "basis": dict(basis),
        },
    }


def _fixed_cashflow_leg(
    label: str,
    weight: float,
    amount: float,
    maturity_years: float,
    basis: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "weight": float(weight),
        "structure": "FIXED_CASHFLOW",
        "method": "DISCOUNTED_CASHFLOW",
        "label": label,
        "contract": {
            "amount": float(amount),
            "maturity_years": float(maturity_years),
            "basis": dict(basis),
        },
    }


def _binary_leg(
    label: str,
    weight: float,
    call_put: str,
    strike: float,
    payout_type: str,
    payout: float,
    maturity_years: float,
    basis: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "weight": float(weight),
        "structure": "BINARY",
        "method": "BINARY_ANALYTIC",
        "label": label,
        "contract": {
            "strike": float(strike),
            "maturity_years": float(maturity_years),
            "call_put": call_put,
            "payout_type": payout_type,
            "payout": float(payout),
            "basis": dict(basis),
        },
    }


def _barrier_leg(
    label: str,
    weight: float,
    call_put: str,
    strike: float,
    barrier: float,
    knock: str,
    rebate: float,
    rebate_at_hit: bool,
    maturity_years: float,
    basis: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "weight": float(weight),
        "structure": "BARRIER",
        "method": "REINER_RUBINSTEIN",
        "label": label,
        "contract": {
            "strike": float(strike),
            "barrier": float(barrier),
            "maturity_years": float(maturity_years),
            "call_put": call_put,
            "knock": knock,
            "monitoring": "Daily",
            "rebate": float(rebate),
            "rebate_at_hit": bool(rebate_at_hit),
            "basis": dict(basis),
        },
    }


def _barrier_contract(
    contract: ResolvedContract,
    maturity_years: float,
    basis: Mapping[str, Any],
) -> dict[str, Any]:
    product_id = contract.product_id
    terms = contract.terms
    call_put = "CALL" if product_id in {"4.1", "4.2", "4.3", "4.4"} else "PUT"
    knock = "Out" if product_id in {"4.1", "4.2", "4.5", "4.6"} else "In"
    barrier_key = "H_KO" if knock == "Out" else "H_KI"
    return {
        "strike": float(terms["K"]),
        "barrier": float(terms[barrier_key]),
        "maturity_years": float(maturity_years),
        "call_put": call_put,
        "knock": knock,
        "monitoring": "Daily",
        "rebate": 0.0,
        "rebate_at_hit": True,
        "basis": dict(basis),
    }


def _binary_contract(
    contract: ResolvedContract,
    maturity_years: float,
    basis: Mapping[str, Any],
) -> dict[str, Any]:
    product_id = contract.product_id
    cash = product_id in {"5.1", "5.2"}
    return {
        "strike": float(contract.terms["K"]),
        "maturity_years": float(maturity_years),
        "call_put": "CALL" if product_id in {"5.1", "5.3"} else "PUT",
        "payout_type": "Cash-or-Nothing" if cash else "Asset-or-Nothing",
        "payout": float(contract.terms.get("A", 0.0)),
        "basis": dict(basis),
    }


def _sharkfin_contract(
    contract: ResolvedContract,
    maturity_years: float,
    basis: Mapping[str, Any],
) -> dict[str, Any]:
    terms = contract.terms
    return {
        "strike": float(terms["K"]),
        "barrier": float(terms["H_KO"]),
        "maturity_years": float(maturity_years),
        "call_put": "CALL" if contract.product_id == "9.5" else "PUT",
        "knock": "Out",
        "monitoring": "Daily",
        "rebate": float(terms["eta"]) * float(terms.get("S0", 100.0)),
        "rebate_at_hit": True,
        "basis": dict(basis),
    }


def _analytical_portfolio_legs(
    contract: ResolvedContract,
    maturity_years: float,
    basis: Mapping[str, Any],
) -> list[dict[str, Any]]:
    product_id = contract.product_id
    terms = contract.terms
    if product_id in _EXACT_MAPPINGS and product_id not in {"1.1", "1.2"}:
        return [
            _vanilla_leg(label, weight, call_put, strike, maturity_years, basis)
            for label, weight, call_put, strike in _portfolio_legs(contract)
        ]
    if product_id in {"5.5", "5.6"}:
        rebate_at_hit = product_id == "5.5"
        common = {
            "call_put": "CALL",
            "strike": float(terms.get("S0", 100.0)),
            "barrier": float(terms["Htouch"]),
            "knock": "Out",
            "rebate_at_hit": rebate_at_hit,
            "maturity_years": maturity_years,
            "basis": basis,
        }
        touch_legs = [
            _barrier_leg("rebated_barrier", 1.0, rebate=float(terms["A"]), **common),
            _barrier_leg("zero_rebate_barrier", -1.0, rebate=0.0, **common),
        ]
        if product_id == "5.5":
            return touch_legs
        return [
            _fixed_cashflow_leg(
                "maturity_cashflow",
                1.0,
                float(terms["A"]),
                maturity_years,
                basis,
            ),
            *(
                {**leg, "weight": -float(leg["weight"])}
                for leg in touch_legs
            ),
        ]
    if product_id in {"6.1", "6.2", "6.3"}:
        spot = float(terms.get("S0", 100.0))
        barrier = float(terms["B"])
        legs: list[dict[str, Any]] = []
        if product_id == "6.1":
            legs.append(_vanilla_leg("long_call", 1.0, "CALL", spot, maturity_years, basis))
        elif product_id == "6.2":
            cap_strike = spot * (1.0 + float(terms["r_cap"]))
            legs.extend((
                _vanilla_leg("long_call", 1.0, "CALL", spot, maturity_years, basis),
                _vanilla_leg("short_cap_call", -1.0, "CALL", cap_strike, maturity_years, basis),
                _barrier_leg("long_knock_in_cap_call", 1.0, "CALL", cap_strike, barrier, "In", 0.0, True, maturity_years, basis),
            ))
        else:
            alpha = float(terms["alpha"])
            legs.extend((
                _vanilla_leg("participation_call", alpha, "CALL", spot, maturity_years, basis),
                _barrier_leg("knock_in_call_top_up", 1.0 - alpha, "CALL", spot, barrier, "In", 0.0, True, maturity_years, basis),
            ))
        legs.append(_barrier_leg("short_knock_in_put", -1.0, "PUT", spot, barrier, "In", 0.0, True, maturity_years, basis))
        return legs
    if product_id in {"9.2", "9.3"}:
        spot = float(terms.get("S0", 100.0))
        lower = float(terms["K1"])
        upper = float(terms["K2"])
        alpha = float(terms["alpha"])
        if product_id == "9.3":
            return [
                _vanilla_leg("long_call_k1", 1.0 / spot, "CALL", lower, maturity_years, basis),
                _vanilla_leg(
                    "short_call_k2",
                    -(1.0 - alpha) / spot,
                    "CALL",
                    upper,
                    maturity_years,
                    basis,
                ),
            ]
        floor_return = (lower - spot) / spot
        return [
            _binary_leg("floor_cash", floor_return, "PUT", lower, "Cash-or-Nothing", 1.0, maturity_years, basis),
            _binary_leg("middle_asset", 1.0 / spot, "CALL", lower, "Asset-or-Nothing", 0.0, maturity_years, basis),
            _binary_leg("middle_cash", -1.0, "CALL", lower, "Cash-or-Nothing", 1.0, maturity_years, basis),
            _binary_leg("upper_asset_adjustment", (alpha - 1.0) / spot, "CALL", upper, "Asset-or-Nothing", 0.0, maturity_years, basis),
            _binary_leg("upper_cash_adjustment", 1.0 - alpha, "CALL", upper, "Cash-or-Nothing", 1.0, maturity_years, basis),
        ]
    raise ValueError(f"{product_id}没有解析组合腿定义")


def _analytical_quantity(contract: ResolvedContract) -> float:
    terms = contract.terms
    if contract.product_id == "9.3":
        return float(terms["N"])
    if contract.product_id in {"1.1", "4.1", "4.2", "4.3", "4.4"}:
        return float(terms.get("n_C", 1.0))
    if contract.product_id in {"1.2", "4.5", "4.6", "4.7", "4.8"}:
        return float(terms.get("n_P", 1.0))
    if contract.product_id in {"5.3", "5.4"}:
        return float(terms.get("asset_unit", 1.0))
    return 1.0


def _initial_cashflow(
    contract: ResolvedContract,
    quantity: float,
    *,
    valuation_date: str | None = None,
) -> float:
    """兼容测试入口：只返回当前估值日尚应计入价值的起始现金流。"""

    cashflow = contractual_initial_cashflow(contract, quantity)
    start_value = contract.identity.get("contract_start_date")
    if valuation_date is None or start_value in {None, ""} or str(valuation_date) == str(start_value):
        return cashflow
    if date.fromisoformat(str(valuation_date)) < date.fromisoformat(str(start_value)):
        raise ValueError("valuation_date不得早于contract_start_date")
    return 0.0


def _contract_with_maturity(
    contract: ResolvedContract,
    maturity_years: float,
    *,
    remaining_years: float | None = None,
    trading_calendar: Mapping[str, Any] | None = None,
    as_of: date | None = None,
    completed_observations: int = 0,
    replay_history: bool = False,
) -> ResolvedContract:
    """Create an immutable remaining-term view for controlled time revalue."""
    remaining_tenor = float(maturity_years if remaining_years is None else remaining_years)
    scenario_identity, scenario_schedules, scenario_maturity = _scenario_contract_window(
        contract,
        as_of=as_of,
        remaining_years=remaining_tenor,
        total_maturity_years=float(maturity_years),
        trading_calendar=trading_calendar,
    )
    terms = {**contract.terms, "T": scenario_maturity}
    # n_obs is an independent contractual term. The frozen Core schedules
    # own its dates; neither the headline nor a time-risk node may replace
    # it with the number of calendar sessions falling inside T.
    if contract.product_id == "7.1" and completed_observations and not replay_history:
        monitor = dict(terms.get("monitor", {}))
        monitor["Q_acc"] = bind_accumulator_remaining_count(
            str(monitor["Q_acc"]), int(terms["n_obs"]) - int(completed_observations),
        )
        terms["monitor"] = monitor
    hedge_schedule = terms.get("hedge_schedule")
    if not replay_history and trading_calendar is not None and as_of is not None and isinstance(hedge_schedule, (tuple, list)):
        session_values = trading_calendar.get("sessions")
        if isinstance(session_values, (tuple, list)):
            target = as_of.toordinal() + round(remaining_tenor * 365.0)
            available_months = _completed_monthly_observations(session_values, as_of, target)
            terms["hedge_schedule"] = [
                item for item in hedge_schedule
                if isinstance(item, (tuple, list)) and len(item) == 2 and int(item[0]) <= available_months
            ]
    return replace(
        contract,
        identity=scenario_identity,
        terms=terms,
        resolved_schedules=scenario_schedules,
        path_case_applicability=None,
    )


def _scenario_contract_window(
    contract: ResolvedContract,
    *,
    as_of: date | None,
    remaining_years: float,
    total_maturity_years: float,
    trading_calendar: Mapping[str, Any] | None,
) -> tuple[dict[str, Any], dict[str, Any], float]:
    """Bind an internal time-risk node to one self-consistent contract window.

    The public ResolvedContract remains unchanged. A materially shorter time
    node is a hypothetical contract scenario, so its civil end, registered
    tenor and frozen observation schedules must move together. The original
    legal end is retained for the headline value and its adjacent last-market-
    session endpoint.
    """
    identity = dict(contract.identity)
    schedules = {
        key: {
            "selector": value["selector"],
            "status": value["status"],
            "dates": list(value["dates"]),
        }
        for key, value in contract.resolved_schedules.items()
    }
    start_value = identity.get("contract_start_date")
    end_value = identity.get("contract_end_date")
    if as_of is None or start_value in {None, ""} or end_value in {None, ""}:
        return identity, schedules, float(total_maturity_years)

    contract_start = date.fromisoformat(str(start_value))
    legal_end = date.fromisoformat(str(end_value))
    scenario_remaining_days = round(float(remaining_years) * 365.0)
    if scenario_remaining_days <= 0:
        raise ValueError("风险期限节点必须晚于估值日")
    scenario_end = as_of + timedelta(days=scenario_remaining_days)
    if contract.terms.get("n_obs") is not None:
        # Count-based observation dates are frozen independently of T.
        # A time-risk node changes the settlement clock, not which contract
        # observations feed the payoff or its contractual denominator.
        identity["contract_end_date"] = scenario_end.isoformat()
        return identity, schedules, float(total_maturity_years)
    # The exchange's last observation can precede a civil maturity across a
    # weekend or holiday closure. Keep the legal end only for that exact,
    # injected terminal session; never infer an arbitrary calendar tolerance.
    terminal_session = _last_calendar_session_on_or_before(trading_calendar, legal_end)
    if scenario_end == legal_end or scenario_end == terminal_session:
        return identity, schedules, float(contract.terms["T"])

    if scenario_end >= legal_end:
        return identity, schedules, float(contract.terms["T"])
    if scenario_end <= contract_start:
        raise ValueError("风险期限节点不得早于合同起始日")

    identity["contract_end_date"] = scenario_end.isoformat()
    for key, snapshot in schedules.items():
        selected = [value for value in snapshot["dates"] if str(value) <= scenario_end.isoformat()]
        if not selected:
            raise ValueError("风险期限节点早于首个冻结观察日")
        snapshot["dates"] = selected
    scenario_maturity = (scenario_end - contract_start).days / 365.0
    return identity, schedules, scenario_maturity


def _last_calendar_session_on_or_before(
    trading_calendar: Mapping[str, Any] | None,
    legal_end: date,
) -> date | None:
    if not isinstance(trading_calendar, Mapping):
        return None
    raw_sessions = trading_calendar.get("sessions")
    if isinstance(raw_sessions, (str, bytes)) or not isinstance(raw_sessions, (tuple, list)):
        return None
    parsed_sessions = (date.fromisoformat(str(value)) for value in raw_sessions)
    sessions = [value for value in parsed_sessions if value <= legal_end]
    return max(sessions, default=None)


def _completed_monthly_observations(sessions: object, as_of: date, target_ordinal: int) -> int:
    """只从注入sessions识别已经完整结束的观察月份。"""
    parsed = [date.fromisoformat(str(value)) for value in sessions]
    return sum(
        1
        for index, value in enumerate(parsed[:-1])
        if as_of <= value and value.toordinal() <= target_ordinal
        and (parsed[index + 1].year, parsed[index + 1].month) != (value.year, value.month)
    )


def _as_of(value: str | None) -> date:
    if value is None:
        return date.today()
    try:
        return date.fromisoformat(value)
    except ValueError as error:
        raise ValueError("valuation_date必须为YYYY-MM-DD") from error


def _is_midlife(observed_state: ObservedContractState, start_value: object) -> bool:
    return (
        observed_state.lifecycle_status == "active"
        and observed_state.valuation_date is not None
        and start_value is not None
        and date.fromisoformat(observed_state.valuation_date) > date.fromisoformat(str(start_value))
    )


def _valuation_after_contract_start(observed_state: ObservedContractState, start_value: object) -> bool:
    return (
        observed_state.valuation_date is not None
        and start_value is not None
        and date.fromisoformat(observed_state.valuation_date) > date.fromisoformat(str(start_value))
    )


def _verified_state_sessions(
    market_snapshot: Mapping[str, Any],
    trading_calendar: Mapping[str, Any] | None,
) -> tuple[str, ...]:
    """Combine verified history and future-calendar sessions for state bounds."""
    data_ref = market_snapshot.get("data_ref")
    coverage = data_ref.get("coverage") if isinstance(data_ref, Mapping) else None
    history = coverage.get("sessions") if isinstance(coverage, Mapping) else None
    future = trading_calendar.get("sessions") if isinstance(trading_calendar, Mapping) else None
    if isinstance(history, (str, bytes)) or not isinstance(history, (tuple, list)):
        raise ProductNotAvailable("存续路径状态校验需要已验证DataAssetRef.coverage.sessions")
    values = {str(value) for value in history}
    if isinstance(future, (tuple, list)):
        values.update(str(value) for value in future)
    return tuple(sorted(values))


def _number(value: Any, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{label}必须为数值")
    result = float(value)
    if result <= 0.0:
        raise ValueError(f"{label}必须为正数")
    return result


def _asset_number(value: Any, asset: str, label: str) -> float:
    if isinstance(value, Mapping):
        if asset not in value:
            raise ValueError(f"{label}必须逐一覆盖合同标的")
        value = value[asset]
    result = _number(value, label) if label in {"spot", "volatility"} else float(value)
    return result


def _two_asset_correlation(value: Any) -> float:
    if value is None:
        return 0.0
    if not isinstance(value, (tuple, list)) or len(value) != 2 or any(
        not isinstance(row, (tuple, list)) or len(row) != 2 for row in value
    ):
        raise ProductNotAvailable("Worst-Of解析定价需要2×2相关矩阵")
    if float(value[0][0]) != 1.0 or float(value[1][1]) != 1.0 or float(value[0][1]) != float(value[1][0]):
        raise ProductNotAvailable("Worst-Of相关矩阵必须对称且对角线为1")
    correlation = float(value[0][1])
    if not -1.0 < correlation < 1.0:
        raise ProductNotAvailable("Worst-Of解析定价的相关系数必须严格位于-1和1之间")
    return correlation


def _analytical_settlement_maturity(contract, trading_calendar, as_of: date, remaining_years: float) -> float:
    """cash(T) uses the frozen civil end, not the registry's fractional tenor."""
    identity, _, _ = _scenario_contract_window(
        contract, as_of=as_of, remaining_years=remaining_years,
        total_maturity_years=float(contract.terms["T"]), trading_calendar=trading_calendar,
    )
    end = identity.get("contract_end_date")
    return (date.fromisoformat(str(end)) - as_of).days / 365.0 if end else float(remaining_years)


def _analytical_observation_times(
    trading_calendar: Mapping[str, Any] | None,
    as_of: date,
    maturity_years: float,
    *,
    contract: ResolvedContract | None = None,
) -> tuple[float, ...]:
    if trading_calendar is None:
        raise ProductNotAvailable("观察型解析结构必须使用冻结交易日历")
    if contract is not None:
        _, schedules, _ = _scenario_contract_window(
            contract, as_of=as_of, remaining_years=maturity_years,
            total_maturity_years=float(contract.terms["T"]), trading_calendar=trading_calendar,
        )
        selected = tuple(
            date.fromisoformat(str(value))
            for value in schedules["Orange"]["dates"]
            if date.fromisoformat(str(value)) >= as_of
        )
        return tuple((value - as_of).days / 365.0 for value in selected)
    target = as_of + timedelta(days=round(float(maturity_years) * 365.0))
    selected = tuple(
        date.fromisoformat(str(value))
        for value in trading_calendar["sessions"]
        if as_of <= date.fromisoformat(str(value)) <= target
    )
    if len(selected) < 2 or (target - selected[-1]).days > 14:
        raise ProductNotAvailable("冻结交易日历未覆盖解析结构的完整期限")
    return tuple((value - as_of).days / 365.0 for value in selected)


def _validated_trading_calendar(value: Any, *, as_of: date, demo_mode: bool) -> dict[str, Any]:
    """MC的日期只能来自受控资产，不以weekday或等距网格补造。"""
    if not isinstance(value, Mapping):
        raise ProductNotAvailable("离散路径MC必须提供独立trading-calendar资产的显式交易sessions")
    calendar_id = value.get("calendar_id")
    calendar_revision = value.get("calendar_revision")
    sessions = value.get("sessions")
    if not isinstance(calendar_id, str) or not calendar_id.strip() or not isinstance(calendar_revision, str) or not calendar_revision.strip():
        raise ProductNotAvailable("离散路径MC交易日历必须包含calendar_id和calendar_revision")
    if isinstance(sessions, (str, bytes)) or not isinstance(sessions, (tuple, list)):
        raise ProductNotAvailable("离散路径MC必须提供显式交易sessions，禁止weekday推断")
    parsed: list[date] = []
    try:
        parsed = [date.fromisoformat(str(item)) for item in sessions]
    except ValueError as error:
        raise ProductNotAvailable("离散路径MC交易sessions必须为YYYY-MM-DD") from error
    if not parsed or parsed != sorted(parsed) or len(set(parsed)) != len(parsed):
        raise ProductNotAvailable("离散路径MC交易sessions必须严格递增且不重复")
    if as_of not in parsed:
        raise ProductNotAvailable("估值日必须是注入交易日历中的真实session")
    verified_cn = bool(value.get("verified_cn_sessions"))
    source = str(value.get("source") or "")
    if not demo_mode and (not verified_cn or source != "host-injected"):
        raise ProductNotAvailable("正式离散路径MC必须注入经验证的中国交易sessions DataAssetRef")
    return {
        "calendar_id": calendar_id,
        "calendar_revision": calendar_revision,
        "sessions": tuple(item.isoformat() for item in parsed),
        "verified_cn_sessions": verified_cn,
        "source": source,
    }


__all__ = ("ProductMapping", "ProductNotAvailable", "ProductPricingAdapter", "product_mapping")
