"""OptionReg共享合同引擎。

本模块只承担合同解析、受限公式解释与路径现金流结算。Payoffer、Pricer与
Backtester均调用它，但三者不相互调用。禁止在此处下载行情、修改默认SVG或把
PricingConfig、BacktestConfig写回OptionReg。
"""

from __future__ import annotations

import ast
import re
from copy import deepcopy
from dataclasses import dataclass, field
from functools import lru_cache
from math import inf
from pathlib import Path
from types import MappingProxyType
from typing import Any, Callable, Mapping, Sequence

import numpy as np
import pandas as pd

from runtime.knowledger.registry_loader import (
    RegistryLoadError,
    get_default_registry_path,
    load_registry as _load_registry,
    load_term_catalog as _load_term_catalog,
)
from .contract_types import deep_freeze, deep_thaw


DEFAULT_REGISTRY_PATH = get_default_registry_path()
_RULE_TERM_KEYS = frozenset({"monitor", "pricing_methods", "constraints", "derived_terms"})
# 这些字段是产品定义的一部分，而不是本次交易可报价、可覆盖的经济参数。
# 它们仍保留在ResolvedContract.terms中，供下游展示和审计读取。
_IMMUTABLE_TERM_KEYS = frozenset({"margin_call", "N", "Nvar", "Nvega", "G"})
# 不可覆盖不等于不可进入公式：N/Nvar虽是内部固定100基准，仍须由解释器绑定。
_STATIC_TERM_KEYS = _RULE_TERM_KEYS | frozenset({"margin_call"})
_ALLOWED_PRODUCT_KEYS = frozenset({"identity", "terms", "paths"})
_ALLOWED_IDENTITY_KEYS = frozenset({"product_id", "name_zh", "entry_status", "rule_revision"})
_ALLOWED_PATH_KEYS = frozenset({"condition", "cases"})
_ALLOWED_CASE_KEYS = frozenset({"domain", "pnl"})
_OBSERVATION_TERM_KEYS = frozenset({"O_KO", "O_KI", "Oc", "Otouch", "Orange", "Ovar", "Ohedge", "Oreset"})
_FORMULA_FUNCTIONS = frozenset({
    "min", "max", "first_time", "first_time_after", "first_time_before", "first_time_levels", "first_time_below_levels", "schedule_levels", "step_levels",
    "first_time_below_schedule", "first_observation_on_or_after", "terminal_event_time", "reset_knockout_time", "effective_hedge_time",
    "first_value", "count", "count_until", "exact_observation_count", "observation_ordinal",
    "realized_variance", "accumulated_quantity", "schedule_between", "schedule_matches_ratios",
    "period_count", "linear_schedule", "terminal_schedule", "truncate_schedule",
    "is_monthly_schedule", "require_maturity_observation", "cash",
})
_SETTLEMENT_VARIABLES = frozenset({"S_t", "S_T", "W_t", "W_T", "r_T", "u", "T_contract", "inf"})
_NORMALIZED_PRICE_BASE = 100.0
_PAYOFF_SCALE_TERM_KEYS = frozenset({"N", "Nvar"})
# A contractual maturity can fall inside the Spring Festival closure.  The
# injected exchange calendar is authoritative, and the last real session can
# then be up to two calendar weeks before the contractual date.  The path MC
# builder rejects anything beyond this same bound, so the evaluator must use
# the matching tolerance instead of treating a valid pre-holiday session as a
# truncated contract.
_MATURITY_TIME_TOLERANCE = 14.0 / 365.0
_NUMERIC_COMPARISON_RTOL = 1e-12
_NUMERIC_COMPARISON_ATOL = 1e-12
_MAX_FORMULA_CHARS = 4096
_MAX_FORMULA_NODES = 256
_MAX_FORMULA_DEPTH = 64
_MAX_POWER_EXPONENT = 32.0
_MAX_FORMULA_ITEMS = 100_000
_MAX_ABS_FORMULA_VALUE = 1e100
_STRUCTURAL_PAYOFF_CALENDAR_ID = "payoffer-structural-candidate"
_STRUCTURAL_PAYOFF_CALENDAR_REVISION = "structural-candidate"
_STRUCTURAL_PAYOFF_SESSION_COUNT = 800


@lru_cache(maxsize=1)
def _shared_term_catalog() -> Mapping[str, Any]:
    """复用Loader已验证的只读目录，避免每个绘图采样点复制完整Registry。"""
    return _load_term_catalog(DEFAULT_REGISTRY_PATH)


def counted_observation_key(terms: Mapping[str, Any]) -> str | None:
    """Locate the registered observation selector governed by n_obs."""
    if terms.get("n_obs") is None:
        return None
    symbols: set[str] = set()
    for formula in terms.get("monitor", {}).values():
        tree = _validated_formula_tree(formula)
        if not any(isinstance(node, ast.Name) and node.id == "n_obs" for node in ast.walk(tree)):
            continue
        symbols.update(
            node.slice.id for node in ast.walk(tree)
            if isinstance(node, ast.Subscript) and isinstance(node.value, ast.Name)
            and node.value.id == "S_t" and isinstance(node.slice, ast.Name)
        )
    catalog = _shared_term_catalog()
    keys = [key for key in _OBSERVATION_TERM_KEYS & set(terms) if catalog[key]["symbol"] in symbols]
    if len(keys) != 1:
        raise ContractResolutionError("n_obs必须唯一绑定合同monitor中的观察日程")
    return keys[0]


def _schedule_snapshot(
    terms: Mapping[str, Any],
    trading_dates: Sequence[Any] | None = None,
    *,
    contract_start_date: Any = None,
    contract_end_date: Any = None,
) -> dict[str, Any]:
    """冻结合同登记的观察选择器。

    含观察条款的正式合同必须在Host已验证的交易日历上解析，不能只冻结selector。
    """
    keys = sorted(_OBSERVATION_TERM_KEYS & set(terms))
    if trading_dates is None:
        if keys:
            raise ContractResolutionError("含观察条款的正式合同必须提供Host验证交易日历")
        return {}
    dates = pd.to_datetime(list(trading_dates), errors="coerce")
    if not len(dates) or dates.isna().any() or not dates.is_monotonic_increasing or dates.has_duplicates:
        raise ContractResolutionError("合同交易日历须为非空、严格递增的有效日期")
    dates = _contract_calendar_window(
        terms,
        dates,
        contract_start_date=contract_start_date,
        contract_end_date=contract_end_date,
    )
    times = np.arange(len(dates), dtype=float)
    count_key = counted_observation_key(terms)
    if count_key is not None:
        count = int(terms["n_obs"])
        positions = _schedule_positions(terms[count_key], times, dates)
        if len(positions) < count:
            raise ContractResolutionError(f"Host验证交易日历仅覆盖{len(positions)}次观察，不足合同n_obs={count}")
        dates = dates[:positions[count - 1] + 1]
        times = np.arange(len(dates), dtype=float)
    snapshot = {
        key: {
            "selector": deep_thaw(terms[key]),
            "status": "resolved",
            "dates": [dates[position].date().isoformat() for position in _schedule_positions(terms[key], times, dates)],
        }
        for key in keys
    }
    if any(not value["dates"] for value in snapshot.values()):
        raise ContractResolutionError("Host验证交易日历未解析出全部合同观察日")
    return snapshot


def derive_contract_end_date(contract_start_date: object, tenor_years: object) -> str:
    """Return the civil maturity used by every formal contract compiler."""

    start = pd.to_datetime(contract_start_date, errors="coerce")
    if pd.isna(start):
        raise ContractResolutionError("identity.contract_start_date不是有效日期")
    if (
        isinstance(tenor_years, bool)
        or not isinstance(tenor_years, (int, float, np.number))
        or not np.isfinite(float(tenor_years))
        or float(tenor_years) <= 0
    ):
        raise ContractResolutionError("合同缺少可用于冻结到期日的有效期限T")
    return (start + pd.Timedelta(days=round(float(tenor_years) * 365.0))).date().isoformat()


def _frozen_civil_maturity_time(identity: Mapping[str, Any]) -> float | None:
    """Return the frozen civil settlement time when both identity dates exist."""

    start_value = identity.get("contract_start_date")
    end_value = identity.get("contract_end_date")
    if start_value not in {None, ""} and end_value not in {None, ""}:
        start = pd.to_datetime(start_value, errors="coerce")
        end = pd.to_datetime(end_value, errors="coerce")
        if pd.isna(start) or pd.isna(end) or end <= start:
            raise ContractResolutionError("合同起止日无法形成有效ACT/365结算时点")
        return float((end.normalize() - start.normalize()).days / 365.0)
    return None


def _contract_maturity_time(identity: Mapping[str, Any], terms: Mapping[str, Any]) -> float:
    """Return the economic maturity used to validate one settlement path."""

    frozen = _frozen_civil_maturity_time(identity)
    if frozen is not None:
        return frozen
    tenor = terms.get("T")
    if (
        isinstance(tenor, bool)
        or not isinstance(tenor, (int, float, np.number))
        or not np.isfinite(float(tenor))
        or float(tenor) <= 0.0
    ):
        raise ContractResolutionError("合同缺少可用于解释结算时点的有效期限T")
    return float(tenor)


def _contract_calendar_window(
    terms: Mapping[str, Any],
    dates: pd.DatetimeIndex,
    *,
    contract_start_date: Any,
    contract_end_date: Any,
) -> pd.DatetimeIndex:
    """Limit an authenticated exchange calendar to the contract's lifespan."""

    if contract_start_date in {None, ""}:
        return dates
    start = pd.to_datetime(contract_start_date, errors="coerce")
    if pd.isna(start):
        raise ContractResolutionError("identity.contract_start_date不是有效日期")
    if terms.get("n_obs") is not None:
        # Counted observation windows close on the nth selected real session.
        # Civil cashflow maturity remains independently frozen from T.
        return dates[dates >= start]
    if contract_end_date not in {None, ""}:
        end = pd.to_datetime(contract_end_date, errors="coerce")
        if pd.isna(end):
            raise ContractResolutionError("identity.contract_end_date不是有效日期")
    else:
        end = pd.to_datetime(
            derive_contract_end_date(contract_start_date, terms.get("T")),
        )
    if end < start:
        raise ContractResolutionError("identity.contract_end_date不得早于contract_start_date")
    window = dates[(dates >= start) & (dates <= end)]
    if not len(window):
        raise ContractResolutionError("Host验证交易日历未覆盖合同起始日至到期日")
    if (end - window[-1]).days > round(_MATURITY_TIME_TOLERANCE * 365.0):
        raise ContractResolutionError("Host验证交易日历未覆盖合同到期日前最后交易日")
    return window


def _require_observation_calendar_identity(identity: Mapping[str, Any], terms: Mapping[str, Any]) -> None:
    if not (_OBSERVATION_TERM_KEYS & set(terms)):
        return
    for key in ("calendar_id", "calendar_revision"):
        value = identity.get(key)
        if not isinstance(value, str) or not value.strip():
            raise ContractResolutionError(f"含观察条款的正式合同必须提供identity.{key}")


def _validate_resolved_schedule_snapshot(
    terms: Mapping[str, Any], schedules: Mapping[str, Any], identity: Mapping[str, Any],
) -> None:
    keys = frozenset(_OBSERVATION_TERM_KEYS & set(terms))
    if not keys:
        if schedules:
            raise ContractResolutionError("无观察条款的ResolvedContract.resolved_schedules必须为空")
        return
    _require_observation_calendar_identity(identity, terms)
    if set(schedules) != keys:
        raise ContractResolutionError("ResolvedContract.resolved_schedules必须逐一覆盖观察条款")
    for key in sorted(keys):
        value = schedules[key]
        if not isinstance(value, Mapping) or set(value) != {"selector", "status", "dates"}:
            raise ContractResolutionError(f"ResolvedContract.resolved_schedules.{key}外形无效")
        if value["status"] != "resolved" or deep_thaw(value["selector"]) != deep_thaw(terms[key]):
            raise ContractResolutionError(f"ResolvedContract.resolved_schedules.{key}必须为对应selector的resolved日程")
        dates = value["dates"]
        if not isinstance(dates, Sequence) or isinstance(dates, (str, bytes)) or not dates:
            raise ContractResolutionError(f"ResolvedContract.resolved_schedules.{key}必须包含真实观察日")
        try:
            parsed = tuple(pd.Timestamp(item).date().isoformat() for item in dates)
        except (TypeError, ValueError) as error:
            raise ContractResolutionError(f"ResolvedContract.resolved_schedules.{key}包含无效观察日") from error
        if tuple(dates) != parsed or parsed != tuple(sorted(parsed)) or len(set(parsed)) != len(parsed):
            raise ContractResolutionError(f"ResolvedContract.resolved_schedules.{key}观察日必须为严格递增的ISO日期")


def _economic_identity(identity: Mapping[str, Any]) -> dict[str, Any]:
    """仅保留决定合同现金流语义的身份字段，排除展示与运行追踪字段。"""
    keys = (
        "product_id", "rule_revision", "underlyings", "currency", "contract_start_date", "contract_end_date",
        "reference_prices", "price_convention", "calendar_id", "calendar_revision",
    )
    return {key: identity.get(key) for key in keys}


class ContractResolutionError(ValueError):
    """OptionReg、合同条款或运行输入不满足约束。"""


class FormulaError(ValueError):
    """受限公式包含不允许的语法、变量或无法解释的经济表达。"""


@dataclass(frozen=True)
class Cashflow:
    """持有方在合同时间轴上的一笔现金流。"""

    time: float
    amount: float

    def to_dict(self) -> dict[str, float]:
        return {"time": float(self.time), "amount": float(self.amount)}


class CashflowBundle:
    """使 ``cash(...) + cash(...)`` 成为受限公式中的唯一现金流组合写法。"""

    def __init__(self, flows: Sequence[Cashflow] = ()) -> None:
        self.flows = tuple(flows)

    def __add__(self, other: object) -> "CashflowBundle":
        if isinstance(other, CashflowBundle):
            return CashflowBundle((*self.flows, *other.flows))
        raise FormulaError("现金流表达式只能以cash(...)相加")

    def __radd__(self, other: object) -> "CashflowBundle":
        if other == 0:
            return self
        return self.__add__(other)


@dataclass(frozen=True)
class _ReachabilityInterval:
    lower: float = -inf
    upper: float = inf
    lower_closed: bool = False
    upper_closed: bool = False

    def intersection(self, other: "_ReachabilityInterval") -> "_ReachabilityInterval | None":
        lower = max(self.lower, other.lower)
        upper = min(self.upper, other.upper)
        lower_closed = (
            self.lower_closed if self.lower > other.lower
            else other.lower_closed if other.lower > self.lower
            else self.lower_closed and other.lower_closed
        )
        upper_closed = (
            self.upper_closed if self.upper < other.upper
            else other.upper_closed if other.upper < self.upper
            else self.upper_closed and other.upper_closed
        )
        if lower < upper or (lower == upper and lower_closed and upper_closed):
            return _ReachabilityInterval(lower, upper, lower_closed, upper_closed)
        return None


_ALL_REACHABILITY = (_ReachabilityInterval(),)
_APPLICABILITY_KEYS = frozenset({"path_index", "case_index", "status", "reason_code"})
_APPLICABILITY_REASONS = frozenset({
    "terminal_constraints_satisfiable",
    "terminal_constraints_contradict",
    "terminal_schedule_event_unavailable",
})


def _derive_path_case_applicability(
    identity: Mapping[str, Any],
    terms: Mapping[str, Any],
    paths: Sequence[Mapping[str, Any]],
    resolved_schedules: Mapping[str, Any],
) -> tuple[dict[str, Any], ...]:
    """Freeze calendar-dependent path/case reachability for one contract.

    OptionReg remains the owner of the complete product path set.  This
    projection proves only terminal contradictions implied by the same frozen
    schedules and monitor formulas used by the evaluator; unknown history
    conditions remain active and must still be witnessed by consumers.
    """

    variables = bind_term_symbols(terms, _shared_term_catalog())
    monitor_rules = _terminal_monitor_rules(identity, terms, resolved_schedules, variables)
    result: list[dict[str, Any]] = []
    for path_offset, path in enumerate(paths):
        path_intervals, path_reasons = _terminal_formula_intervals(
            str(path["condition"]), variables, monitor_rules,
        )
        for case_offset, case in enumerate(path["cases"]):
            case_intervals, case_reasons = _terminal_formula_intervals(
                str(case["domain"]), variables, monitor_rules,
            )
            combined = _intersect_interval_sets(path_intervals, case_intervals)
            reasons = path_reasons | case_reasons
            if combined:
                status = "active"
                reason_code = "terminal_constraints_satisfiable"
            else:
                status = "inactive"
                reason_code = (
                    "terminal_schedule_event_unavailable"
                    if "terminal_schedule_event_unavailable" in reasons
                    else "terminal_constraints_contradict"
                )
            result.append({
                "path_index": path_offset + 1,
                "case_index": case_offset + 1,
                "status": status,
                "reason_code": reason_code,
            })
    return tuple(result)


def _validate_path_case_applicability(
    value: Sequence[Mapping[str, Any]],
    paths: Sequence[Mapping[str, Any]],
) -> tuple[dict[str, Any], ...]:
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise ContractResolutionError("ResolvedContract.path_case_applicability必须为数组")
    expected_refs = {
        (path_index, case_index)
        for path_index, path in enumerate(paths, start=1)
        for case_index, _case in enumerate(path["cases"], start=1)
    }
    records: list[dict[str, Any]] = []
    seen: set[tuple[int, int]] = set()
    for raw in value:
        if not isinstance(raw, Mapping) or set(raw) != _APPLICABILITY_KEYS:
            raise ContractResolutionError("path_case_applicability记录字段无效")
        path_index = raw.get("path_index")
        case_index = raw.get("case_index")
        status = raw.get("status")
        reason_code = raw.get("reason_code")
        ref = (path_index, case_index)
        if (
            isinstance(path_index, bool) or not isinstance(path_index, int)
            or isinstance(case_index, bool) or not isinstance(case_index, int)
            or ref not in expected_refs or ref in seen
            or status not in {"active", "inactive"}
            or reason_code not in _APPLICABILITY_REASONS
        ):
            raise ContractResolutionError("path_case_applicability记录值无效")
        seen.add(ref)
        records.append(dict(raw))
    if seen != expected_refs:
        raise ContractResolutionError("path_case_applicability必须逐一覆盖全部产品path/case")
    return tuple(records)


def _terminal_monitor_rules(
    identity: Mapping[str, Any],
    terms: Mapping[str, Any],
    schedules: Mapping[str, Any],
    variables: Mapping[str, Any],
) -> dict[str, tuple[str, bool, bool, tuple[_ReachabilityInterval, ...]]]:
    monitor = terms.get("monitor", {})
    if not isinstance(monitor, Mapping):
        return {}
    end_date = str(identity.get("contract_end_date") or "")
    catalog = _shared_term_catalog()
    dates_by_symbol: dict[str, tuple[str, ...]] = {}
    for key, snapshot in schedules.items():
        entry = catalog.get(key)
        dates = snapshot.get("dates") if isinstance(snapshot, Mapping) else None
        if isinstance(entry, Mapping) and isinstance(entry.get("symbol"), str) and isinstance(dates, Sequence):
            dates_by_symbol[str(entry["symbol"])] = tuple(str(item) for item in dates)
    rules: dict[str, tuple[str, bool, bool, tuple[_ReachabilityInterval, ...]]] = {}
    for name, expression in monitor.items():
        try:
            node = ast.parse(str(expression), mode="eval").body
        except SyntaxError:
            continue
        if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Name) or not node.args:
            continue
        function = node.func.id
        if function not in {"terminal_event_time", "first_time", "first_time_after", "first_time_before"}:
            continue
        event = _terminal_event_intervals(
            node.args[0],
            variables,
            {symbol: len(dates) for symbol, dates in dates_by_symbol.items()},
        )
        if event is None:
            continue
        schedule_symbol, event_intervals = event
        dates = dates_by_symbol.get(schedule_symbol, ())
        same_terminal_price = bool(dates) and (not end_date or dates[-1] == end_date)
        eligible = same_terminal_price
        terminal_position = len(dates) - 1 if eligible else -1
        kind = "terminal" if function == "terminal_event_time" else "history"
        if function == "first_time_after" and eligible:
            try:
                skipped = int(evaluate_formula(ast.unparse(node.args[1]), variables))
            except (IndexError, TypeError, ValueError, FormulaError):
                eligible = False
            else:
                eligible = terminal_position >= skipped
        if function == "first_time_before":
            eligible = False
        rules[str(name)] = (kind, eligible, same_terminal_price, event_intervals)
    return rules


def _terminal_event_intervals(
    node: ast.AST,
    variables: Mapping[str, Any],
    terminal_ordinals: Mapping[str, int],
) -> tuple[str, tuple[_ReachabilityInterval, ...]] | None:
    if not isinstance(node, ast.Compare) or len(node.ops) != 1 or len(node.comparators) != 1:
        return None
    left, operator, right = node.left, node.ops[0], node.comparators[0]
    left_series = _scheduled_series(left)
    right_series = _scheduled_series(right)
    if (left_series is None) == (right_series is None):
        return None
    if left_series is None:
        left, right = right, left
        operator = _reverse_comparison(operator)
        left_series = right_series
    assert left_series is not None
    series_name, schedule_symbol = left_series
    axis = {"S_t": "S_T", "W_t": "W_T"}.get(series_name)
    if axis is None:
        return None
    terminal_ordinal = terminal_ordinals.get(schedule_symbol)
    bound_node = right
    scheduled_level = _terminal_schedule_level(
        bound_node,
        expected_series=left_series,
        terminal_ordinal=terminal_ordinal,
        variables=variables,
    )
    if scheduled_level is not None:
        bound_node = ast.Constant(scheduled_level)
    intervals = _axis_comparison_intervals(ast.Name(id=axis), operator, bound_node, variables, axis)
    return (schedule_symbol, intervals) if intervals is not None else None


def _terminal_schedule_level(
    node: ast.AST,
    *,
    expected_series: tuple[str, str],
    terminal_ordinal: int | None,
    variables: Mapping[str, Any],
) -> float | None:
    """Resolve schedule_levels at the frozen terminal observation ordinal."""

    if (
        terminal_ordinal is None
        or not isinstance(node, ast.Call)
        or not isinstance(node.func, ast.Name)
        or node.func.id != "schedule_levels"
        or len(node.args) != 2
        or _scheduled_series(node.args[0]) != expected_series
    ):
        return None
    try:
        schedule = evaluate_formula(ast.unparse(node.args[1]), variables)
    except FormulaError:
        return None
    if not isinstance(schedule, Sequence) or isinstance(schedule, (str, bytes)):
        return None
    matches: list[float] = []
    for item in schedule:
        if not isinstance(item, Sequence) or isinstance(item, (str, bytes)) or len(item) != 2:
            return None
        ordinal, level = item
        if ordinal == terminal_ordinal:
            try:
                matches.append(float(level))
            except (TypeError, ValueError):
                return None
    if len(matches) != 1 or not np.isfinite(matches[0]):
        return None
    return matches[0]


def _scheduled_series(node: ast.AST) -> tuple[str, str] | None:
    if not isinstance(node, ast.Subscript) or not isinstance(node.value, ast.Name):
        return None
    slice_node = node.slice
    if not isinstance(slice_node, ast.Name):
        return None
    return node.value.id, slice_node.id


def _terminal_formula_intervals(
    expression: str,
    variables: Mapping[str, Any],
    monitor_rules: Mapping[str, tuple[str, bool, bool, tuple[_ReachabilityInterval, ...]]],
) -> tuple[tuple[_ReachabilityInterval, ...], frozenset[str]]:
    try:
        root = ast.parse(expression, mode="eval").body
    except SyntaxError:
        return _ALL_REACHABILITY, frozenset()
    return _terminal_node_intervals(root, variables, monitor_rules)


def _terminal_node_intervals(
    node: ast.AST,
    variables: Mapping[str, Any],
    monitor_rules: Mapping[str, tuple[str, bool, bool, tuple[_ReachabilityInterval, ...]]],
) -> tuple[tuple[_ReachabilityInterval, ...], frozenset[str]]:
    if isinstance(node, ast.BoolOp):
        parts = [_terminal_node_intervals(item, variables, monitor_rules) for item in node.values]
        if isinstance(node.op, ast.Or):
            nonempty = tuple(interval for intervals, _ in parts for interval in intervals)
            return nonempty, frozenset().union(*(reasons for _, reasons in parts)) if not nonempty else frozenset()
        intervals = _ALL_REACHABILITY
        reasons: frozenset[str] = frozenset()
        for following, following_reasons in parts:
            intervals = _intersect_interval_sets(intervals, following)
            reasons |= following_reasons
        return intervals, reasons
    if not isinstance(node, ast.Compare):
        return _ALL_REACHABILITY, frozenset()
    intervals = _ALL_REACHABILITY
    reasons: frozenset[str] = frozenset()
    left = node.left
    for operator, right in zip(node.ops, node.comparators):
        piece, piece_reasons = _comparison_terminal_constraint(
            left, operator, right, variables, monitor_rules,
        )
        intervals = _intersect_interval_sets(intervals, piece)
        reasons |= piece_reasons
        left = right
    return intervals, reasons


def _comparison_terminal_constraint(
    left: ast.AST,
    operator: ast.cmpop,
    right: ast.AST,
    variables: Mapping[str, Any],
    monitor_rules: Mapping[str, tuple[str, bool, bool, tuple[_ReachabilityInterval, ...]]],
) -> tuple[tuple[_ReachabilityInterval, ...], frozenset[str]]:
    monitor_name, state = _monitor_infinity_comparison(left, operator, right, monitor_rules)
    if monitor_name is not None and state is not None:
        kind, eligible, same_terminal_price, event_intervals = monitor_rules[monitor_name]
        if state == "finite" and kind == "terminal":
            if not eligible:
                return (), frozenset({"terminal_schedule_event_unavailable"})
            return (event_intervals, frozenset()) if same_terminal_price else (_ALL_REACHABILITY, frozenset())
        if state == "infinite" and eligible and same_terminal_price:
            return _complement_intervals(event_intervals), frozenset()
        return _ALL_REACHABILITY, frozenset()
    monitor_name = _monitor_maturity_equality(left, operator, right, monitor_rules)
    if monitor_name is not None:
        _kind, eligible, same_terminal_price, event_intervals = monitor_rules[monitor_name]
        if not eligible or not same_terminal_price:
            return (), frozenset({"terminal_schedule_event_unavailable"})
        return event_intervals, frozenset()
    direct = _axis_comparison_intervals(left, operator, right, variables, "S_T")
    return (direct, frozenset()) if direct is not None else (_ALL_REACHABILITY, frozenset())


def _monitor_infinity_comparison(
    left: ast.AST,
    operator: ast.cmpop,
    right: ast.AST,
    monitor_rules: Mapping[str, Any],
) -> tuple[str | None, str | None]:
    if isinstance(left, ast.Name) and left.id in monitor_rules and isinstance(right, ast.Name) and right.id == "inf":
        if isinstance(operator, ast.Eq):
            return left.id, "infinite"
        if isinstance(operator, ast.Lt):
            return left.id, "finite"
    if isinstance(right, ast.Name) and right.id in monitor_rules and isinstance(left, ast.Name) and left.id == "inf":
        if isinstance(operator, ast.Eq):
            return right.id, "infinite"
        if isinstance(operator, ast.Gt):
            return right.id, "finite"
    return None, None


def _monitor_maturity_equality(
    left: ast.AST,
    operator: ast.cmpop,
    right: ast.AST,
    monitor_rules: Mapping[str, Any],
) -> str | None:
    if not isinstance(operator, ast.Eq):
        return None
    if (
        isinstance(left, ast.Name)
        and left.id in monitor_rules
        and isinstance(right, ast.Name)
        and right.id in {"T", "T_contract"}
    ):
        return left.id
    if (
        isinstance(right, ast.Name)
        and right.id in monitor_rules
        and isinstance(left, ast.Name)
        and left.id in {"T", "T_contract"}
    ):
        return right.id
    return None


def _axis_comparison_intervals(
    left: ast.AST,
    operator: ast.cmpop,
    right: ast.AST,
    variables: Mapping[str, Any],
    axis: str,
) -> tuple[_ReachabilityInterval, ...] | None:
    left_axis = isinstance(left, ast.Name) and left.id == axis
    right_axis = isinstance(right, ast.Name) and right.id == axis
    if left_axis == right_axis:
        return None
    bound_node = right if left_axis else left
    effective_operator = operator if left_axis else _reverse_comparison(operator)
    try:
        bound = float(evaluate_formula(ast.unparse(bound_node), variables))
    except (TypeError, ValueError, FormulaError):
        return None
    if not np.isfinite(bound):
        return None
    if isinstance(effective_operator, ast.Gt):
        return (_ReachabilityInterval(lower=bound, lower_closed=False),)
    if isinstance(effective_operator, ast.GtE):
        return (_ReachabilityInterval(lower=bound, lower_closed=True),)
    if isinstance(effective_operator, ast.Lt):
        return (_ReachabilityInterval(upper=bound, upper_closed=False),)
    if isinstance(effective_operator, ast.LtE):
        return (_ReachabilityInterval(upper=bound, upper_closed=True),)
    if isinstance(effective_operator, ast.Eq):
        return (_ReachabilityInterval(bound, bound, True, True),)
    return None


def _reverse_comparison(operator: ast.cmpop) -> ast.cmpop:
    if isinstance(operator, ast.Gt):
        return ast.Lt()
    if isinstance(operator, ast.GtE):
        return ast.LtE()
    if isinstance(operator, ast.Lt):
        return ast.Gt()
    if isinstance(operator, ast.LtE):
        return ast.GtE()
    return operator


def _intersect_interval_sets(
    left: Sequence[_ReachabilityInterval],
    right: Sequence[_ReachabilityInterval],
) -> tuple[_ReachabilityInterval, ...]:
    return tuple(
        merged
        for first in left
        for second in right
        if (merged := first.intersection(second)) is not None
    )


def _complement_intervals(
    intervals: Sequence[_ReachabilityInterval],
) -> tuple[_ReachabilityInterval, ...]:
    if len(intervals) != 1:
        return _ALL_REACHABILITY
    interval = intervals[0]
    result: list[_ReachabilityInterval] = []
    if interval.lower != -inf:
        result.append(_ReachabilityInterval(upper=interval.lower, upper_closed=not interval.lower_closed))
    if interval.upper != inf:
        result.append(_ReachabilityInterval(lower=interval.upper, lower_closed=not interval.upper_closed))
    return tuple(result)


@dataclass(frozen=True)
class ResolvedContract:
    """三个计算模块共同读取的本次已解析合同完整快照。"""

    identity: Mapping[str, Any]
    terms: Mapping[str, Any]
    term_sources: Mapping[str, str]
    paths: tuple[Mapping[str, Any], ...]
    resolved_schedules: Mapping[str, Any] | None = None
    path_case_applicability: tuple[Mapping[str, Any], ...] | None = None

    def __post_init__(self) -> None:
        terms = deep_freeze(self.terms)
        identity_value = deep_thaw(self.identity)
        if not isinstance(identity_value, Mapping):
            raise ContractResolutionError("ResolvedContract.identity必须为对象")
        if (
            identity_value.get("contract_start_date") not in {None, ""}
            and identity_value.get("contract_end_date") in {None, ""}
        ):
            identity_value["contract_end_date"] = derive_contract_end_date(
                identity_value["contract_start_date"], terms.get("T"),
            )
        identity = deep_freeze(identity_value)
        sources = deep_freeze(self.term_sources)
        paths = tuple(deep_freeze(path) for path in self.paths)
        if set(sources) != set(terms) or any(value not in {"default", "override", "derived"} for value in sources.values()):
            raise ContractResolutionError("term_sources必须逐一覆盖terms且来源值有效")
        if not paths:
            raise ContractResolutionError("ResolvedContract.paths不能为空")
        schedules = deep_freeze(self.resolved_schedules or _schedule_snapshot(terms))
        _validate_resolved_schedule_snapshot(terms, schedules, identity)
        expected_applicability = _derive_path_case_applicability(identity, terms, paths, schedules)
        if self.path_case_applicability is not None:
            supplied_applicability = _validate_path_case_applicability(
                self.path_case_applicability, paths,
            )
            if deep_thaw(supplied_applicability) != deep_thaw(expected_applicability):
                raise ContractResolutionError("ResolvedContract.path_case_applicability与冻结日历及monitor语义不一致")
        applicability = deep_freeze(expected_applicability)
        object.__setattr__(self, "identity", identity)
        object.__setattr__(self, "terms", terms)
        object.__setattr__(self, "term_sources", sources)
        object.__setattr__(self, "paths", paths)
        object.__setattr__(self, "resolved_schedules", schedules)
        object.__setattr__(self, "path_case_applicability", applicability)

    @property
    def product_id(self) -> str:
        return str(self.identity["product_id"])

    @property
    def name_zh(self) -> str:
        return str(self.identity["name_zh"])

    @property
    def underlyings(self) -> tuple[str, ...]:
        return tuple(self.identity["underlyings"])

    @property
    def currency(self) -> str:
        return str(self.identity["currency"])

    @property
    def active_path_case_refs(self) -> tuple[tuple[int, int], ...]:
        """Return zero-based path/case pairs valid for this frozen contract."""

        return tuple(
            (int(item["path_index"]) - 1, int(item["case_index"]) - 1)
            for item in self.path_case_applicability or ()
            if item["status"] == "active"
        )

    def to_dict(self) -> dict[str, Any]:
        """返回本次运行冻结的完整合同快照。"""
        return {
            "identity": deep_thaw(self.identity),
            "terms": deep_thaw(self.terms),
            "term_sources": deep_thaw(self.term_sources),
            "paths": deep_thaw(self.paths),
            "resolved_schedules": deep_thaw(self.resolved_schedules),
            "path_case_applicability": deep_thaw(self.path_case_applicability),
        }

    def to_protocol_dict(self) -> dict[str, Any]:
        return self.to_dict()

    def to_controlled_snapshot(self) -> dict[str, Any]:
        """返回仅供Core与受控ModuleRun输入使用的完整合同快照。

        该快照可由``ResolvedContract(**snapshot)``严格复原。它不是公开展示
        对象；页面和公开工件必须使用各模块显式定义的display projection。
        """
        return self.to_protocol_dict()

    @classmethod
    def from_controlled_snapshot(cls, snapshot: Mapping[str, Any]) -> "ResolvedContract":
        """严格恢复Core受控快照，拒绝展示投影或不完整对象。"""
        if not isinstance(snapshot, Mapping):
            raise ContractResolutionError("Core受控ResolvedContract快照必须是对象")
        if "path_case_applicability" not in snapshot:
            raise ContractResolutionError("Core受控ResolvedContract快照缺少path_case_applicability")
        try:
            return cls(**dict(snapshot))
        except (TypeError, ValueError, ContractResolutionError) as error:
            raise ContractResolutionError(f"Core受控ResolvedContract快照无效：{error}") from error


@dataclass(frozen=True)
class PayoffInput:
    """Po唯一输入：已解析合同。"""

    contract: ResolvedContract


@dataclass(frozen=True)
class PayoffEvaluation:
    """某条价格路径上的唯一结算结果。"""

    selected_path: int
    selected_case: int
    monitor_values: dict[str, Any]
    cashflows: tuple[Cashflow, ...]

    @property
    def pnl(self) -> float:
        return float(sum(flow.amount for flow in self.cashflows))

    def to_dict(self) -> dict[str, Any]:
        return {
            "selected_path": self.selected_path,
            "selected_case": self.selected_case,
            "monitor_values": _json_scalar_map(self.monitor_values),
            "cashflows": [flow.to_dict() for flow in self.cashflows],
            "pnl": self.pnl,
        }


class ContractEvaluationCancelled(RuntimeError):
    """批量合同解释在路径边界收到取消信号。"""


@dataclass(frozen=True)
class PreparedContractEvaluator:
    """绑定合同与价格网格的只读解释器准备结果。"""

    contract: ResolvedContract
    asset_ids: tuple[str, ...]
    valuation_date: str
    times: tuple[float, ...]
    dates: tuple[pd.Timestamp, ...] | None
    _base_variables: Mapping[str, Any] = field(repr=False, compare=False)
    _schedule_cache: Mapping[int, tuple[np.ndarray, np.ndarray]] = field(repr=False, compare=False)


@dataclass(frozen=True)
class BatchPayoffEvaluation:
    """保持输入路径顺序的逐路径合同解释结果。"""

    evaluations: tuple[PayoffEvaluation, ...]


class EventVector:
    def __init__(self, values: Any, times: Sequence[float], *, includes_path_endpoint: bool = False) -> None:
        self.values = np.asarray(values, dtype=bool)
        self.times = np.asarray(times, dtype=float)
        self.includes_path_endpoint = bool(includes_path_endpoint)
        if self.values.shape != self.times.shape:
            raise FormulaError("路径布尔指标与时间网格长度不一致")

    def __and__(self, other: object) -> "EventVector":
        other_vector = _event_vector(other, self.times)
        return EventVector(
            self.values & other_vector.values,
            self.times,
            includes_path_endpoint=self.includes_path_endpoint and other_vector.includes_path_endpoint,
        )

    def __or__(self, other: object) -> "EventVector":
        other_vector = _event_vector(other, self.times)
        return EventVector(
            self.values | other_vector.values,
            self.times,
            includes_path_endpoint=self.includes_path_endpoint and other_vector.includes_path_endpoint,
        )

    def __invert__(self) -> "EventVector":
        return EventVector(
            ~self.values,
            self.times,
            includes_path_endpoint=self.includes_path_endpoint,
        )


def _numeric_relation(left: object, right: object, relation: str) -> Any | None:
    """以统一容差解释合同数值边界；字符串、无穷和其他对象保持原生比较。"""
    if isinstance(left, (bool, np.bool_)) or isinstance(right, (bool, np.bool_)):
        return None
    try:
        lhs = np.asarray(left, dtype=float)
        rhs = np.asarray(right, dtype=float)
    except (TypeError, ValueError):
        return None
    if not np.issubdtype(lhs.dtype, np.number) or not np.issubdtype(rhs.dtype, np.number):
        return None
    lhs, rhs = np.broadcast_arrays(lhs, rhs)
    if not np.isfinite(lhs).all() or not np.isfinite(rhs).all():
        return None
    tolerance = _NUMERIC_COMPARISON_ATOL + _NUMERIC_COMPARISON_RTOL * np.maximum(np.abs(lhs), np.abs(rhs))
    if relation == "lt":
        result = lhs < rhs - tolerance
    elif relation == "le":
        result = lhs <= rhs + tolerance
    elif relation == "gt":
        result = lhs > rhs + tolerance
    elif relation == "ge":
        result = lhs >= rhs - tolerance
    elif relation == "eq":
        result = np.abs(lhs - rhs) <= tolerance
    elif relation == "ne":
        result = np.abs(lhs - rhs) > tolerance
    else:
        raise FormulaError("不允许的比较运算")
    return bool(result.item()) if result.ndim == 0 else result


class ObservedValues:
    def __init__(
        self,
        values: Sequence[float],
        times: Sequence[float],
        ordinals: Sequence[int] | None = None,
        *,
        includes_path_endpoint: bool = False,
        covers_complete_schedule: bool = False,
        frozen_schedule: bool = False,
    ) -> None:
        self.values = np.asarray(values, dtype=float)
        self.times = np.asarray(times, dtype=float)
        self.includes_path_endpoint = bool(includes_path_endpoint)
        self.covers_complete_schedule = bool(covers_complete_schedule)
        self.frozen_schedule = bool(frozen_schedule)
        if self.values.shape != self.times.shape:
            raise FormulaError("观察价格与时间网格长度不一致")
        self.ordinals = np.arange(1, len(self.values) + 1, dtype=int) if ordinals is None else np.asarray(ordinals, dtype=int)
        if self.ordinals.shape != self.values.shape or (self.ordinals <= 0).any() or len(np.unique(self.ordinals)) != len(self.ordinals):
            raise FormulaError("观察序号必须与观察价格一一对应且为不重复正整数")

    def _compare(self, other: object, relation: str, op) -> EventVector:
        result = _numeric_relation(self.values, other, relation)
        return EventVector(
            op(self.values, other) if result is None else result,
            self.times,
            includes_path_endpoint=self.includes_path_endpoint,
        )

    def __lt__(self, other: object) -> EventVector:
        return self._compare(other, "lt", np.less)

    def __le__(self, other: object) -> EventVector:
        return self._compare(other, "le", np.less_equal)

    def __gt__(self, other: object) -> EventVector:
        return self._compare(other, "gt", np.greater)

    def __ge__(self, other: object) -> EventVector:
        return self._compare(other, "ge", np.greater_equal)

    def __eq__(self, other: object) -> EventVector:  # type: ignore[override]
        return self._compare(other, "eq", np.equal)

    def __ne__(self, other: object) -> EventVector:  # type: ignore[override]
        return self._compare(other, "ne", np.not_equal)


class PriceSeries:
    """安全公式可索引的价格序列，支持 ``S_t[O_out]``。"""

    def __init__(
        self,
        values: Sequence[float],
        times: Sequence[float],
        dates: Sequence[Any] | None = None,
        *,
        schedule_cache: Mapping[int, tuple[np.ndarray, np.ndarray]] | None = None,
    ) -> None:
        self.values = np.asarray(values, dtype=float)
        self.times = np.asarray(times, dtype=float)
        self.dates = pd.to_datetime(list(dates)) if dates is not None else None
        self._schedule_cache = schedule_cache or {}
        if self.values.ndim != 1 or self.values.shape != self.times.shape:
            raise FormulaError("价格路径必须是一维且与时间网格等长")

    def __getitem__(self, schedule: object) -> ObservedValues:
        cached = self._schedule_cache.get(id(schedule))
        if cached is None:
            positions = _schedule_positions(schedule, self.times, self.dates)
            ordinals = _schedule_observation_ordinals(schedule, self.times, self.dates, positions)
        else:
            positions, ordinals = cached
        return ObservedValues(
            self.values[positions],
            self.times[positions],
            ordinals,
            includes_path_endpoint=bool(len(positions) and positions[-1] == len(self.values) - 1),
            covers_complete_schedule=(
                isinstance(schedule, _FrozenObservationSchedule)
                and len(positions) == len(schedule.dates)
            ),
            frozen_schedule=isinstance(schedule, _FrozenObservationSchedule),
        )


@dataclass(frozen=True)
class _FrozenObservationSchedule:
    """ResolvedContract中已冻结的真实观察日，不允许由运行路径重新推导。"""

    dates: tuple[pd.Timestamp, ...]


@dataclass(frozen=True)
class PricePath:
    """完整单标的或多标的真实市场价格路径，首维为合同时间。

    ``values``保存交易日收盘价，不应由调用方预先归一化；解释器以identity中的
    ``reference_prices``将其映射为内部100基准价格水平。若合同将
    ``observation_price``设为``open``、``high``或``low``，调用方必须在
    ``price_fields``中逐一提供同形状的对应OHLC序列；禁止静默回退至收盘价。
    """

    values: np.ndarray
    times: np.ndarray
    asset_ids: tuple[str, ...]
    dates: tuple[Any, ...] | None = None
    price_fields: Mapping[str, np.ndarray] | None = None
    times_explicit: bool = True

    @classmethod
    def from_values(
        cls,
        values: Sequence[float] | Sequence[Sequence[float]] | np.ndarray,
        *,
        times: Sequence[float] | None = None,
        asset_ids: Sequence[str] = ("UNDERLYING",),
        dates: Sequence[Any] | None = None,
        price_fields: Mapping[str, Sequence[float] | Sequence[Sequence[float]] | np.ndarray] | None = None,
    ) -> "PricePath":
        data = np.asarray(values, dtype=float)
        if data.ndim == 1:
            data = data[:, None]
        if data.ndim != 2 or data.shape[0] < 2 or not np.isfinite(data).all() or (data < 0).any() or (data[0] <= 0).any():
            raise ContractResolutionError("价格路径必须含至少两个非负价格观察点，且首个观察点必须严格为正")
        assets = tuple(str(item) for item in asset_ids)
        if len(assets) != data.shape[1]:
            raise ContractResolutionError("asset_ids数量与价格路径列数不一致")
        grid = np.asarray(times if times is not None else np.linspace(0.0, 1.0, data.shape[0]), dtype=float)
        if grid.shape != (data.shape[0],) or grid[0] < 0.0 or np.any(np.diff(grid) <= 0):
            raise ContractResolutionError("时间网格须非负且严格递增")
        normalized_dates: tuple[Any, ...] | None = None
        if dates is not None:
            if len(dates) != data.shape[0]:
                raise ContractResolutionError("日期网格与价格路径长度不一致")
            date_index = pd.to_datetime(list(dates), errors="coerce")
            if date_index.isna().any() or not date_index.is_monotonic_increasing or date_index.has_duplicates:
                raise ContractResolutionError("日期网格须为严格递增的有效交易日")
            normalized_dates = tuple(date_index)
        fields: dict[str, np.ndarray] = {}
        for source, source_values in dict(price_fields or {}).items():
            if source not in {"open", "high", "low"}:
                raise ContractResolutionError("price_fields仅支持open、high或low；收盘价请使用values")
            source_data = np.asarray(source_values, dtype=float)
            if source_data.ndim == 1:
                source_data = source_data[:, None]
            if source_data.shape != data.shape or not np.isfinite(source_data).all() or (source_data < 0).any() or (source_data[0] <= 0).any():
                raise ContractResolutionError(f"price_fields.{source}必须与收盘价路径同形状且均为非负，首个观察点严格为正")
            fields[source] = source_data
        return cls(data, grid, assets, normalized_dates, fields or None, times is not None)

    def values_for(self, source: str) -> np.ndarray:
        """返回合同指定的原始观察价，缺少OHLC字段时明确拒绝执行。"""
        if source == "close":
            return self.values
        available = (self.price_fields or {}).get(source)
        if available is None:
            raise ContractResolutionError(f"合同观察价格为{source}，但价格路径未提供price_fields.{source}")
        return np.asarray(available, dtype=float)


def load_registry(path: str | Path = DEFAULT_REGISTRY_PATH) -> dict[str, Any]:
    """经唯一Registry Loader读取OptionReg，不提供旧字段兼容层。"""
    try:
        return _load_registry(path)
    except RegistryLoadError as error:
        raise ContractResolutionError(str(error)) from error


def get_product(product_id: str, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    reg = dict(registry) if registry is not None else load_registry()
    try:
        product = reg["products"][str(product_id)]
    except (KeyError, TypeError) as error:
        raise ContractResolutionError(f"OptionReg不存在产品{product_id}") from error
    if not isinstance(product, Mapping):
        raise ContractResolutionError(f"产品{product_id}不是有效对象")
    return deepcopy(dict(product))


def overridable_term_keys(
    product_id: str,
    registry: Mapping[str, Any] | None = None,
) -> frozenset[str]:
    """Return the current Catalog terms accepted by ``resolve_contract``.

    The result is derived from the same product and rule sets used by contract
    resolution.  The immutable set exposes policy membership without implying
    a UI order or exposing the engine's internal policy constants.
    """

    source_registry = registry if registry is not None else load_registry()
    product = get_product(product_id, source_registry)
    terms = product.get("terms")
    if not isinstance(terms, Mapping):
        raise ContractResolutionError(f"产品{product_id}缺少有效terms")
    derived = terms.get("derived_terms", {})
    if not isinstance(derived, Mapping):
        raise ContractResolutionError(f"产品{product_id}.derived_terms必须为对象")
    return frozenset(
        str(key)
        for key in terms
        if key not in _RULE_TERM_KEYS
        and key not in _IMMUTABLE_TERM_KEYS
        and key not in derived
    )


def verify_current_product_rule(
    contract: ResolvedContract,
    registry: Mapping[str, Any],
) -> ResolvedContract:
    """Verify that a run snapshot was compiled from the current product rule."""

    if not isinstance(contract, ResolvedContract) or not isinstance(registry, Mapping):
        raise ContractResolutionError("产品规则校验需要ResolvedContract与当前OptionReg")
    try:
        current_product = registry["products"][contract.product_id]
        current_revision = current_product["identity"]["rule_revision"]
    except (KeyError, TypeError) as error:
        raise ContractResolutionError("ResolvedContract对应的当前产品规则不存在") from error
    if contract.identity.get("rule_revision") != current_revision:
        raise ContractResolutionError("ResolvedContract.rule_revision不是当前产品规则")
    identity_fields = {
        "contract_id", "underlyings", "currency", "contract_start_date", "contract_end_date",
        "reference_prices", "price_convention", "calendar_id", "calendar_revision",
    }
    identity = {key: deep_thaw(value) for key, value in contract.identity.items() if key in identity_fields}
    overrides = {
        key: deep_thaw(contract.terms[key])
        for key, source in contract.term_sources.items()
        if source == "override"
    }
    expected = _resolve_contract(
        contract.product_id,
        identity=identity,
        term_overrides=overrides,
        registry=registry,
        frozen_resolved_schedules=contract.resolved_schedules,
    )
    for label, actual, declared in (
        ("identity", _economic_identity(contract.identity), _economic_identity(expected.identity)),
        ("terms", contract.terms, expected.terms),
        ("term_sources", contract.term_sources, expected.term_sources),
        ("paths", contract.paths, expected.paths),
        (
            "path_case_applicability",
            contract.path_case_applicability,
            expected.path_case_applicability,
        ),
    ):
        if deep_thaw(actual) != deep_thaw(declared):
            raise ContractResolutionError(f"ResolvedContract.{label}不属于当前产品规则")
    return contract


def _apply_constraint_bound_terms(
    terms: dict[str, Any],
    constraints: Any,
    catalog: Mapping[str, Any],
    *,
    explicit_overrides: frozenset[str],
) -> dict[str, str]:
    """联动单一``字段 == 表达式``约束中的非独立左值。

    OptionReg早期用constraints表达了一部分派生条款。Desk页面现在把这些字段标成
    只读；当用户修改右侧独立条款时，合同编译器必须同步左值，否则一个合理修改
    会被旧默认值反向阻断。重复定义同一左值的联立约束不在这里猜解，仍由后续
    严格校验拒绝不一致的组合。
    """

    if not isinstance(constraints, (list, tuple)):
        return {}
    symbol_to_key = {
        str(metadata.get("symbol") or key): str(key)
        for key in terms
        for metadata in (catalog.get(key),)
        if isinstance(metadata, Mapping)
    }
    assignments: dict[str, list[str]] = {}
    for raw in constraints:
        try:
            root = ast.parse(str(raw), mode="eval").body
        except SyntaxError:
            continue
        if (
            not isinstance(root, ast.Compare)
            or len(root.ops) != 1
            or not isinstance(root.ops[0], ast.Eq)
            or len(root.comparators) != 1
            or not isinstance(root.left, ast.Name)
        ):
            continue
        key = symbol_to_key.get(root.left.id)
        if key is not None and key in terms:
            assignments.setdefault(key, []).append(ast.unparse(root.comparators[0]))

    sources: dict[str, str] = {}
    for _ in range(max(1, len(assignments))):
        changed = False
        variables = bind_term_symbols(terms, catalog)
        for key, expressions in assignments.items():
            if len(expressions) != 1 or key in explicit_overrides:
                continue
            value = evaluate_formula(expressions[0], variables)
            _validate_terms({key: value}, catalog)
            if deep_thaw(terms[key]) != deep_thaw(value):
                terms[key] = value
                changed = True
                sources[key] = "derived"
            variables[str(catalog[key].get("symbol") or key)] = value
        if not changed:
            break
    return sources


def _resolve_contract(
    product_id: str,
    *,
    identity: Mapping[str, Any] | None = None,
    term_overrides: Mapping[str, Any] | None = None,
    registry: Mapping[str, Any] | None = None,
    registry_path: str | Path = DEFAULT_REGISTRY_PATH,
    trading_dates: Sequence[Any] | None = None,
    frozen_resolved_schedules: Mapping[str, Any] | None = None,
) -> ResolvedContract:
    """以默认条款加本次覆盖生成唯一合同；未完整录入的产品拒绝运行。"""
    source_registry = deepcopy(dict(registry)) if registry is not None else load_registry(registry_path)
    product = get_product(product_id, source_registry)
    issues = validate_product_spec(str(product_id), product, source_registry["term_catalog"])
    if issues:
        raise ContractResolutionError(f"产品{product_id}的OptionReg校验失败：{'；'.join(issues)}")
    product_identity = product["identity"]
    if not product_identity["entry_status"]:
        raise ContractResolutionError(f"产品{product_id}尚未完整录入，entry_status=False，Po、P、BT禁止执行")

    supplied_identity = dict(identity or {})
    unknown_identity = set(supplied_identity) - {
        "contract_id", "underlyings", "currency", "contract_start_date", "contract_end_date",
        "reference_prices", "price_convention", "calendar_id",
        "calendar_revision",
    }
    if unknown_identity:
        raise ContractResolutionError(f"合同identity含未知字段：{','.join(sorted(unknown_identity))}")
    underlyings = tuple(str(item).strip() for item in supplied_identity.get("underlyings", ("DEFAULT.UNDERLYING",)))
    if not underlyings or any(not item for item in underlyings) or len(set(underlyings)) != len(underlyings):
        raise ContractResolutionError("underlyings必须为无重复的非空标的代码序列")
    source_terms = product["terms"]
    references = supplied_identity.get("reference_prices")
    if references is not None:
        if not isinstance(references, Mapping) or set(references) != set(underlyings):
            raise ContractResolutionError("reference_prices必须逐一覆盖underlyings")
        references = {str(key): _positive_number(value, f"reference_prices.{key}") for key, value in references.items()}

    defaults = {key: deepcopy(value) for key, value in source_terms.items() if key not in _RULE_TERM_KEYS}
    # Payoffer、Pricer和Backtester共用这份合同解释器。历史OptionReg保留的N/Nvar
    # 只是旧资料的规模示例；运行期一律固定为无货币单位的100点标准化结算基准。
    # 不改写资料库或默认示例资产，亦不让客户名义本金进入本次合同。
    for key in _PAYOFF_SCALE_TERM_KEYS & set(defaults):
        defaults[key] = _NORMALIZED_PRICE_BASE
    overrides = dict(term_overrides or {})
    attempted_scale_override = set(overrides) & _PAYOFF_SCALE_TERM_KEYS
    if attempted_scale_override:
        raise ContractResolutionError(
            f"内部标准化基准100不可覆盖：{','.join(sorted(attempted_scale_override))}"
        )
    attempted_immutable = set(overrides) & _IMMUTABLE_TERM_KEYS
    if attempted_immutable:
        raise ContractResolutionError(f"结构性条款不可由用户直接覆盖：{','.join(sorted(attempted_immutable))}")
    derived_keys = set(source_terms.get("derived_terms", {}))
    attempted_derived = set(overrides) & derived_keys
    if attempted_derived:
        raise ContractResolutionError(f"派生条款不可由用户直接覆盖：{','.join(sorted(attempted_derived))}")
    unknown = set(overrides) - set(defaults)
    if unknown:
        raise ContractResolutionError(f"本次条款覆盖含未登记字段：{','.join(sorted(unknown))}")
    price_convention = str(supplied_identity.get("price_convention") or "normalized_100")
    # normalized_100合同的公开坐标始终以S0=100为基准。执行价、障碍等
    # price条款直接使用OptionReg登记值或用户覆盖值，不再以最低执行价
    # 作为第二套展示基准。absolute_market合同同样保留Host冻结的真实条款。
    final_terms = {**defaults, **overrides}
    _validate_terms(final_terms, source_registry["term_catalog"])
    if "S0Vec" in final_terms:
        required_assets = len(final_terms["S0Vec"])
        if required_assets < 2:
            raise ContractResolutionError(f"{product_id}为多标的结构，S0Vec至少须含两个标的基准")
        if len(underlyings) != required_assets:
            raise ContractResolutionError(
                f"{product_id}为多标的结构，underlyings数量必须与S0Vec长度{required_assets}一致"
            )
    if price_convention == "normalized_100" and references is None:
        # A normalized contract's S0/S0Vec is its declared price coordinate,
        # not an implicit market quote.  Freeze that coordinate explicitly so
        # every formal calculator receives the same complete identity.  An
        # absolute-market contract still requires a Host-supplied quote.
        references = _normalized_reference_prices(final_terms, underlyings)
    if price_convention == "normalized_100":
        _validate_normalized_price_base(final_terms)
    elif price_convention == "absolute_market":
        if references is None:
            raise ContractResolutionError("absolute_market价格口径必须提供reference_prices")
        expected = np.asarray([references[asset] for asset in underlyings], dtype=float)
        if "S0Vec" in final_terms and not np.allclose(np.asarray(final_terms["S0Vec"], dtype=float), expected, rtol=0.0, atol=1e-12):
            raise ContractResolutionError("absolute_market价格口径下S0Vec必须逐一等于reference_prices")
        if "S0" in final_terms and (len(expected) != 1 or not np.isclose(float(final_terms["S0"]), expected[0], rtol=0.0, atol=1e-12)):
            raise ContractResolutionError("absolute_market价格口径下S0必须等于reference_prices")
    else:
        raise ContractResolutionError("price_convention仅支持normalized_100或absolute_market")
    constraint_sources = _apply_constraint_bound_terms(
        final_terms,
        source_terms.get("constraints", ()),
        source_registry["term_catalog"],
        explicit_overrides=frozenset(overrides),
    )
    variables = bind_term_symbols(final_terms, source_registry["term_catalog"])
    derived_sources: dict[str, str] = {}
    for key, expression in source_terms.get("derived_terms", {}).items():
        if key in final_terms:
            raise ContractResolutionError(f"派生条款字段与基础条款重名：{key}")
        try:
            value = evaluate_formula(expression, variables)
        except FormulaError as error:
            raise ContractResolutionError(f"派生条款{key}无法计算：{error}") from error
        _validate_terms({key: value}, source_registry["term_catalog"])
        final_terms[key] = value
        variables[str(source_registry["term_catalog"][key]["symbol"])] = value
        derived_sources[key] = "derived"
    for expression in source_terms.get("constraints", []):
        if _coerce_bool(evaluate_formula(expression, variables)) is not True:
            raise ContractResolutionError(f"条款覆盖不满足产品约束：{expression}")
    if _OBSERVATION_TERM_KEYS & set(final_terms):
        _require_observation_calendar_identity(supplied_identity, final_terms)
        if trading_dates is None and frozen_resolved_schedules is None:
            raise ContractResolutionError("含观察条款的正式合同必须提供Host验证交易日历")
    final_terms["monitor"] = deepcopy(source_terms.get("monitor", {}))
    final_terms["pricing_methods"] = list(source_terms["pricing_methods"])
    if "constraints" in source_terms:
        final_terms["constraints"] = list(source_terms["constraints"])
    if "derived_terms" in source_terms:
        final_terms["derived_terms"] = deepcopy(source_terms["derived_terms"])
    term_sources = {key: "override" if key in overrides else "default" for key in defaults}
    term_sources.update(constraint_sources)
    term_sources.update(derived_sources)
    for key in final_terms:
        term_sources.setdefault(key, "default")
    resolved_identity = {
        "product_id": str(product_id),
        "name_zh": product_identity["name_zh"],
        "entry_status": bool(product_identity["entry_status"]),
        "rule_revision": int(product_identity["rule_revision"]),
        "contract_id": str(supplied_identity.get("contract_id") or f"{product_id}-contract"),
        "underlyings": list(underlyings),
        "currency": str(supplied_identity.get("currency") or "CNY"),
        "contract_start_date": supplied_identity.get("contract_start_date"),
        "contract_end_date": supplied_identity.get("contract_end_date"),
        "reference_prices": references,
        "price_convention": price_convention,
        "calendar_id": supplied_identity.get("calendar_id"),
        "calendar_revision": supplied_identity.get("calendar_revision"),
    }
    contract = ResolvedContract(
        resolved_identity,
        final_terms,
        term_sources,
        tuple(deepcopy(product["paths"])),
        resolved_schedules=(
            deep_thaw(frozen_resolved_schedules)
            if frozen_resolved_schedules is not None
            else _schedule_snapshot(
                final_terms,
                trading_dates,
                contract_start_date=resolved_identity.get("contract_start_date"),
                contract_end_date=resolved_identity.get("contract_end_date"),
            )
        ),
    )
    return contract


def resolve_contract(
    product_id: str,
    *,
    identity: Mapping[str, Any] | None = None,
    term_overrides: Mapping[str, Any] | None = None,
    registry: Mapping[str, Any] | None = None,
    registry_path: str | Path = DEFAULT_REGISTRY_PATH,
    trading_dates: Sequence[Any] | None = None,
) -> ResolvedContract:
    """以默认条款加本次覆盖生成唯一正式合同；观察日必须由Host冻结。"""
    return _resolve_contract(
        product_id,
        identity=identity,
        term_overrides=term_overrides,
        registry=registry,
        registry_path=registry_path,
        trading_dates=trading_dates,
    )


def resolve_structural_payoff_contract(
    product_id: str,
    *,
    term_overrides: Mapping[str, Any] | None = None,
    registry: Mapping[str, Any] | None = None,
) -> ResolvedContract:
    """Compile a normalized payoff shape without market or task data.

    Payoffer describes contract settlement returns on the shared S0=100
    coordinate.  Security codes, quotes and exchange calendars therefore do
    not belong to this input.  Observation selectors still need a deterministic
    date grid so the common contract interpreter can freeze their relative
    schedule; that internal grid is explicitly not market evidence.
    """

    source_registry = registry if registry is not None else load_registry()
    product = get_product(str(product_id), source_registry)
    terms = product.get("terms")
    if not isinstance(terms, Mapping):
        raise ContractResolutionError(f"产品{product_id}缺少有效terms")
    if "S0Vec" in terms:
        raw_references = terms["S0Vec"]
        if not isinstance(raw_references, (list, tuple)) or len(raw_references) < 2:
            raise ContractResolutionError(f"产品{product_id}.S0Vec必须定义至少两个标准化坐标")
        underlyings = [f"S{index + 1}" for index in range(len(raw_references))]
        reference_prices = dict(zip(underlyings, raw_references))
    else:
        underlyings = ["S1"]
        reference_prices = {"S1": float(terms.get("S0", _NORMALIZED_PRICE_BASE))}
    has_observations = bool(_OBSERVATION_TERM_KEYS.intersection(terms))
    identity: dict[str, Any] = {
        "underlyings": underlyings,
        "reference_prices": reference_prices,
        "price_convention": "normalized_100",
    }
    trading_dates: Sequence[str] | None = None
    if has_observations:
        identity.update({
            "calendar_id": _STRUCTURAL_PAYOFF_CALENDAR_ID,
            "calendar_revision": _STRUCTURAL_PAYOFF_CALENDAR_REVISION,
        })
        trading_dates = tuple(
            pd.bdate_range("2026-01-02", periods=_STRUCTURAL_PAYOFF_SESSION_COUNT)
            .strftime("%Y-%m-%d")
            .tolist()
        )
    return _resolve_contract(
        str(product_id),
        identity=identity,
        term_overrides=term_overrides,
        registry=source_registry,
        trading_dates=trading_dates,
    )


def make_payoff_input(contract: ResolvedContract) -> PayoffInput:
    return PayoffInput(contract=contract)


def bind_term_symbols(terms: Mapping[str, Any], term_catalog: Mapping[str, Any] | None = None) -> dict[str, Any]:
    catalog = term_catalog or _shared_term_catalog()
    variables: dict[str, Any] = {}
    for key, value in terms.items():
        if key in _STATIC_TERM_KEYS:
            continue
        try:
            symbol = str(catalog[key]["symbol"])
        except (KeyError, TypeError) as error:
            raise ContractResolutionError(f"条款字段{key}未登记在term_catalog") from error
        if symbol in variables:
            raise ContractResolutionError(f"公式变量{symbol}在同一合同中重复绑定")
        variables[symbol] = value
    return variables


def prepare_contract_evaluator(
    contract: ResolvedContract,
    *,
    times: Sequence[float],
    dates: Sequence[Any] | None,
    asset_ids: Sequence[str],
    valuation_date: Any = None,
) -> PreparedContractEvaluator:
    """一次冻结批量路径共享的合同、时间网格和观察日映射。"""

    if not isinstance(contract, ResolvedContract):
        raise ContractResolutionError("批量解释准备需要ResolvedContract")
    assets = tuple(str(item) for item in asset_ids)
    if assets != contract.underlyings:
        raise ContractResolutionError("asset_ids必须与ResolvedContract.underlyings完全一致")
    grid = np.asarray(times, dtype=float)
    if grid.ndim != 1 or len(grid) < 2 or not np.isfinite(grid).all() or grid[0] < 0.0 or np.any(np.diff(grid) <= 0):
        raise ContractResolutionError("时间网格须含至少两个非负有限值且严格递增")

    normalized_dates: tuple[pd.Timestamp, ...] | None = None
    if dates is not None:
        if len(dates) != len(grid):
            raise ContractResolutionError("日期网格与时间网格长度不一致")
        date_index = pd.to_datetime(list(dates), errors="coerce")
        if date_index.isna().any() or not date_index.is_monotonic_increasing or date_index.has_duplicates:
            raise ContractResolutionError("日期网格须为严格递增的有效交易日")
        normalized_dates = tuple(pd.Timestamp(value) for value in date_index)
        inferred_valuation_date = pd.Timestamp(normalized_dates[0]).normalize()
    else:
        if contract.resolved_schedules:
            raise ContractResolutionError("含冻结观察日的合同准备批量解释时必须提供真实日期网格")
        inferred_valuation_date = None
    if valuation_date is not None and valuation_date != "":
        declared_valuation_date = pd.to_datetime(valuation_date, errors="coerce")
        if pd.isna(declared_valuation_date):
            raise ContractResolutionError("valuation_date必须为有效日期")
        declared_valuation_date = pd.Timestamp(declared_valuation_date).normalize()
        if inferred_valuation_date is not None and declared_valuation_date != inferred_valuation_date:
            raise ContractResolutionError("valuation_date必须与日期网格首日一致")
        inferred_valuation_date = declared_valuation_date
    if inferred_valuation_date is None:
        raise ContractResolutionError("无日期网格时必须显式提供valuation_date")

    base_variables = _contract_formula_variables(contract)
    schedule_cache: dict[int, tuple[np.ndarray, np.ndarray]] = {}
    date_index = pd.DatetimeIndex(normalized_dates) if normalized_dates is not None else None
    for value in base_variables.values():
        if not isinstance(value, _FrozenObservationSchedule):
            continue
        positions = _schedule_positions(value, grid, date_index)
        ordinals = _schedule_observation_ordinals(value, grid, date_index, positions)
        positions.setflags(write=False)
        ordinals.setflags(write=False)
        schedule_cache[id(value)] = (positions, ordinals)

    grid_times = tuple(float(item) for item in grid)
    valuation_iso = inferred_valuation_date.date().isoformat()
    return PreparedContractEvaluator(
        contract=contract,
        asset_ids=assets,
        valuation_date=valuation_iso,
        times=grid_times,
        dates=normalized_dates,
        _base_variables=MappingProxyType(base_variables),
        _schedule_cache=MappingProxyType(schedule_cache),
    )


def evaluate_contract_batch(
    prepared: PreparedContractEvaluator,
    values: Sequence[Any] | np.ndarray,
    *,
    price_fields: Mapping[str, Sequence[Any] | np.ndarray] | None = None,
    batch_size: int | None = None,
    cancellation_check: Callable[[], bool] | None = None,
) -> BatchPayoffEvaluation:
    """按输入顺序批量调用同一合同解释语义，不聚合、不降采样。"""

    if not isinstance(prepared, PreparedContractEvaluator):
        raise ContractResolutionError("批量解释必须使用prepare_contract_evaluator的准备结果")
    paths = np.asarray(values, dtype=float)
    expected_shape = (len(prepared.times), len(prepared.asset_ids))
    if paths.ndim != 3 or paths.shape[0] < 1 or paths.shape[1:] != expected_shape:
        raise ContractResolutionError("批量价格路径必须为(paths,steps,assets)且匹配准备网格")
    if batch_size is None:
        chunk_size = len(paths)
    elif isinstance(batch_size, bool) or not isinstance(batch_size, int) or batch_size <= 0:
        raise ContractResolutionError("batch_size必须为正整数")
    else:
        chunk_size = batch_size

    normalized_fields: dict[str, np.ndarray] = {}
    for name, field_values in dict(price_fields or {}).items():
        field_array = np.asarray(field_values, dtype=float)
        if field_array.shape != paths.shape:
            raise ContractResolutionError(f"price_fields.{name}必须与批量价格路径同形状")
        normalized_fields[name] = field_array

    evaluations: list[PayoffEvaluation] = []
    for chunk_start in range(0, len(paths), chunk_size):
        chunk_end = min(chunk_start + chunk_size, len(paths))
        for path_index in range(chunk_start, chunk_end):
            if cancellation_check is not None and cancellation_check():
                raise ContractEvaluationCancelled("批量合同解释已取消")
            path = PricePath.from_values(
                paths[path_index],
                times=prepared.times,
                dates=prepared.dates,
                asset_ids=prepared.asset_ids,
                price_fields={name: data[path_index] for name, data in normalized_fields.items()},
            )
            variables = _formula_context(
                prepared.contract,
                path,
                base_variables=prepared._base_variables,
                schedule_cache=prepared._schedule_cache,
            )
            evaluations.append(_evaluate_contract_variables(prepared.contract, path, variables))
    return BatchPayoffEvaluation(tuple(evaluations))


def evaluate_contract(contract: ResolvedContract, price_path: PricePath) -> PayoffEvaluation:
    """同一解释器选择唯一经济路径、唯一分段并产出逐笔持有方现金流。"""
    variables = _formula_context(contract, price_path)
    return _evaluate_contract_variables(contract, price_path, variables)


def _evaluate_contract_variables(
    contract: ResolvedContract,
    price_path: PricePath,
    variables: dict[str, Any],
) -> PayoffEvaluation:
    monitor_values = compute_monitor_values(contract, price_path, variables)
    variables.update(monitor_values)
    chosen_paths = [index for index, path in enumerate(contract.paths) if _coerce_bool(evaluate_formula(path["condition"], variables))]
    if len(chosen_paths) != 1:
        raise FormulaError(f"{contract.product_id}在给定价格路径下命中{len(chosen_paths)}条经济路径，必须唯一")
    selected_path = chosen_paths[0]
    _validate_settlement_endpoint(contract, price_path, monitor_values, contract.paths[selected_path]["condition"])
    cases = contract.paths[selected_path]["cases"]
    chosen_cases = [index for index, case in enumerate(cases) if _coerce_bool(evaluate_formula(case["domain"], variables))]
    if len(chosen_cases) != 1:
        raise FormulaError(f"{contract.product_id}路径{selected_path + 1}命中{len(chosen_cases)}个分段，必须唯一")
    selected_case = chosen_cases[0]
    if (selected_path, selected_case) not in set(contract.active_path_case_refs):
        raise FormulaError(
            f"{contract.product_id}运行路径命中合同冻结日历下不可达的"
            f"path{selected_path + 1}/case{selected_case + 1}"
        )
    result = evaluate_formula(cases[selected_case]["pnl"], variables)
    if not isinstance(result, CashflowBundle):
        raise FormulaError("pnl必须返回由cash(t, amount)组成的现金流")
    return PayoffEvaluation(selected_path, selected_case, monitor_values, result.flows)
def _validate_settlement_endpoint(
    contract: ResolvedContract,
    price_path: PricePath,
    monitor_values: Mapping[str, Any],
    selected_condition: str,
) -> None:
    """未到合同期限的输入只能用于已有终止事件的完整提前结算路径。"""
    if "T" not in contract.terms:
        return
    contractual_tenor = _contract_maturity_time(contract.identity, contract.terms)
    actual_tenor = float(price_path.times[-1])
    count_key = counted_observation_key(contract.terms)
    if count_key is not None and price_path.dates is not None:
        observation_end = pd.Timestamp(contract.resolved_schedules[count_key]["dates"][-1])
        actual_end = pd.Timestamp(price_path.dates[-1]).normalize()
        if actual_end == observation_end:
            return
        if actual_end > observation_end:
            raise ContractResolutionError("计数型合同价格路径终点不得晚于冻结观察终点")
        # A prefix requires an actual termination event, even if T is short.
        contractual_tenor = inf
    if actual_tenor > contractual_tenor + _MATURITY_TIME_TOLERANCE:
        raise ContractResolutionError(
            f"{contract.product_id}价格路径终点{actual_tenor}年晚于合同期限{contractual_tenor}年；"
            "结算路径不得使用到期日后的价格"
        )
    if abs(actual_tenor - contractual_tenor) <= _MATURITY_TIME_TOLERANCE:
        return
    termination_names = ("tau_out", "tau_out_1", "tau_out_2", "tau_hedge", "tau_touch")
    for name in termination_names:
        value = monitor_values.get(name)
        if not isinstance(value, (int, float, np.number)) or not np.isfinite(float(value)):
            continue
        if float(value) > actual_tenor + 1e-12 or not re.search(rf"\b{name}\b", selected_condition):
            continue
        if re.search(rf"\b{name}\s*==\s*inf", selected_condition):
            continue
        return
    if count_key is not None:
        raise ContractResolutionError("n_obs计数型合同的未终止路径必须覆盖完整冻结观察日程")
    raise ContractResolutionError(
        f"{contract.product_id}价格路径终点{actual_tenor}年早于合同期限{contractual_tenor}年；"
        "未终止路径须覆盖至合同到期日或其相邻交易日"
    )


def compute_monitor_values(contract: ResolvedContract, price_path: PricePath, base_variables: Mapping[str, Any] | None = None) -> dict[str, Any]:
    monitor = contract.terms.get("monitor", {})
    if not isinstance(monitor, Mapping):
        raise ContractResolutionError("terms.monitor必须为扁平公式字典")
    variables = dict(base_variables or _formula_context(contract, price_path))
    result: dict[str, Any] = {}
    for name in _monitor_evaluation_order(monitor):
        expression = monitor[name]
        result[name] = evaluate_formula(expression, variables)
        variables[name] = result[name]
    return result


def _monitor_evaluation_order(monitor: Mapping[str, Any]) -> tuple[str, ...]:
    """Return a deterministic dependency order independent of JSON key order."""

    if any(not isinstance(name, str) or not isinstance(expression, str) for name, expression in monitor.items()):
        raise ContractResolutionError("monitor必须是唯一指标名到字符串公式的映射")
    names = frozenset(monitor)
    dependencies = {
        name: frozenset(
            node.id for node in ast.walk(_validated_formula_tree(expression))
            if isinstance(node, ast.Name) and node.id in names
        )
        for name, expression in monitor.items()
    }
    remaining = set(names)
    resolved: set[str] = set()
    ordered: list[str] = []
    while remaining:
        ready = sorted(name for name in remaining if dependencies[name] <= resolved)
        if not ready:
            raise ContractResolutionError("monitor指标存在循环依赖")
        ordered.extend(ready)
        resolved.update(ready)
        remaining.difference_update(ready)
    return tuple(ordered)


def evaluate_formula(expression: str, variables: Mapping[str, Any]) -> Any:
    """执行有限AST表达式；绝不使用eval、属性访问、导入或产品专属函数。"""
    if not isinstance(expression, str) or not expression.strip():
        raise FormulaError("公式必须为非空字符串")
    if len(expression) > _MAX_FORMULA_CHARS:
        raise FormulaError("公式超过最大长度")
    tree = _validated_formula_tree(expression)

    try:
        result = _FormulaEvaluator(variables).visit(tree.body)
    except FormulaError:
        raise
    except (ArithmeticError, TypeError, ValueError, RecursionError, MemoryError) as error:
        raise FormulaError("公式计算超过受限范围") from error
    if isinstance(result, (float, np.floating)) and not np.isfinite(float(result)):
        if float(result) != inf:
            raise FormulaError("公式结果必须为有限数值")
    return result


@lru_cache(maxsize=512)
def _validated_formula_tree(expression: str) -> ast.Expression:
    tree = _parse_formula(expression)
    nodes = list(ast.walk(tree))
    if len(nodes) > _MAX_FORMULA_NODES:
        raise FormulaError("公式超过最大语法复杂度")
    stack = [(tree, 1)]
    while stack:
        node, depth = stack.pop()
        if depth > _MAX_FORMULA_DEPTH:
            raise FormulaError("公式超过最大嵌套深度")
        stack.extend((child, depth + 1) for child in ast.iter_child_nodes(node))
    return tree


@lru_cache(maxsize=512)
def _parse_formula(expression: str) -> ast.Expression:
    try:
        return ast.parse(expression, mode="eval")
    except (SyntaxError, RecursionError, MemoryError) as error:
        raise FormulaError(f"公式语法错误：{expression}") from error


class _FormulaEvaluator(ast.NodeVisitor):
    def __init__(self, variables: Mapping[str, Any]) -> None:
        self.variables = dict(variables)

    def generic_visit(self, node: ast.AST) -> Any:
        raise FormulaError(f"不允许的公式语法：{node.__class__.__name__}")

    def visit_Constant(self, node: ast.Constant) -> Any:
        if isinstance(node.value, (int, float, str, bool)) or node.value is None:
            return node.value
        raise FormulaError("公式常量仅允许数值、字符串和布尔值")

    def visit_Name(self, node: ast.Name) -> Any:
        if node.id == "inf":
            return inf
        try:
            return self.variables[node.id]
        except KeyError as error:
            raise FormulaError(f"公式引用了未绑定变量：{node.id}") from error

    def visit_List(self, node: ast.List) -> list[Any]:
        return [self.visit(item) for item in node.elts]

    def visit_Tuple(self, node: ast.Tuple) -> tuple[Any, ...]:
        return tuple(self.visit(item) for item in node.elts)

    def visit_Subscript(self, node: ast.Subscript) -> Any:
        target = self.visit(node.value)
        index = self.visit(node.slice)
        if not isinstance(target, PriceSeries):
            raise FormulaError("下标访问仅允许价格路径，例如S_t[O_out]")
        return target[index]

    def visit_UnaryOp(self, node: ast.UnaryOp) -> Any:
        value = self.visit(node.operand)
        if isinstance(node.op, ast.USub):
            return -value
        if isinstance(node.op, ast.UAdd):
            return +value
        if isinstance(node.op, ast.Not):
            return ~value if isinstance(value, EventVector) else not _coerce_bool(value)
        raise FormulaError("不允许的单目运算")

    def visit_BinOp(self, node: ast.BinOp) -> Any:
        left, right = self.visit(node.left), self.visit(node.right)
        if any(isinstance(value, (str, bytes, list, tuple, set, frozenset)) for value in (left, right)):
            raise FormulaError("公式不允许对字符串或容器执行算术")
        if isinstance(node.op, ast.Add): return _bounded_formula_value(left + right)
        if isinstance(node.op, ast.Sub): return _bounded_formula_value(left - right)
        if isinstance(node.op, ast.Mult): return _bounded_formula_value(left * right)
        if isinstance(node.op, ast.Div): return _bounded_formula_value(left / right)
        if isinstance(node.op, ast.Pow):
            exponent = _finite_number(right, "幂指数")
            if abs(exponent) > _MAX_POWER_EXPONENT:
                raise FormulaError("幂指数超过受限范围")
            return _bounded_formula_value(left ** exponent)
        if isinstance(node.op, ast.Mod): return _bounded_formula_value(left % right)
        raise FormulaError("不允许的二元运算")

    def visit_BoolOp(self, node: ast.BoolOp) -> Any:
        values = [self.visit(value) for value in node.values]
        result = values[0]
        for value in values[1:]:
            if isinstance(result, EventVector) or isinstance(value, EventVector):
                result = _event_vector(result, _event_times(result, value))
                other = _event_vector(value, result.times)
                result = result & other if isinstance(node.op, ast.And) else result | other
            else:
                result = _coerce_bool(result) and _coerce_bool(value) if isinstance(node.op, ast.And) else _coerce_bool(result) or _coerce_bool(value)
        return result

    def visit_Compare(self, node: ast.Compare) -> Any:
        left = self.visit(node.left)
        results: list[Any] = []
        for operator, comparator in zip(node.ops, node.comparators):
            right = self.visit(comparator)
            results.append(_compare(left, right, operator))
            left = right
        result = results[0]
        for item in results[1:]:
            result = result & item if isinstance(result, EventVector) else _coerce_bool(result) and _coerce_bool(item)
        return result

    def visit_Call(self, node: ast.Call) -> Any:
        if not isinstance(node.func, ast.Name) or node.keywords:
            raise FormulaError("公式函数不支持属性、关键字参数或任意调用")
        name = node.func.id
        args = [self.visit(arg) for arg in node.args]
        functions = {
            "min": min,
            "max": max,
            "first_time": _first_time,
            "first_time_after": _first_time_after,
            "first_time_before": _first_time_before,
            "first_time_levels": _first_time_levels,
            "first_time_below_levels": _first_time_below_levels,
            "schedule_levels": _schedule_levels,
            "step_levels": _step_levels,
            "first_time_below_schedule": _first_time_below_schedule,
            "first_observation_on_or_after": _first_observation_on_or_after,
            "terminal_event_time": _terminal_event_time,
            "reset_knockout_time": _reset_knockout_time,
            "effective_hedge_time": _effective_hedge_time,
            "first_value": _first_value,
            "count": _count,
            "count_until": _count_until,
            "exact_observation_count": _exact_observation_count,
            "observation_ordinal": _observation_ordinal,
            "realized_variance": _realized_variance,
            "accumulated_quantity": _accumulated_quantity,
            "schedule_between": _schedule_between,
            "schedule_matches_ratios": _schedule_matches_ratios,
            "period_count": _period_count,
            "linear_schedule": _linear_schedule,
            "terminal_schedule": _terminal_schedule,
            "truncate_schedule": _truncate_schedule,
            "is_monthly_schedule": _is_monthly_schedule,
            "require_maturity_observation": _require_maturity_observation,
            "cash": _cash,
        }
        try:
            return functions[name](*args)
        except KeyError as error:
            raise FormulaError(f"公式函数未登记：{name}") from error
        except FormulaError:
            raise
        except (TypeError, ValueError, FloatingPointError) as error:
            raise FormulaError(f"公式函数{name}的参数无效") from error


def validate_product_spec(product_id: str, product: Mapping[str, Any], term_catalog: Mapping[str, Any]) -> list[str]:
    """验证每个OptionReg产品的外形、字段及静态公式语义。

    ``entry_status``只决定模块是否允许执行，不能跳过资料库本身的结构和
    公式检查。否则未完成产品会在恢复执行时才暴露字段或符号错误。
    """
    issues: list[str] = []
    if set(product) != _ALLOWED_PRODUCT_KEYS:
        issues.append("product必须且只能有identity、terms、paths")
        return issues
    identity = product.get("identity")
    terms = product.get("terms")
    paths = product.get("paths")
    if not isinstance(identity, Mapping) or set(identity) != _ALLOWED_IDENTITY_KEYS:
        issues.append("identity字段不符合固定外形")
    elif identity.get("product_id") != product_id:
        issues.append("products外层键与identity.product_id不一致")
    elif not isinstance(identity.get("entry_status"), bool):
        issues.append("identity.entry_status必须为Python布尔值")
    elif (
        isinstance(identity.get("rule_revision"), bool)
        or not isinstance(identity.get("rule_revision"), int)
        or identity["rule_revision"] <= 0
    ):
        issues.append("identity.rule_revision必须为正整数")
    elif not isinstance(identity.get("name_zh"), str) or not identity["name_zh"].strip():
        issues.append("identity.name_zh必须为非空字符串")
    if not isinstance(terms, Mapping) or not terms:
        issues.append("terms必须为非空映射")
        return issues
    if "pricing_methods" not in terms or not isinstance(terms["pricing_methods"], list) or "monte_carlo" not in terms["pricing_methods"]:
        issues.append("terms.pricing_methods必须包含monte_carlo")
    elif len(terms["pricing_methods"]) != len(set(terms["pricing_methods"])):
        issues.append("terms.pricing_methods不得重复")
    if set(terms.get("pricing_methods", [])) - {"analytical", "monte_carlo"}:
        issues.append("pricing_methods含未登记方法")
    if "constraints" in terms and (not isinstance(terms["constraints"], list) or not terms["constraints"]):
        issues.append("constraints只能省略或为非空列表")
    if "monitor" in terms and (not isinstance(terms["monitor"], Mapping) or not all(isinstance(key, str) and isinstance(value, str) for key, value in terms["monitor"].items())):
        issues.append("monitor必须为扁平字符串公式字典")
    if "derived_terms" in terms and (not isinstance(terms["derived_terms"], Mapping) or not terms["derived_terms"] or not all(isinstance(key, str) and isinstance(value, str) for key, value in terms["derived_terms"].items())):
        issues.append("derived_terms只能省略或为非空字符串公式字典")
    ordinary_terms = {key: value for key, value in terms.items() if key not in _RULE_TERM_KEYS}
    term_symbols: set[str] = set()
    try:
        _validate_terms(ordinary_terms, term_catalog)
        term_symbols = set(bind_term_symbols(ordinary_terms, term_catalog))
    except ContractResolutionError as error:
        issues.append(str(error))
    # 月度默认每月最后一个交易日，本次合同可覆盖为其他月内交易日。
    if term_symbols:
        derived_symbols: set[str] = set()
        derived_variables: dict[str, Any] = {}
        try:
            derived_variables = bind_term_symbols(ordinary_terms, term_catalog)
            for key, expression in terms.get("derived_terms", {}).items():
                if key in ordinary_terms:
                    issues.append(f"派生条款字段与基础条款重名：{key}")
                    continue
                if key not in term_catalog:
                    issues.append(f"派生条款字段{key}未登记在term_catalog")
                    continue
                issues.extend(_validate_expression(expression, term_symbols | derived_symbols, f"derived_terms.{key}", allow_cash=False))
                value = evaluate_formula(expression, derived_variables)
                _validate_terms({key: value}, term_catalog)
                symbol = str(term_catalog[key]["symbol"])
                if symbol in derived_variables:
                    issues.append(f"派生公式变量{symbol}重复绑定")
                    continue
                derived_variables[symbol] = value
                derived_symbols.add(symbol)
        except (ContractResolutionError, FormulaError) as error:
            issues.append(f"derived_terms无法解释：{error}")
        monitor = terms.get("monitor", {})
        if isinstance(monitor, Mapping):
            prior_monitor_symbols: set[str] = set()
            for monitor_key, expression in monitor.items():
                issues.extend(_validate_expression(
                    expression,
                    term_symbols | derived_symbols | _SETTLEMENT_VARIABLES | prior_monitor_symbols,
                    f"monitor.{monitor_key}",
                    allow_cash=False,
                ))
                prior_monitor_symbols.add(monitor_key)
        if "constraints" in terms:
            for index, expression in enumerate(terms["constraints"]):
                issues.extend(_validate_expression(expression, term_symbols | derived_symbols, f"constraints[{index}]", allow_cash=False))
            try:
                variables = bind_term_symbols(ordinary_terms, term_catalog)
                for key, expression in terms.get("derived_terms", {}).items():
                    value = evaluate_formula(expression, variables)
                    variables[str(term_catalog[key]["symbol"])] = value
                for expression in terms["constraints"]:
                    if not _coerce_bool(evaluate_formula(expression, variables)):
                        issues.append(f"默认条款不满足constraints：{expression}")
            except FormulaError as error:
                issues.append(f"constraints无法解释：{error}")
    if not isinstance(paths, list) or not paths:
        issues.append("paths必须为非空列表")
    else:
        for path in paths:
            if not isinstance(path, Mapping) or set(path) != _ALLOWED_PATH_KEYS or not isinstance(path.get("condition"), str) or not isinstance(path.get("cases"), list) or not path["cases"]:
                issues.append("路径必须且只能有condition与非空cases")
                continue
            for case in path["cases"]:
                if not isinstance(case, Mapping) or set(case) != _ALLOWED_CASE_KEYS or not all(isinstance(case.get(key), str) for key in _ALLOWED_CASE_KEYS):
                    issues.append("分段必须且只能有domain与pnl字符串")
            allowed = term_symbols | derived_symbols | _SETTLEMENT_VARIABLES | set(terms.get("monitor", {}))
            issues.extend(_validate_expression(path["condition"], allowed, "paths.condition", allow_cash=False))
            for case in path["cases"]:
                if isinstance(case, Mapping) and isinstance(case.get("domain"), str) and isinstance(case.get("pnl"), str):
                    issues.extend(_validate_expression(case["domain"], allowed, "paths.cases.domain", allow_cash=False))
                    issues.extend(_validate_expression(case["pnl"], allowed, "paths.cases.pnl", allow_cash=True, require_cash=True))
    return issues


def validate_registry(registry: Mapping[str, Any] | None = None) -> dict[str, list[str]]:
    reg = registry or load_registry()
    errors: dict[str, list[str]] = {}
    for product_id, product in reg["products"].items():
        issues = validate_product_spec(product_id, product, reg["term_catalog"])
        if issues:
            errors[product_id] = issues
    return errors


def _validate_expression(
    expression: str,
    allowed_variables: set[str],
    label: str,
    *,
    allow_cash: bool,
    require_cash: bool = False,
) -> list[str]:
    """只做静态语义核验，不执行产品公式。"""
    try:
        tree = _parse_formula(expression)
    except FormulaError as error:
        return [f"{label}语法无效：{error}"]
    names = {node.id for node in ast.walk(tree) if isinstance(node, ast.Name)}
    unknown = names - allowed_variables - _FORMULA_FUNCTIONS
    if unknown:
        return [f"{label}引用未登记变量：{','.join(sorted(unknown))}"]
    calls = {
        node.func.id
        for node in ast.walk(tree)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
    }
    if not allow_cash and "cash" in calls:
        return [f"{label}不得生成现金流"]
    if require_cash and "cash" not in calls:
        return [f"{label}必须使用cash(t, amount)表达现金流"]
    return []


def _validate_terms(terms: Mapping[str, Any], catalog: Mapping[str, Any]) -> None:
    for key, value in terms.items():
        if key not in catalog:
            raise ContractResolutionError(f"条款字段{key}未登记在term_catalog")
        definition = catalog[key]
        value_type = definition.get("value_type")
        domain = definition.get("domain", {})
        if value_type == "number":
            _check_number(value, key, domain)
        elif value_type == "integer":
            if not isinstance(value, int) or isinstance(value, bool):
                raise ContractResolutionError(f"条款{key}必须为整数")
            _check_number(value, key, domain)
        elif value_type == "boolean":
            if not isinstance(value, bool):
                raise ContractResolutionError(f"条款{key}必须为布尔值")
        elif value_type == "string":
            if not isinstance(value, str):
                raise ContractResolutionError(f"条款{key}必须为字符串")
            if "enum" in domain and value not in domain["enum"]:
                raise ContractResolutionError(f"条款{key}不在允许枚举内")
            if domain.get("format") == "observation_schedule" and not _is_observation_schedule(value):
                raise ContractResolutionError(f"条款{key}不是有效观察日程：{value}")
        elif value_type == "number_list":
            if not isinstance(value, Sequence) or isinstance(value, (str, bytes)) or not value:
                raise ContractResolutionError(f"条款{key}必须为非空数值列表")
            for item in value: _check_number(item, key, domain)
        elif value_type == "schedule":
            if not isinstance(value, Sequence) or isinstance(value, (str, bytes)) or len(value) < domain.get("min_items", 1):
                raise ContractResolutionError(f"条款{key}必须为非空日程")
        else:
            raise ContractResolutionError(f"term_catalog.{key}.value_type无效")


def _check_number(value: Any, key: str, domain: Mapping[str, Any]) -> None:
    if not isinstance(value, (int, float, np.number)) or isinstance(value, bool) or not np.isfinite(float(value)):
        raise ContractResolutionError(f"条款{key}必须为有限数值")
    number = float(value)
    if "min" in domain and number < float(domain["min"]): raise ContractResolutionError(f"条款{key}低于最小值")
    if "max" in domain and number > float(domain["max"]): raise ContractResolutionError(f"条款{key}高于最大值")
    if "exclusive_min" in domain and number <= float(domain["exclusive_min"]): raise ContractResolutionError(f"条款{key}必须大于{domain['exclusive_min']}")


def _validate_normalized_price_base(terms: Mapping[str, Any]) -> None:
    """价格水平统一以100为内部基准，真实参考价仅由identity提供。"""
    if "S0" in terms and not np.isclose(float(terms["S0"]), _NORMALIZED_PRICE_BASE, rtol=0.0, atol=1e-12):
        raise ContractResolutionError("S0是固定的内部标准化基准100，不可覆盖为其他数值；请在reference_prices传入真实合同参考价")
    if "S0Vec" in terms:
        levels = np.asarray(terms["S0Vec"], dtype=float)
        if not np.allclose(levels, _NORMALIZED_PRICE_BASE, rtol=0.0, atol=1e-12):
            raise ContractResolutionError("S0Vec各分量必须为内部标准化基准100；请在reference_prices逐一传入真实合同参考价")


def _normalized_reference_prices(terms: Mapping[str, Any], underlyings: Sequence[str]) -> dict[str, float] | None:
    """Derive normalized coordinate references only from frozen S0 facts."""

    if "S0Vec" in terms:
        values = tuple(float(value) for value in terms["S0Vec"])
        if len(values) != len(underlyings):
            raise ContractResolutionError("S0Vec与underlyings数量不一致，无法冻结参考价格")
        return dict(zip(underlyings, values, strict=True))
    if "S0" in terms:
        if len(underlyings) != 1:
            raise ContractResolutionError("多标的normalized_100合同必须使用S0Vec冻结逐标的参考价格")
        return {underlyings[0]: float(terms["S0"])}
    return None


def _contract_formula_variables(contract: ResolvedContract) -> dict[str, Any]:
    catalog = _shared_term_catalog()
    variables = bind_term_symbols(contract.terms, catalog)
    for key, snapshot in contract.resolved_schedules.items():
        symbol = str(catalog[key]["symbol"])
        variables[symbol] = _FrozenObservationSchedule(
            tuple(pd.Timestamp(value).normalize() for value in snapshot["dates"]),
        )
    if "T" in contract.terms:
        variables["T_contract"] = float(contract.terms["T"])
    return variables


def _formula_context(
    contract: ResolvedContract,
    price_path: PricePath,
    *,
    base_variables: Mapping[str, Any] | None = None,
    schedule_cache: Mapping[int, tuple[np.ndarray, np.ndarray]] | None = None,
) -> dict[str, Any]:
    if price_path.asset_ids != contract.underlyings:
        raise ContractResolutionError("价格路径asset_ids必须与ResolvedContract.underlyings完全一致")
    catalog = _shared_term_catalog()
    variables = dict(base_variables) if base_variables is not None else _contract_formula_variables(contract)
    # 正式合同中的观察日已在ResolvedContract冻结。无论路径是否带日期，都必须
    # 先注入冻结日程；随后由_FrozenObservationSchedule显式拒绝无日期路径，
    # 禁止退回monthly_last等selector按时间网格重新推导观察点。
    # 公式中的T是当前实际结算终点，用于ACT/365票息与期权费的实际天数折算。
    # 合同期限仍保留在ResolvedContract；evaluate_contract随后拒绝半程未终止路径，
    # 只有已发生的提前终止事件才能在合同到期前结算。
    if "T" in contract.terms:
        contractual_tenor = float(contract.terms["T"])
        if not price_path.times_explicit and not np.isclose(contractual_tenor, 1.0, rtol=0.0, atol=1e-12):
            raise ContractResolutionError(
                f"{contract.product_id}合同期限为{contractual_tenor}年，价格路径必须显式提供times；"
                "不得使用默认1年时间网格"
            )
        # T是冻结合同起止日定义的ACT/365结算时点；价格路径最后一行可能只是
        # 到期日前最后可用市场价格，不能把该数据日伪装成合同到期日。
        # T_contract保留登记期限，供明确依赖登记期限的公式使用。
        frozen_maturity = _frozen_civil_maturity_time(contract.identity)
        variables["T"] = (
            frozen_maturity if frozen_maturity is not None else float(price_path.times[-1])
        )
    observation_price = str(contract.terms.get("observation_price", "close"))
    raw_values = price_path.values_for(observation_price)
    references = contract.identity.get("reference_prices")
    if references is None:
        if "S0Vec" in contract.terms:
            reference_values = np.asarray(contract.terms["S0Vec"], dtype=float)
        elif "S0" in contract.terms:
            reference_values = np.full(len(price_path.asset_ids), float(contract.terms["S0"]), dtype=float)
        else:
            # 方差互换等不以合同参考价定义经济条款的产品，保留输入价格的原始尺度。
            reference_values = np.asarray(raw_values[0], dtype=float)
    else:
        reference_values = np.asarray([references[asset] for asset in price_path.asset_ids], dtype=float)
    if reference_values.shape != (len(price_path.asset_ids),):
        raise ContractResolutionError("合同参考价数量与标的数量不一致")
    price_convention = str(contract.identity.get("price_convention") or "normalized_100")
    if price_convention == "absolute_market":
        # absolute_market保留真实合同录入价格；解释器只在公式上下文中换算为
        # 100基准，ResolvedContract继续保存原始条款和身份参考价。
        normalized_reference = np.full(len(price_path.asset_ids), _NORMALIZED_PRICE_BASE, dtype=float)
        for key, value in contract.terms.items():
            definition = catalog.get(key, {})
            if definition.get("unit") != "price":
                continue
            symbol = str(definition.get("symbol", ""))
            if not symbol:
                continue
            if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
                levels = np.asarray(value, dtype=float)
                if levels.shape == reference_values.shape:
                    variables[symbol] = levels / reference_values * _NORMALIZED_PRICE_BASE
            elif isinstance(value, (int, float, np.number)):
                variables[symbol] = float(value) / float(reference_values[0]) * _NORMALIZED_PRICE_BASE
    elif "S0Vec" in contract.terms:
        normalized_reference = np.asarray(contract.terms["S0Vec"], dtype=float)
    elif "S0" in contract.terms:
        normalized_reference = np.full(len(price_path.asset_ids), float(contract.terms["S0"]), dtype=float)
    else:
        normalized_reference = reference_values
    values = raw_values / reference_values[None, :] * normalized_reference[None, :]
    terminal = values[-1]
    performance = raw_values / reference_values[None, :] * 100.0
    primary_series = PriceSeries(
        values[:, 0], price_path.times, price_path.dates, schedule_cache=schedule_cache,
    )
    worst_series = PriceSeries(
        np.min(performance, axis=1), price_path.times, price_path.dates, schedule_cache=schedule_cache,
    )
    variables.update({
        "S_t": primary_series,
        "S_T": float(terminal[0]),
        # S_T已按合同的标准化初始价表达；r_T必须与该标准化尺度配对，
        # 从而恒等于原始价格的raw_terminal / contract_reference - 1。
        # 这既保留默认S_0=100的展示尺度，也支持任意合同参考价。
        "r_T": float(terminal[0] / normalized_reference[0] - 1.0),
        # 所有合同收益均以无货币单位的每100标准化单位表达。真实参考价只用于
        # raw路径归一化，绝不把普通期权价差换回货币金额。
        "u": 1.0,
        "W_t": worst_series,
        "W_T": float(np.min(performance[-1])),
    })
    return variables


def _is_observation_schedule(value: str) -> bool:
    """校验已明确的交易日观察日程。"""
    if value in {"daily", "monthly_last"}:
        return True
    match = re.fullmatch(r"monthly_(\d+)(st|nd|rd|th)", value)
    if not match:
        return False
    ordinal, suffix = int(match.group(1)), match.group(2)
    if not 1 <= ordinal <= 31:
        return False
    last_two = ordinal % 100
    expected = "th" if 11 <= last_two <= 13 else {1: "st", 2: "nd", 3: "rd"}.get(ordinal % 10, "th")
    return suffix == expected


def _is_monthly_schedule(value: object) -> bool:
    """识别月度观察日程，供固定月票息结构的合同约束使用。"""
    return isinstance(value, str) and (value == "monthly_last" or bool(re.fullmatch(r"monthly_\d+(?:st|nd|rd|th)", value)))


def _require_maturity_observation(values: object, maturity: object) -> bool:
    """要求冻结观察集合包含当前受控价格路径的终点。"""
    if not isinstance(values, ObservedValues):
        raise FormulaError("require_maturity_observation第一个参数必须为观察价格序列")
    _nonnegative_number(maturity, "require_maturity_observation到期时点")
    if not len(values.times) or not values.includes_path_endpoint:
        raise FormulaError("合同约定的观察日程必须包含实际到期日")
    return True


def _schedule_positions(schedule: object, times: np.ndarray, dates: pd.DatetimeIndex | None) -> np.ndarray:
    if isinstance(schedule, _FrozenObservationSchedule):
        if dates is None:
            raise FormulaError("ResolvedContract冻结观察日要求价格路径提供真实日期")
        path_dates = pd.DatetimeIndex(dates).normalize()
        all_frozen_dates = pd.DatetimeIndex(schedule.dates)
        required = np.asarray(
            (all_frozen_dates >= path_dates[0]) & (all_frozen_dates <= path_dates[-1]), dtype=bool,
        )
        frozen_dates = all_frozen_dates[required]
        positions = path_dates.get_indexer(frozen_dates)
        if (positions < 0).any():
            raise ContractResolutionError("价格路径缺少ResolvedContract冻结的合同观察日")
        return positions.astype(int)
    if isinstance(schedule, str):
        if not _is_observation_schedule(schedule):
            raise FormulaError(f"无效观察日程：{schedule}")
        if schedule == "daily":
            return np.arange(len(times))
        if schedule == "monthly_last" or re.fullmatch(r"monthly_\d+(?:st|nd|rd|th)", schedule):
            positions = _monthly_positions(schedule, times, dates)
            return positions[times[positions] > 1e-12]
    if isinstance(schedule, Sequence) and not isinstance(schedule, (str, bytes)):
        positions = np.asarray(schedule, dtype=int)
        if (positions < 0).any() or (positions >= len(times)).any():
            raise FormulaError("观察日程索引超出价格路径")
        return positions
    raise FormulaError("观察日程仅支持daily、monthly_第n个交易日、monthly_last或整数索引序列")


def resolve_schedule(selector: str | Sequence[int], trading_dates: Sequence[Any]) -> tuple[pd.Timestamp, ...]:
    dates = pd.to_datetime(list(trading_dates), errors="coerce")
    if not len(dates) or dates.isna().any() or dates.has_duplicates or not dates.is_monotonic_increasing:
        raise FormulaError("trading_dates必须为非空、严格递增且不重复的有效交易日")
    positions = _schedule_positions(selector, np.arange(len(dates), dtype=float), dates)
    return tuple(pd.Timestamp(dates[index]) for index in positions)


def resolve_schedules(terms: Mapping[str, Any], trading_dates: Sequence[Any]) -> Mapping[str, tuple[pd.Timestamp, ...]]:
    return deep_freeze({
        key: resolve_schedule(terms[key], trading_dates)
        for key in sorted(_OBSERVATION_TERM_KEYS & set(terms))
    })


def _schedule_observation_ordinals(
    schedule: object,
    times: np.ndarray,
    dates: pd.DatetimeIndex | None,
    positions: np.ndarray,
) -> np.ndarray:
    """返回观察日在完整合同日程中的序号。

    有日期的历史路径以输入的合同观察集合顺序编号；无日期的周期模拟路径则按
    绝对合同时间推定序号，以便分期障碍日程不会从中途路径重新从第1期开始。
    """
    if isinstance(schedule, _FrozenObservationSchedule):
        if dates is None:
            raise FormulaError("ResolvedContract冻结观察日要求价格路径提供真实日期")
        positions_in_schedule = pd.DatetimeIndex(schedule.dates).get_indexer(pd.DatetimeIndex(dates)[positions].normalize())
        if (positions_in_schedule < 0).any():
            raise ContractResolutionError("价格路径观察日不属于ResolvedContract冻结日程")
        return positions_in_schedule.astype(int) + 1
    if not isinstance(schedule, str) or dates is not None:
        return np.arange(1, len(positions) + 1, dtype=int)
    observation_times = times[positions]
    if schedule == "monthly_last":
        return _strictly_increasing_ordinals(np.maximum(1, np.rint(observation_times * 12.0).astype(int)))
    if re.fullmatch(r"monthly_\d+(?:st|nd|rd|th)", schedule):
        return _strictly_increasing_ordinals(np.maximum(1, np.ceil(observation_times * 12.0 - 1e-10).astype(int)))
    return np.arange(1, len(positions) + 1, dtype=int)


def _strictly_increasing_ordinals(values: np.ndarray) -> np.ndarray:
    """稀疏无日期网格被多个周期目标命中时，保留其先后周期次序。"""
    result = np.asarray(values, dtype=int).copy()
    for index in range(1, len(result)):
        result[index] = max(result[index], result[index - 1] + 1)
    return result


def _monthly_positions(schedule: str, times: np.ndarray, dates: pd.DatetimeIndex | None) -> np.ndarray:
    if dates is not None:
        periods = dates.to_period("M")
        positions: list[int] = []
        last_index = len(dates) - 1
        for period in periods.unique():
            month_positions = np.flatnonzero(periods == period)
            if schedule == "monthly_last":
                candidate = int(month_positions[-1])
                # 最后一个输入点仅在其确为自然月最后一个工作日时才是月度观察点。
                # 因此截断到期日不会被自动视为月末；节假日例外应以显式索引日程给出。
                is_business_month_end = dates[candidate] == dates[candidate] + pd.offsets.BMonthEnd(0)
                if candidate != last_index or is_business_month_end:
                    positions.append(candidate)
                continue
            ordinal = int(re.fullmatch(r"monthly_(\d+)(?:st|nd|rd|th)", schedule).group(1))
            if len(month_positions) >= ordinal:
                positions.append(int(month_positions[ordinal - 1]))
        return np.asarray(positions, dtype=int)
    # 无真实日期的Monte Carlo采用合同起点为锚点的月度网格。第n个交易日按每月
    # 21个交易日折算；不根据当前子路径的长度重新分配月份。
    if schedule == "monthly_last":
        offset = 1.0
    else:
        ordinal = int(re.fullmatch(r"monthly_(\d+)(?:st|nd|rd|th)", schedule).group(1))
        offset = min(ordinal, 21) / 21.0
    targets = _contract_grid_targets(times, 12, offset)
    return _nearest_nonterminal_positions(times, targets)


def _contract_grid_targets(times: np.ndarray, periods_per_year: int, offset: float) -> np.ndarray:
    """返回落在当前绝对合同时间窗口内的周期观察目标时点。

    ``offset``以一个周期为单位：周末为1，周内第n个交易日为n/5；月末为1，
    月内第n个交易日为min(n,21)/21。路径起点若本身是一个观察时点可以保留，
    但路径终点不因无日期的近似网格而自动加入观察集合。
    """
    if periods_per_year <= 0 or not 0.0 < offset <= 1.0:
        raise FormulaError("周期观察网格参数无效")
    start, end = float(times[0]), float(times[-1])
    first = int(np.ceil(start * periods_per_year - offset - 1e-12))
    last = int(np.floor(end * periods_per_year - offset + 1e-12))
    indices = np.arange(max(first, 0), last + 1, dtype=float)
    targets = (indices + offset) / periods_per_year
    return targets[(targets >= start - 1e-12) & (targets < end - 1e-12)]


def _nearest_nonterminal_positions(times: np.ndarray, targets: np.ndarray) -> np.ndarray:
    """将无日期周期目标映射到最近模拟网格点，且不把终点视为自动观察日。"""
    positions: list[int] = []
    terminal = len(times) - 1
    for target in targets:
        right = int(np.searchsorted(times, target, side="left"))
        candidates = [index for index in (right - 1, right) if 0 <= index <= terminal]
        if not candidates:
            continue
        position = min(candidates, key=lambda index: abs(float(times[index]) - float(target)))
        if position != terminal:
            positions.append(position)
    return np.asarray(sorted(set(positions)), dtype=int)


def _first_time(value: object) -> float:
    vector = _event_vector(value)
    positions = np.flatnonzero(vector.values)
    return inf if not len(positions) else float(vector.times[positions[0]])


def _first_time_after(value: object, skipped_observations: object) -> float:
    """返回略过前n个观察期后的首次事件时点。"""
    vector = _event_vector(value)
    skipped = int(_nonnegative_number(skipped_observations, "first_time_after锁定观察期"))
    positions = np.flatnonzero(vector.values)
    positions = positions[positions >= skipped]
    return inf if not len(positions) else float(vector.times[positions[0]])


def _first_time_before(value: object, cutoff: object) -> float:
    """返回严格早于合同截止时点的首次事件，适用于明确排除到期日的观察。"""
    vector = _event_vector(value)
    end = _positive_number(cutoff, "first_time_before截止时点")
    positions = np.flatnonzero(vector.values & (vector.times < end))
    return inf if not len(positions) else float(vector.times[positions[0]])


def _first_time_levels(values: object, levels: object) -> float:
    """按每个观察期对应的障碍日程返回首次敲出时点。"""
    if not isinstance(values, ObservedValues):
        raise FormulaError("first_time_levels第一个参数必须为观察价格序列")
    thresholds = np.asarray(levels, dtype=float)
    if thresholds.ndim != 1 or thresholds.shape != values.values.shape:
        raise FormulaError("first_time_levels障碍日程必须与观察价格逐期对应")
    hits = np.flatnonzero(_numeric_relation(values.values, thresholds, "ge"))
    return inf if not len(hits) else float(values.times[hits[0]])


def _first_time_below_levels(values: object, levels: object) -> float:
    """按逐观察期障碍日程返回首次向下触发时点。"""
    if not isinstance(values, ObservedValues):
        raise FormulaError("first_time_below_levels第一个参数必须为观察价格序列")
    thresholds = np.asarray(levels, dtype=float)
    if thresholds.ndim != 1 or thresholds.shape != values.values.shape:
        raise FormulaError("first_time_below_levels障碍日程必须与观察价格逐期对应")
    hits = np.flatnonzero(_numeric_relation(values.values, thresholds, "le"))
    return inf if not len(hits) else float(values.times[hits[0]])


def _schedule_levels(values: object, schedule: object) -> np.ndarray:
    """将逐观察期障碍日程展开为与观察价格一一对应的数值序列。

    日程使用``[(1, level_1), ..., (n, level_n)]``，序号从1开始且必须完整覆盖
    本次观察集合。这是一种通用的合同日程表达，不包含产品专属分支。
    """
    if not isinstance(values, ObservedValues):
        raise FormulaError("schedule_levels第一个参数必须为观察价格序列")
    if not isinstance(schedule, Sequence) or isinstance(schedule, (str, bytes)):
        raise FormulaError("schedule_levels日程必须为(观察序号,水平)序列")
    levels = np.full(len(values.values), np.nan, dtype=float)
    for item in schedule:
        if not isinstance(item, Sequence) or isinstance(item, (str, bytes)) or len(item) != 2:
            raise FormulaError("schedule_levels日程项必须是(观察序号,水平)")
        ordinal, level = item
        if not isinstance(ordinal, int) or isinstance(ordinal, bool) or ordinal < 1:
            raise FormulaError("schedule_levels观察序号必须为正整数")
        # 日程可以覆盖完整合同期限，而当前历史或模拟路径只包含其中已发生的
        # 绝对观察期。无日期中途模拟不会把合同第13期错误重编号为本段第1期。
        positions = np.flatnonzero(values.ordinals == ordinal)
        if not len(positions):
            continue
        if len(positions) != 1 or np.isfinite(levels[positions[0]]):
            raise FormulaError("schedule_levels观察序号重复")
        levels[positions[0]] = _finite_number(level, "schedule_levels障碍水平")
    if not np.isfinite(levels).all():
        raise FormulaError("schedule_levels日程未完整覆盖观察集合")
    return levels


def _schedule_between(schedule: object, lower: object, upper: object) -> bool:
    """校验(观察序号,水平)日程严格递增且所有水平位于开区间内。"""
    if not isinstance(schedule, Sequence) or isinstance(schedule, (str, bytes)) or not schedule:
        raise FormulaError("schedule_between日程必须为非空(观察序号,水平)序列")
    lower_value = _finite_number(lower, "schedule_between下界")
    upper_value = _finite_number(upper, "schedule_between上界")
    if lower_value >= upper_value:
        return False
    prior_ordinal = 0
    for item in schedule:
        if not isinstance(item, Sequence) or isinstance(item, (str, bytes)) or len(item) != 2:
            raise FormulaError("schedule_between日程项必须是(观察序号,水平)")
        ordinal, level = item
        if not isinstance(ordinal, int) or isinstance(ordinal, bool) or ordinal <= prior_ordinal:
            return False
        level_value = _finite_number(level, "schedule_between障碍水平")
        if not lower_value < level_value < upper_value:
            return False
        prior_ordinal = ordinal
    return True


def _schedule_matches_ratios(schedule: object, reference: object, ratios: object) -> bool:
    """校验观察障碍日程按1基连续编号，并等于参考价格乘以逐期比例。"""
    if not isinstance(schedule, Sequence) or isinstance(schedule, (str, bytes)):
        raise FormulaError("schedule_matches_ratios日程必须为(观察序号,水平)序列")
    if not isinstance(ratios, Sequence) or isinstance(ratios, (str, bytes)) or not ratios:
        raise FormulaError("schedule_matches_ratios比例必须为非空序列")
    if len(schedule) != len(ratios):
        return False
    reference_value = _finite_number(reference, "schedule_matches_ratios参考价格")
    for expected_ordinal, (item, ratio) in enumerate(zip(schedule, ratios), start=1):
        if not isinstance(item, Sequence) or isinstance(item, (str, bytes)) or len(item) != 2:
            raise FormulaError("schedule_matches_ratios日程项必须是(观察序号,水平)")
        ordinal, level = item
        if ordinal != expected_ordinal:
            return False
        level_value = _finite_number(level, "schedule_matches_ratios障碍水平")
        ratio_value = _finite_number(ratio, "schedule_matches_ratios比例")
        if not np.isclose(level_value, reference_value * ratio_value, rtol=0.0, atol=1e-10):
            return False
    return True


def _period_count(tenor: object, periods_per_year: object) -> int:
    """Convert a tenor into a whole number of regular contractual periods."""

    tenor_value = _positive_number(tenor, "period_count期限")
    frequency_value = _positive_number(periods_per_year, "period_count年频率")
    raw_count = tenor_value * frequency_value
    rounded_count = int(round(raw_count))
    if rounded_count < 1 or not np.isclose(raw_count, rounded_count, rtol=0.0, atol=1e-10):
        raise FormulaError("合同期限必须对应完整观察期数")
    return rounded_count


def _linear_schedule(
    count: object,
    reference: object,
    first_ratio: object,
    ratio_step: object,
) -> list[tuple[int, float]]:
    """Build a complete 1-based schedule with a constant ratio step."""

    period_total = _positive_integer(count, "linear_schedule期数")
    reference_value = _finite_number(reference, "linear_schedule参考价格")
    first_value = _finite_number(first_ratio, "linear_schedule首期比例")
    step_value = _finite_number(ratio_step, "linear_schedule比例步长")
    return [
        (ordinal, reference_value * (first_value + (ordinal - 1) * step_value))
        for ordinal in range(1, period_total + 1)
    ]


def _terminal_schedule(
    count: object,
    reference: object,
    regular_ratio: object,
    terminal_ratio: object,
) -> list[tuple[int, float]]:
    """Build a complete schedule whose final period uses a distinct ratio."""

    period_total = _positive_integer(count, "terminal_schedule期数")
    reference_value = _finite_number(reference, "terminal_schedule参考价格")
    regular_value = _finite_number(regular_ratio, "terminal_schedule常规比例")
    terminal_value = _finite_number(terminal_ratio, "terminal_schedule到期比例")
    return [
        (
            ordinal,
            reference_value * (terminal_value if ordinal == period_total else regular_value),
        )
        for ordinal in range(1, period_total + 1)
    ]


def _truncate_schedule(schedule: object, count: object) -> list[tuple[int, float]]:
    """Keep sparse contractual events that occur within the selected tenor."""

    period_total = _positive_integer(count, "truncate_schedule期数")
    if not isinstance(schedule, Sequence) or isinstance(schedule, (str, bytes)):
        raise FormulaError("truncate_schedule日程必须为(观察序号,水平)序列")
    result: list[tuple[int, float]] = []
    prior_ordinal = 0
    for item in schedule:
        if not isinstance(item, Sequence) or isinstance(item, (str, bytes)) or len(item) != 2:
            raise FormulaError("truncate_schedule日程项必须是(观察序号,水平)")
        ordinal, level = item
        if not isinstance(ordinal, int) or isinstance(ordinal, bool) or ordinal <= prior_ordinal:
            raise FormulaError("truncate_schedule观察序号必须严格递增")
        prior_ordinal = ordinal
        if ordinal <= period_total:
            result.append((ordinal, _finite_number(level, "truncate_schedule障碍水平")))
    return result


def _step_levels(values: object, schedule: object, activation: object = "on") -> np.ndarray:
    """按合同时间分段展开障碍水平。

    日程使用``[(起始时点,水平), ...]``，第一个起始时点必须为0。每个观察时点
    activation=on时新水平在起始时点生效；activation=after时在起始时点后的
    首个观察时点生效，适用于周年当日仍沿用上一档的合同条款。
    """
    if not isinstance(values, ObservedValues):
        raise FormulaError("step_levels第一个参数必须为观察价格序列")
    if not isinstance(schedule, Sequence) or isinstance(schedule, (str, bytes)) or not schedule:
        raise FormulaError("step_levels日程必须为非空(起始时点,水平)序列")
    starts: list[float] = []
    levels: list[float] = []
    for item in schedule:
        if not isinstance(item, Sequence) or isinstance(item, (str, bytes)) or len(item) != 2:
            raise FormulaError("step_levels日程项必须是(起始时点,水平)")
        starts.append(_nonnegative_number(item[0], "step_levels起始时点"))
        levels.append(_finite_number(item[1], "step_levels障碍水平"))
    if starts[0] != 0.0 or any(later <= earlier for earlier, later in zip(starts, starts[1:])):
        raise FormulaError("step_levels日程起始时点须从0开始且严格递增")
    if activation not in {"on", "after"}:
        raise FormulaError("step_levels生效方式仅支持on或after")
    side = "right" if activation == "on" else "left"
    positions = np.searchsorted(np.asarray(starts), values.times, side=side) - 1
    positions[values.times <= starts[0]] = 0
    return np.asarray(levels, dtype=float)[positions]


def _first_time_below_schedule(values: object, schedule: object) -> float:
    """在稀疏合同观察日程中返回首次严格跌破对应水平的时点。"""
    if not isinstance(values, ObservedValues):
        raise FormulaError("first_time_below_schedule第一个参数必须为观察价格序列")
    if not isinstance(schedule, Sequence) or isinstance(schedule, (str, bytes)):
        raise FormulaError("first_time_below_schedule日程必须为(观察序号,水平)序列")
    hits: list[int] = []
    seen: set[int] = set()
    for item in schedule:
        if not isinstance(item, Sequence) or isinstance(item, (str, bytes)) or len(item) != 2:
            raise FormulaError("first_time_below_schedule日程项必须是(观察序号,水平)")
        ordinal, level = item
        if not isinstance(ordinal, int) or isinstance(ordinal, bool) or not 1 <= ordinal <= len(values.values):
            raise FormulaError("first_time_below_schedule观察序号超出范围")
        if ordinal in seen:
            raise FormulaError("first_time_below_schedule观察序号重复")
        seen.add(ordinal)
        if values.values[ordinal - 1] < _finite_number(level, "first_time_below_schedule障碍水平"):
            hits.append(ordinal - 1)
    return inf if not hits else float(values.times[min(hits)])


def _first_observation_on_or_after(values: object, event_time: object) -> float:
    """返回事件发生当日或其后首个约定观察日；事件未发生时返回无穷。"""
    if not isinstance(values, ObservedValues):
        raise FormulaError("first_observation_on_or_after第一个参数必须为观察价格序列")
    if event_time == inf:
        return inf
    start = _nonnegative_number(event_time, "first_observation_on_or_after事件时点")
    positions = np.flatnonzero(values.times >= start)
    return inf if not len(positions) else float(values.times[positions[0]])


def _terminal_event_time(value: object, maturity: object) -> float:
    """仅在实际到期点属于给定观察集合且满足事件时返回到期时点。

    周/月度日程不会因为价格路径结束而自动加入到期点；本函数只用于合同
    明确把最后一档事件限定在到期观察日的情形。
    """
    vector = _event_vector(value)
    terminal = _nonnegative_number(maturity, "terminal_event_time到期时点")
    if not len(vector.times) or not vector.includes_path_endpoint:
        return inf
    return float(terminal) if bool(vector.values[-1]) else inf


def _reset_knockout_time(
    knockout_prices: object,
    reset_time: object,
    initial_knockout_level: object,
    reset_knockout_level: object,
) -> float:
    """重置观察日之前按初始敲出线、当日及之后按重置线判断首次敲出。"""
    if not isinstance(knockout_prices, ObservedValues):
        raise FormulaError("reset_knockout_time第一个参数必须为敲出观察价格序列")
    reset = inf if reset_time == inf else _nonnegative_number(reset_time, "reset_knockout_time重置时点")
    h_initial = _finite_number(initial_knockout_level, "reset_knockout_time初始敲出线")
    h_reset = _finite_number(reset_knockout_level, "reset_knockout_time重置敲出线")
    thresholds = np.where(knockout_prices.times >= reset, h_reset, h_initial)
    hits = np.flatnonzero(knockout_prices.values >= thresholds)
    return inf if not len(hits) else float(knockout_prices.times[hits[0]])


def _effective_hedge_time(
    raw_hedge_time: object,
    knockout_time: object,
    knockin_time: object,
    ki_history_policy: object,
) -> float:
    """按确认书定义避险观察日是否计入历史敲入范围。"""
    if ki_history_policy not in {"include_hedge_date", "exclude_hedge_date"}:
        raise FormulaError("effective_hedge_time敲入历史口径无效")
    raw = inf if raw_hedge_time == inf else _nonnegative_number(raw_hedge_time, "effective_hedge_time避险时点")
    knockout = inf if knockout_time == inf else _nonnegative_number(knockout_time, "effective_hedge_time敲出时点")
    knockin = inf if knockin_time == inf else _nonnegative_number(knockin_time, "effective_hedge_time敲入时点")
    if raw == inf or raw >= knockout:
        return inf
    if ki_history_policy == "include_hedge_date":
        return raw if raw < knockin else inf
    return raw if raw <= knockin else inf


def _first_value(values: object, event: object) -> float:
    """返回事件首次成立时对应的观察价格。"""
    if not isinstance(values, ObservedValues):
        raise FormulaError("first_value第一个参数必须为观察价格序列")
    vector = _event_vector(event, values.times)
    if not np.array_equal(vector.times, values.times):
        raise FormulaError("first_value的价格与事件日程不一致")
    positions = np.flatnonzero(vector.values)
    return inf if not len(positions) else float(values.values[positions[0]])


def _count(value: object) -> int:
    if isinstance(value, EventVector): return int(value.values.sum())
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)): return len(value)
    raise FormulaError("count仅支持观察事件或序列")


def _count_until(value: object, cutoff: object) -> int:
    """统计不晚于cutoff的观察数；cutoff=inf表示整个观察集合。"""
    end = inf if cutoff == inf else _nonnegative_number(cutoff, "count_until截止时点")
    if isinstance(value, EventVector):
        return int(np.sum(value.values & (value.times <= end)))
    if isinstance(value, ObservedValues):
        return int(np.sum(value.times <= end))
    raise FormulaError("count_until仅支持观察事件或观察价格序列")


def _exact_observation_count(values: object, expected: object) -> int:
    """确认运行路径与合同约定观察日数一致，避免分母与实际观察次数错配。"""
    if not isinstance(values, ObservedValues):
        raise FormulaError("exact_observation_count第一个参数必须为观察价格序列")
    required = int(_positive_number(expected, "exact_observation_count合同观察日数"))
    if required != expected:
        raise FormulaError("exact_observation_count合同观察日数必须为正整数")
    actual = len(values.values)
    if actual != required:
        raise FormulaError(f"观察日数{actual}与合同n_obs={required}不一致；请按实际观察日程覆盖n_obs")
    return actual


def _observation_ordinal(value: object, event_time: object) -> float:
    """返回事件在观察集合中的1基序号；事件未发生时返回无穷。"""
    if not isinstance(value, ObservedValues):
        raise FormulaError("observation_ordinal第一个参数必须为观察价格序列")
    if event_time == inf:
        return inf
    event = _nonnegative_number(event_time, "observation_ordinal事件时点")
    positions = np.flatnonzero(np.isclose(value.times, event, rtol=0.0, atol=1e-12))
    if not len(positions):
        raise FormulaError("observation_ordinal事件时点不属于观察集合")
    return float(positions[0] + 1)


def _realized_variance(value: object, annualization_days: object) -> float:
    series = value.values if isinstance(value, ObservedValues) else np.asarray(value, dtype=float)
    if len(series) < 2: raise FormulaError("方差计算至少需要两个观察值")
    if not np.isfinite(series).all() or (series <= 0).any():
        raise FormulaError("realized_variance要求全部观察价格严格为正")
    annual = _positive_number(annualization_days, "annualization_days")
    log_return = np.diff(np.log(series))
    return float(annual * np.mean(log_return ** 2))


def _accumulated_quantity(
    prices: object,
    knockout_level: object,
    strike: object,
    base_quantity: object,
    multiplier: object,
    lockout_observations: object,
    expected_observations: object,
    maturity: object,
) -> float:
    """标准累购的逐观察日成交量与保股期敲出规则。"""
    if not isinstance(prices, ObservedValues):
        raise FormulaError("accumulated_quantity第一个参数必须为观察价格序列")
    h_out = _finite_number(knockout_level, "accumulated_quantity敲出价")
    k = _finite_number(strike, "accumulated_quantity执行价")
    q = _positive_number(base_quantity, "accumulated_quantity基础数量")
    m = _positive_number(multiplier, "accumulated_quantity累计倍数")
    lock = int(_nonnegative_number(lockout_observations, "accumulated_quantity保股期"))
    expected = int(_positive_number(expected_observations, "accumulated_quantity观察日数"))
    if float(expected_observations) != expected:
        raise FormulaError("accumulated_quantity观察日数必须为正整数")
    end = _positive_number(maturity, "accumulated_quantity到期时点")
    values = prices.values
    if len(values) > expected:
        raise FormulaError("accumulated_quantity观察价格数量超过n_obs")
    # The last frozen observation may precede a non-trading civil maturity.
    # A history prefix remains valid while a complete schedule must match n_obs.
    complete = prices.covers_complete_schedule or (not prices.frozen_schedule and prices.times[-1] >= end - 1e-12)
    if complete and len(values) != expected:
        raise FormulaError("accumulated_quantity完整到期路径必须正好覆盖n_obs个观察日")
    knockout_events = _numeric_relation(values, h_out, "ge")
    if knockout_events is None:
        raise FormulaError("accumulated_quantity敲出比较必须为数值")
    hits = np.flatnonzero(knockout_events)
    knockout_index = int(hits[0]) if len(hits) else None
    if knockout_index is None:
        variable_days = range(len(values))
        forced_days: range = range(0)
    elif knockout_index + 1 <= lock:
        variable_days = range(knockout_index)
        forced_days = range(knockout_index, min(lock, len(values)))
    else:
        variable_days = range(knockout_index)
        forced_days = range(0)
    quantity = 0.0
    for index in variable_days:
        below_strike = _numeric_relation(values[index], k, "lt")
        if below_strike is None:
            raise FormulaError("accumulated_quantity执行价比较必须为数值")
        quantity += q * (1.0 + (m - 1.0) * float(below_strike))
    return float(quantity + len(forced_days) * q)


def _cash(time: object, amount: object) -> CashflowBundle:
    return CashflowBundle((Cashflow(_nonnegative_number(time, "cash时间"), _finite_number(amount, "cash金额")),))


def _compare(left: object, right: object, operator: ast.cmpop) -> Any:
    relation = (
        "lt" if isinstance(operator, ast.Lt) else "le" if isinstance(operator, ast.LtE)
        else "gt" if isinstance(operator, ast.Gt) else "ge" if isinstance(operator, ast.GtE)
        else "eq" if isinstance(operator, ast.Eq) else "ne" if isinstance(operator, ast.NotEq) else None
    )
    if relation is None:
        raise FormulaError("不允许的比较运算")
    numeric_result = _numeric_relation(left, right, relation)
    if numeric_result is not None:
        return numeric_result
    if isinstance(operator, ast.Lt): return left < right  # type: ignore[operator]
    if isinstance(operator, ast.LtE): return left <= right  # type: ignore[operator]
    if isinstance(operator, ast.Gt): return left > right  # type: ignore[operator]
    if isinstance(operator, ast.GtE): return left >= right  # type: ignore[operator]
    if isinstance(operator, ast.Eq): return left == right
    if isinstance(operator, ast.NotEq): return left != right
    raise FormulaError("不允许的比较运算")


def _event_vector(value: object, times: Sequence[float] | None = None) -> EventVector:
    if isinstance(value, EventVector): return value
    if isinstance(value, (bool, np.bool_)):
        grid = np.asarray(times if times is not None else [0.0], dtype=float)
        return EventVector(np.full(grid.shape, bool(value)), grid)
    raise FormulaError("此公式位置需要路径事件布尔序列")


def _event_times(left: object, right: object) -> np.ndarray:
    if isinstance(left, EventVector): return left.times
    if isinstance(right, EventVector): return right.times
    return np.asarray([0.0])


def _coerce_bool(value: object) -> bool:
    if isinstance(value, (bool, np.bool_)): return bool(value)
    if isinstance(value, np.ndarray) and value.size == 1: return bool(value.item())
    raise FormulaError("路径条件与分段定义域必须返回标量布尔值")


def _positive_number(value: object, label: str) -> float:
    number = _finite_number(value, label)
    if number <= 0: raise FormulaError(f"{label}必须为正数")
    return number


def _positive_integer(value: object, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, np.integer)) or int(value) <= 0:
        raise FormulaError(f"{label}必须为正整数")
    return int(value)


def _nonnegative_number(value: object, label: str) -> float:
    number = _finite_number(value, label)
    if number < 0: raise FormulaError(f"{label}不得为负")
    return number


def _finite_number(value: object, label: str) -> float:
    if not isinstance(value, (int, float, np.number)) or isinstance(value, bool) or not np.isfinite(float(value)):
        raise FormulaError(f"{label}必须为有限数值")
    return float(value)


def _bounded_formula_value(value: Any) -> Any:
    if isinstance(value, CashflowBundle):
        return value
    try:
        array = np.asarray(value)
    except (TypeError, ValueError) as error:
        raise FormulaError("公式算术仅支持数值或现金流") from error
    if array.size > _MAX_FORMULA_ITEMS or not np.issubdtype(array.dtype, np.number):
        raise FormulaError("公式算术结果超过受限范围")
    try:
        numeric = np.asarray(array, dtype=float)
    except (TypeError, ValueError, OverflowError) as error:
        raise FormulaError("公式算术结果不是受限数值") from error
    if not np.isfinite(numeric).all() or (np.abs(numeric) > _MAX_ABS_FORMULA_VALUE).any():
        raise FormulaError("公式算术结果超过受限范围")
    return value


def _json_scalar_map(values: Mapping[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in values.items():
        if isinstance(value, np.generic): result[key] = value.item()
        elif isinstance(value, np.ndarray): result[key] = value.tolist()
        else: result[key] = value
    return result
