# Pricer模块指南

## 职责

基于`ResolvedContract`、`PricingConfig`、受控市场资产和必要的`ObservedContractState`估值，返回PV、公平条款、Greeks、情景、风险分析、误差和限制。历史敲入、敲出、票息触发和存续时间统计由Backtester负责。

## 实施基座

Pricer必须以`src/engines/pricing_core/`内部数值基座为唯一引擎，保留迁移基线中的闭式、Monte Carlo、Greeks、反解、随机源、市场快照、Golden和ADR证据后扩展与提升。允许修改接口、目录、Facade、Catalog和STANDARD命名；不得脱离该基座从零重写，也不得长期保留两套正式引擎。

## 输入与输出

```text
PricingInput = {ResolvedContract, PricingConfig, market_data_refs, trading_calendar_ref?, pricing_objective?}
```

`pricing_objective`只接受用户显式选择的`{"mode":"valuation"}`或受控目标`{"mode":"fair_parameter","target_id":"..."}`。省略时保持普通PV估值及既有结果口径；不得从普通条款、自然语言或调用方自报目标推断反解目标。公平参数结果单独返回`solution`、`base_parameter`、`residual`和`solution_uncertainty`；只有`quote_eligible=true`且`formal_quote_status`不是`research_only`时才显示正式报价资格，否则必须显示研究估计及受控原因，不得把公平参数结果当作普通PV或Quote。

`pricing_methods`来自OptionReg，实际运行能力来自Pricer，两者不相交则返回`unsupported`。存续期路径结构必须先由可见不复权价格形成`ObservedContractState`；历史不足时不得假设未发生事件。该状态应由Core正式协议独立冻结，Pricer不得把它伪装为定价参数。

公开定价方法只有`Analytical`和`Monte Carlo`。支持解析定价的产品优先使用`Analytical`；该公开类别内部可路由至香草、二元、障碍及静态复制等经过产品级验证的实现，但内部模型名称不进入公开合同。仅支持路径模拟的产品必须使用`Monte Carlo`。

Monte Carlo严格使用调用方显式提供的`path_count`，只校验为正整数，不代替用户选择路径数或设置精度阈值。低路径数逻辑探针仅存在于测试夹具，不属于正式页面或Tool协议。

面向用户的估值、回测和报告只展示百分比。`S0Raw`仅用于真实价格与标准化合同换算，不作为面向用户字段；内部现金流、点数、金额和名义本金不得投影到页面、正式Tool、CSV或报告。内部每100点数仅用于Golden、共同随机数回归和可复验计算。

## 交互边界

- 页面正式运行只能通过App任务上下文取得已绑定的`DataAssetRef`和必要的`trading-calendar`。页面不得提交物理路径、读取本地CSV或自行伪造行情、日历和合同状态。
- 运行前先复用当前任务覆盖本次标的、估值日、字段和口径的DataAssetRef。无法复用且需要新数据时，先确认iFind，再按DataFetcher指南取得数据。运行时数据能力不可用则保留估值条件并停止，不猜测市场输入或无提示改用本地数据。
- 历史行情DataAssetRef只提供现价、历史波动率和历史数据。路径型Monte Carlo另用独立`trading-calendar`引用读取未来交易日期，未来价格始终由Pricer模拟。
- 用户输入日期保留为`requested_valuation_date`，未填写时默认今天。若请求日尚无可用数据，则采用DataAssetRef中所有标的均有覆盖的最新数据日作为`effective_valuation_session`；不得使用请求区间的截止日冒充实际数据日。结果同时披露请求日期、有效估值日和有效到期交易日。
- Analytical和仅终值的普通香草Monte Carlo不强制获取完整未来日历；离散路径Monte Carlo必须覆盖有效估值交易日至合同到期日前最后一个交易日。
- 路径模拟使用完整ACT/365交易日时间轴，合同的`daily`、`monthly_last`等规则在完整路径上选择观察日，不按`n_obs`平均抽样。
- 用户未指定估值日且任务使用最新行情时，以当前可验证交易日为估值日并在结果中说明，不为该默认值单独追问。
- 缺少会改变估值含义的合同、市场数据或存续期已观察状态时，一次列出全部缺口；不得逐字段连续追问，也不得用模型猜测数值。
- 单独调用直接给出估值、Greeks、情景、精度和限制，不自动生成报告。原始JSON仅在用户明确要求或系统集成时展示。
- 用户明确改动期限、波动率假设、估值日或模型参数并要求重新估值时，Host只合并该次变更并签发新的合同与估值运行；清晰的“改为…重新估值”本身就是确认。
- 市场引用和估值结果只使用安装目录之外的项目Store；模块不接受或暴露物理路径。

## 用户可见进度

以下文案直接面向用户，不包含Tool名、JSON字段、运行标识、环境名称或物理路径。开始提示一次；估值或精度检验明显耗时时才发送进度，进度最多更新1至2次，不要求用户回复，完成后直接给结果。

组合分析或正式交付中由顶层工作流统一发进度，本模块不重复发送以下文案。

- 开始：我先核对合同、市场数据和估值口径，再进行估值与风险计算。
- 进度：核心估值已经完成，正在检查敏感度、情景结果和计算精度。
- 完成：估值完成。下面给出价值、主要风险指标、精度判断和适用限制。
- 失败：本次估值条件不完整或当前方法不支持。我会一次列明缺口及其影响，不猜测市场输入或金融数值。
