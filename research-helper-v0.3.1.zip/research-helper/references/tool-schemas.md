# Tool schemas

All tools read one UTF-8 JSON object and write one JSON object to standard output. On Windows, prefer a UTF-8 input file with `--input path.json` so Chinese text is not corrupted by the shell.

Workflow responses include `next_action` and `next_prompt`. The agent must either continue automatically or ask that one concrete question; it must not stop after reporting a status.

## `environment-check`

No input is required. It reports runtime discovery, required imports, credential presence, and configured OptionHelper availability. `missing_required_credentials` blocks a research run; `missing_optional_credentials` only describes degraded capabilities. It never prints credential values.

## `analyze-request`

Input:

```json
{
  "request": "未来一个月机器人行业的投资机会",
  "include_target_proposal": true
}
```

Output includes `brief`, `rendered_brief`, and `target_proposal`. The proposal is not an analyst confirmation.

## `verify-target`

Input:

```json
{
  "brief": {},
  "confirmation": {
    "market": "A股",
    "research_mode": "industry",
    "research_scope": "机器人",
    "underlying_code": "",
    "theme_basket_codes": [],
    "research_only": true
  }
}
```

Use the complete `brief` returned by `analyze-request`. The normalized confirmation schema is defined by the current Research Helper engine and may contain additional mapping fields supplied by the UI or agent.

## `prepare-viewpoints`

Input:

```json
{
  "brief": {},
  "event_evidence": {},
  "overrides_path": ""
}
```

Use the verified `brief` returned by `verify-target`. The command retrieves research data and returns all candidate viewpoints, `suggested_ids`, and `next_prompt`; it does not generate a report. For an event-driven study, pass the analyst-confirmed evidence package.

## `run-research`

Input:

```json
{
  "request": "未来一个月机器人行业的投资机会",
  "market_confirmation": {},
  "event_evidence": {},
  "logic_pick_ids": ["V1", "V4", "doc_2"],
  "auto_select_viewpoints": false,
  "allow_model_fallback": false,
  "pdf": true,
  "optionhelper": "",
  "timeout_seconds": 3600,
  "client_constraints": {
    "horizon": "3个月",
    "max_loss": "100%",
    "principal_fluctuation": true,
    "return_preference": ""
  }
}
```

`optionhelper` may be empty, `recommend`, or `quote`. Formal quote requests require the separately configured OptionHelper Skill.

The runtime records the actual PDF page count but does not reject a successfully exported report for exceeding one page. OptionHelper recommendation treats a `100%` maximum-loss entry as non-restrictive during candidate generation while retaining the original client constraint for the formal quote and audit trail.

`logic_pick_ids` is preferred to numeric positions because refreshed data can reorder candidates. `run-research` refuses to start without a confirmed selection unless `auto_select_viewpoints` is explicitly `true`.

When a required confirmation is absent, the command cancels the child run safely and returns `status: "needs_input"` plus `required_type`, `required_payload`, `next_action`, and `next_prompt`. Obtain the analyst's answer and continue automatically.

## `latest-run`

Optional input:

```json
{"run_id": "run-YYYYMMDD-HHMMSS-abcdef"}
```

Without `run_id`, it returns the most recently modified run summary from the configured user-data directory.

