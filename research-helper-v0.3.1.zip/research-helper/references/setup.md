# Local setup

## Python environment

Use Python 3.10 or newer in a dedicated environment. Install the packages listed in `requirements-skill.txt`. On Windows, install `iFinDPy` separately from the official iFinD SDK when the desktop SDK route is required. On macOS, configure the official iFinD HTTP API refresh token.

Run:

```bash
python scripts/environment_check.py
```

The command reports missing packages and whether credentials are present. It does not make a network request or reveal secret values.
DeepSeek and iFinD are required for a normal research run. Tavily is optional; without it, public-evidence discovery uses the lower-coverage Bing RSS fallback.

## Local configuration

Never write credentials into the Skill folder. Use environment variables or the current user's Research Helper `config.local.json`.

Default configuration locations:

- Windows: `C:\Users\<username>\AppData\Local\ResearchHelper\config.local.json`
- macOS: `~/Library/Application Support/ResearchHelper/config.local.json`
- Linux: `${XDG_DATA_HOME:-~/.local/share}/ResearchHelper/config.local.json`

On Windows the Skill deliberately derives the real user path from `USERPROFILE`. Codex may map `LOCALAPPDATA` to a temporary sandbox directory during execution; credentials must remain in the normal user profile and must not be copied into that sandbox.

For the Windows desktop SDK route, the runtime discovers common Anaconda and Python installations. If the official SDK is elsewhere, set `IFIND_SDK_PATH` in `config.local.json` to the directory containing `iFinDPy.py` and `ShellExport.dll`, or to the official SDK path already used by the desktop app. The runtime creates only a local path bridge under the user's Research Helper data directory; it does not copy the proprietary SDK into the Skill package.

Typical keys are:

```json
{
  "DEEPSEEK_API_KEY": "replace-locally",
  "IFIND_ACCOUNT": "replace-locally",
  "IFIND_PASSWORD": "replace-locally",
  "IFIND_SDK_PATH": "D:/path/to/official-ifind-sdk/bin/x64",
  "IFIND_REFRESH_TOKEN": "replace-locally-on-macos",
  "TAVILY_API_KEY": "replace-locally"
}
```

Only configure the applicable iFinD authentication route. The source Skill uses the adjacent project's local configuration. A packaged Skill uses the standard per-user Research Helper data directory unless `RESEARCH_HELPER_DATA_ROOT` is set.

## Package contents

`scripts/build_skill.py` creates a ZIP with a read-only runtime snapshot. The package excludes local configuration, source documents, prior reports, market-data caches, OptionHelper state, and quote results.

After upgrading the Research Helper project, rebuild the Skill ZIP so its runtime snapshot matches the current business rules.

