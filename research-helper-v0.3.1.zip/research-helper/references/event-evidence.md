# Event evidence

Use the event-evidence path only for an explicit external event such as an earnings release, policy announcement, IPO, product launch, accident, or merger. Market-state questions such as a sector pullback or valuation rotation use market data instead.

Confirm these fields before running an event report:

1. Event fact source text, source title, publisher, URL or uploaded-file reference, and date.
2. Industry mechanism source text and the mechanism it supports.
3. A-share exposure source text tied to the confirmed research object.
4. One or more combined chains that cite adopted evidence items.

Prefer original company, exchange, regulator, index-provider, and fund-manager disclosures. Then use established research institutions and authoritative financial media. Generic pages and price-only pages may help discovery but cannot by themselves prove a transmission relationship.

If the evidence is incomplete, return the missing categories to the analyst. Do not weaken the requirement or fill the gap from model memory.

