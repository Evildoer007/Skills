# Workflow and boundaries

## Route selection

Research Helper separates the data scope from the later quotation instrument.

- **Standard industry**: use a verified standard-industry node and its constituents. Choose this for established industry questions. Common normalized routes include robotics or humanoid robotics to automation equipment/mechanical equipment, wind power to wind-power equipment/electrical equipment, and brokerages to securities.
- **Analyst-selected theme basket**: use only companies explicitly selected by the analyst after company-level relevance review. Choose this for narrow or cross-industry themes whose constituent definition is subjective.
- **Theme ETF**: use the verified constituents of the ETF's actual tracking index. Choose this when the ETF itself is the intended research universe.

An ETF selected for later quotation does not change an industry or basket research scope.

## Required sequence

```text
customer request
    -> structured request analysis
    -> analyst confirms data scope
    -> market data and evidence retrieval
    -> analyst confirms event evidence when applicable
    -> candidate viewpoints
    -> analyst selects report viewpoints
    -> report generation and validation
    -> analyst chooses edit/export/OptionHelper/finish
    -> optional OptionHelper recommendation and quote
```

## Conversation behavior

The workflow advances on its own until analyst judgment is needed. At each checkpoint, show what was completed, what decision is required, the recommended choice, and one precise question. After the answer, proceed without requiring the analyst to say “继续”.

Do not ask a generic next-step question. The four valid analyst checkpoints are:

1. Confirm the market, data route, and target.
2. Confirm event evidence when the request concerns an explicit external event.
3. Select 2–3 candidate viewpoints or explicitly accept the suggested combination.
4. After generation, choose open/edit, export, OptionHelper, or finish.

If a tool returns `next_prompt`, use it as the basis for the question. A state such as `confirmed` or `completed` never justifies ending without the next question.

## Native report boundary

Only artifacts returned by `run-research` are Research Helper reports. Do not use an agent-authored HTML page, a generic PDF library, or a different layout to conceal a failed native export. Native reports may paginate according to their content; preserve and disclose the measured page count.

## Evidence roles

- **Event fact** confirms what happened, when, and to whom.
- **Industry mechanism** explains the supply, demand, price, capacity, policy, or technology mechanism.
- **A-share exposure** establishes why the confirmed company basket, standard industry, or ETF constituents are exposed.
- **Transmission chain** links the three layers without adding unsupported facts.

Search results are candidates. Adoption always requires source-text review.

## Delivery status

- HTML without a successful PDF export remains an editable research artifact.
- A successfully exported native PDF is deliverable regardless of page count; record the measured count.
- OptionHelper failure does not erase an already completed research report; record the quote failure separately.

## Current runtime behavior

- All studies require target confirmation before retrieval, including ordinary industry questions.
- ETF discovery normalizes common aliases before ranking verified candidates. A provider returning only one verified ETF is valid and should be disclosed rather than padded with unverified names.
- Theme-basket candidates require company-level relevance evidence; a concept-list match alone is insufficient.
- Charts with materially identical underlying data are deduplicated across viewpoints. Report-editor size choices are `auto`, `small`, `medium`, and `large` when the desktop editor is used.
- Formal OptionHelper quotes are independent from report delivery. Complex path-dependent structures may use 100,000 simulation paths and can take several minutes; the current process allowance is up to 15 minutes unless locally overridden.

