"""全局配置与运行环境处理。

关键约束（实测踩坑）：
本机常开着本地代理（如 Clash，127.0.0.1:7897）。akshare 的数据源
（东财 push2.eastmoney.com、新浪等）都是国内站点，经该代理转发到境外
出口时会 ProxyError 失败。因此所有取数操作前必须清掉代理环境变量。
打包成 exe 后用户若开着代理，同样会踩这个坑，故在此统一处理。
"""

from __future__ import annotations

import os
from contextlib import contextmanager

# akshare / 国内数据源默认直连，不走系统代理
_PROXY_ENV_KEYS = (
    "HTTP_PROXY",
    "HTTPS_PROXY",
    "http_proxy",
    "https_proxy",
    "ALL_PROXY",
    "all_proxy",
)


@contextmanager
def no_proxy():
    """临时清空代理环境变量，退出时恢复。用于包裹 akshare 调用。"""
    saved = {k: os.environ.get(k) for k in _PROXY_ENV_KEYS}
    for k in _PROXY_ENV_KEYS:
        os.environ.pop(k, None)
    os.environ["NO_PROXY"] = "*"
    try:
        yield
    finally:
        for k, v in saved.items():
            if v is not None:
                os.environ[k] = v
        os.environ.pop("NO_PROXY", None)


# ---- 凭证加载：环境变量优先，其次本地 config.local.json（已被 .gitignore 忽略）----
import json
from pathlib import Path
from .app_paths import CONFIG_PATH, DATA_CACHE_DIR, OPTIONHELPER_DIR, USER_DATA_ROOT

_PROJECT_ROOT = USER_DATA_ROOT
_LOCAL_CONFIG_PATH = CONFIG_PATH


def _load_local_config() -> dict:
    try:
        with open(_LOCAL_CONFIG_PATH, encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


_LOCAL = _load_local_config()


def _cred(key: str, default: str = "") -> str:
    """取凭证：环境变量优先，其次本地文件。"""
    return os.environ.get(key) or _LOCAL.get(key, default)


def _setting_bool(key: str, default: bool) -> bool:
    """读取本机布尔设置；环境变量仍优先于 config.local.json。"""
    raw = os.environ.get(key, _LOCAL.get(key, default))
    if isinstance(raw, bool):
        return raw
    return str(raw).strip().lower() not in {"0", "false", "no", "off", "否"}


# ---- DeepSeek / LLM 配置 ----
DEEPSEEK_API_KEY = _cred("DEEPSEEK_API_KEY")
DEEPSEEK_BASE_URL = os.environ.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com")
# 模型 ID 会随供应商升级而变化。配置只保存分析师明确选择的逻辑档位；账号当前
# 可用目录由 GET /models 动态取得。DEEPSEEK_MODEL 继续作为旧版配置兼容入口。
_LEGACY_DEEPSEEK_MODEL = str(_LOCAL.get("DEEPSEEK_MODEL") or "").strip()
DEEPSEEK_FAST_MODEL = str(
    os.environ.get("RESEARCH_HELPER_RUN_FAST_MODEL")
    or os.environ.get("DEEPSEEK_FAST_MODEL")
    or _LOCAL.get("DEEPSEEK_FAST_MODEL")
    or _LEGACY_DEEPSEEK_MODEL
    or "deepseek-flash"
).strip()
DEEPSEEK_QUALITY_MODEL = str(
    os.environ.get("RESEARCH_HELPER_RUN_QUALITY_MODEL")
    or os.environ.get("DEEPSEEK_QUALITY_MODEL")
    or _LOCAL.get("DEEPSEEK_QUALITY_MODEL")
    or _LEGACY_DEEPSEEK_MODEL
    or "deepseek-flash"
).strip()
DEEPSEEK_FALLBACK_MODEL = str(
    os.environ.get("DEEPSEEK_FALLBACK_MODEL")
    or _LOCAL.get("DEEPSEEK_FALLBACK_MODEL")
    or "deepseek-flash"
).strip()
# OptionHelper 等尚未区分逻辑档位的旧调用默认使用质量档。
DEEPSEEK_MODEL = DEEPSEEK_QUALITY_MODEL

# ---- iFinD（同花顺 quant API）配置 ----
# 数据源主力。注意：账户有周度取数上限，静态/慢变数据须缓存到本地（见 data_cache/）。
IFIND_ACCOUNT = _cred("IFIND_ACCOUNT")
IFIND_PASSWORD = _cred("IFIND_PASSWORD")
# macOS 无本地 iFinDPy SDK，使用官方 HTTP API。Refresh Token 只保存在当前
# 用户配置或环境变量中；短期 Access Token 仅驻留内存，不写日志或运行底稿。
IFIND_REFRESH_TOKEN = _cred("IFIND_REFRESH_TOKEN")
IFIND_API_BASE_URL = str(
    _cred("IFIND_API_BASE_URL", "https://quantapi.51ifind.com/api/v1")
).strip().rstrip("/")

# ---- 公开证据检索 ----
# Tavily 负责高质量 URL 发现及清洗正文；无 Key、调用失败或额度不足时可回退
# 到无需密钥的 Bing RSS。Key 只从环境变量或被 Git 忽略的本机配置读取。
TAVILY_API_KEY = _cred("TAVILY_API_KEY")
SEARCH_PROVIDER = str(_cred("SEARCH_PROVIDER", "tavily") or "tavily").strip().lower()
SEARCH_DEPTH = str(_cred("SEARCH_DEPTH", "basic") or "basic").strip().lower()
SEARCH_COUNTRY = str(_cred("SEARCH_COUNTRY", "china") or "china").strip().lower()
SEARCH_LANGUAGE = str(_cred("SEARCH_LANGUAGE", "zh-cn") or "zh-cn").strip().lower()
SEARCH_BING_FALLBACK = _setting_bool("SEARCH_BING_FALLBACK", True)

# 本地数据缓存目录（静态数据取一次存这里，规避配额）
DEEPSEEK_MODEL_CACHE = DATA_CACHE_DIR / "deepseek_models.json"


def model_for_purpose(purpose: str = "quality") -> str:
    """按任务逻辑选择模型；运行级覆盖在每次调用时读取，支持显式降级。"""
    slot = "fast" if str(purpose).strip().lower() == "fast" else "quality"
    if slot == "fast":
        return str(os.environ.get("RESEARCH_HELPER_RUN_FAST_MODEL") or DEEPSEEK_FAST_MODEL)
    return str(os.environ.get("RESEARCH_HELPER_RUN_QUALITY_MODEL") or DEEPSEEK_QUALITY_MODEL)


def has_llm() -> bool:
    """是否配置了可用的 DeepSeek key。未配置时 planner/writer 直接返回错误提示配置，
    绝不用假数据兜底（防幻觉原则：宁可不出，也不造假）。"""
    return bool(DEEPSEEK_API_KEY)


def has_ifind() -> bool:
    """是否配置了 SDK 账号或官方 HTTP API Refresh Token。"""
    return bool((IFIND_ACCOUNT and IFIND_PASSWORD) or IFIND_REFRESH_TOKEN)


# ---- OptionHelper Skill（正式参考报价）集成配置 ----
# 新版是只读 Skill 安装目录，项目数据固定写入本仓库下的 data/result/.optionhelper。
# 本地升级由 tools/optionhelper_install.py 显式配置已验证的独立 Skill 与解释器。
# 未配置时仍兼容旧桌面安装；源码 pull 不会自动改变已激活 Skill。
# 旧 OPTIONHELPER_ROOT 不再读取，避免误连旧版工程。
_DESKTOP_OPTIONHELPER_SKILL = Path.home() / "Desktop" / "option-helper_3" / "option-helper"
OPTIONHELPER_SKILL_ROOT = _cred(
    "OPTIONHELPER_SKILL_ROOT",
    str(_DESKTOP_OPTIONHELPER_SKILL) if _DESKTOP_OPTIONHELPER_SKILL.is_dir() else "",
)

# 必须由使用者明确选择解释器；选择后可记录在被忽略的项目级状态文件，
# 以后复用同一绝对路径，不再重新猜环境。
_OPTIONHELPER_INTERPRETER_FILE = OPTIONHELPER_DIR / "interpreter.txt"
try:
    _SELECTED_OPTIONHELPER_PYTHON = _OPTIONHELPER_INTERPRETER_FILE.read_text(encoding="utf-8").strip()
except (OSError, UnicodeError):
    _SELECTED_OPTIONHELPER_PYTHON = ""
OPTIONHELPER_PYTHON = _cred("OPTIONHELPER_PYTHON", _SELECTED_OPTIONHELPER_PYTHON)

# 对话 Agent 完成 Recommender Intent/Research/Critic 后写出的**一次性**公开选择交接件。
# Quote 桥接会把它原子移动到以 run_id 命名的归档；绝不从旧运行回读。
OPTIONHELPER_SELECTION_PATH = _cred(
    "OPTIONHELPER_SELECTION_PATH", str(OPTIONHELPER_DIR / "selection.pending.json"),
)
OPTIONHELPER_HOST_URL = _cred("OPTIONHELPER_HOST_URL")

# Research Helper 的客户条件默认档案。桥接层会每次显式传给 OptionHelper，
# 因而这里是项目唯一的可修改位置；客户本次输入（selection.json 的
# constraints）优先级更高。不要把实际价格、行权价或任何市场数据放在这里。
_OPTIONHELPER_DEFAULT_CONSTRAINTS = {
    "horizon": "3个月",
    "max_loss": "100%",
    "principal_fluctuation": True,
}
_LOCAL_OPTIONHELPER_DEFAULTS = _LOCAL.get("OPTIONHELPER_DEFAULT_CONSTRAINTS", {})
OPTIONHELPER_DEFAULT_CONSTRAINTS = {
    **_OPTIONHELPER_DEFAULT_CONSTRAINTS,
    **(_LOCAL_OPTIONHELPER_DEFAULTS if isinstance(_LOCAL_OPTIONHELPER_DEFAULTS, dict) else {}),
}


def has_optionhelper() -> bool:
    """是否已具备启动新版 Skill 统一就绪检查的本地条件。"""
    try:
        return bool(
            OPTIONHELPER_SKILL_ROOT
            and OPTIONHELPER_PYTHON
            and Path(OPTIONHELPER_PYTHON).is_file()
            and (Path(OPTIONHELPER_SKILL_ROOT) / "scripts" / "environment_check.py").is_file()
            and (Path(OPTIONHELPER_SKILL_ROOT) / "scripts" / "tool_entry.py").is_file()
        )
    except OSError:
        # 权限不足或盘符暂时不可用应表现为“能力未就绪”，不能令整个 GUI 崩溃。
        return False
