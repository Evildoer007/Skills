"""writer：论述生成（第二个 LLM 环节）。

输入：pipeline 产出的"带数据论证计划"（每条逻辑 + 真实数据 + 缺口）。
输出：每条逻辑的 { 论述文字, 图表规格(画什么，非画图本身), 加粗结论 } + 核心结论。

防幻觉铁律（贯穿设计）：
  - 只能用喂进来的真实数字，绝不编造；
  - "缺失数据"字段不得臆造数值，可定性带过或标"（数据待补）"；
  - writer 只产内容与图表规格，真正画图/排版是 renderer 的事。

核心结论最后综合各逻辑生成（DESIGN §4：印在最上但最后写）。
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field as dfield

from llm.client import DeepSeekClient

from .pipeline import MarketAnalysis

# 从研报原文里挑出可引用的数字（带单位，避免把年份、序号也算进去）
_NUMS = re.compile(r"-?\d+(?:\.\d+)?\s*(?:%|倍|万亿韩元|亿韩元|万亿元|亿元|万元|亿|元|pct|bp|个百分点)")
_INTERNAL_ID = re.compile(
    r"\[(?:[FMEC]\d+)(?:\s*[+＋、/,]\s*[FMEC]\d+)*\]|"
    r"\b[FMEC]\d+(?:\s*[+＋、/,]\s*[FMEC]\d+)+\b",
    re.I,
)
_CONFIDENCE_LABEL = re.compile(
    r"[，；,;]?\s*(?:(?:该|本)?(?:证据链|传导链|结论|判断)?(?:的)?)?"
    r"(?:可信度|置信度)\s*(?:为|是|：|:)?\s*(?:较高|较低|高|中等?|低)(?:水平)?",
    re.I,
)


def _public_text(value: object) -> str:
    """正式报告文字兜底脱敏；内部编号和证据等级只允许进入内部底稿。"""
    text = _INTERNAL_ID.sub("", str(value or ""))
    text = _CONFIDENCE_LABEL.sub("", text)
    # 查询日期属于页眉/图表元信息，不在摘要或每段分析中重复播报。
    text = re.sub(
        r"(?:数据查询日\s*[：:]\s*|截至(?:本次)?数据查询日\s*)(?:20\d{2}[-/]\d{1,2}[-/]\d{1,2})\s*[。，；,:：]?\s*",
        "", text,
    )
    text = re.sub(r"(?:事件事实|产业机制|A\s*股暴露)(?:层面|方面)\s*[：:，,]\s*", "", text)
    # 客户正文解释“什么变化、经什么渠道影响哪些资产”，不展示内部证据工程术语。
    text = re.sub(
        r"(?:\*\*)?(?:事件|事实)\s*[—\-→]+\s*(?:产业)?机制\s*[—\-→]+\s*A\s*股(?:对象)?暴露"
        r"(?:的)?(?:传导链)?(?:较为|已经|已)?(?:清晰|完整|成立|可验证)?(?:\*\*)?\s*[，,；;]?\s*",
        "", text, flags=re.I,
    )
    text = re.sub(r"(?:事件)?传导链(?:较为|已经|已)?(?:清晰|完整|成立|可验证)\s*[，,；;]?\s*", "", text)
    text = text.replace(
        "但需注意审厂行为尚未直接证明相关公司获得订单或收入",
        "后续重点观察供应商订单与收入兑现",
    )
    text = re.sub(
        r"单日行情不能外推为持续趋势\s*[，,]\s*需关注([^。；]+)",
        r"短期市场反应能否延续，取决于\1", text,
    )
    # 不机械删除整句风险信息，只把内部审核术语转成业务可观察条件。
    text = text.replace("证据跳跃", "后续仍需业务数据验证")
    text = text.replace("因果关系不可靠", "后续影响仍需观察")
    text = text.replace("证据链不完整", "后续仍需补充业务数据")
    text = text.replace("缺乏直接证据", "仍需后续业务数据验证")
    text = re.sub(r"（\s*[；，,;]*\s*）", "", text)
    text = re.sub(r"([（；，])\s*[；，]+", r"\1", text)
    text = re.sub(r"^[，,；;]\s*", "", text)
    return text.strip(" ；，,;")


def _field_payload(field, ma: MarketAnalysis) -> dict:
    return {
        "字段": field.field,
        "值": field.display or str(field.value),
        "数据日期或区间": field.as_of or getattr(ma, "数据查询日", ""),
    }


@dataclass
class LogicContent:
    逻辑id: str
    论述: str
    结论: str
    # writer 自拟的一句话标题（#82）。此前版面直接印 planner 给的 `标题`，
    # 而那基本就是论点库的**类型名**（"估值历史低分位"），三条排下来像三个术语，
    # 读者读完标题仍不知道这篇在讲什么。改由 writer 出——它手上有真实数据、
    # 也刚写完论述，最清楚这条到底论证了什么。为空时版面回退到 planner 的标题。
    标题: str = ""
    # 一条逻辑可配 1~3 张图，而非固定一张。此前每条逻辑写死一张图，
    # 遇到"背离类"论点（价格 vs 资金）等本就需要两个不同角度才能说清的场景，
    # 只能挤进一张图或舍弃一个角度；现在允许多张图各自支撑论述的不同部分。
    图表规格列表: list[dict] = dfield(default_factory=list)


@dataclass
class ReportContent:
    主题: str
    类型: str
    核心结论: str = ""
    推荐方向: str = ""
    logics: list[LogicContent] = dfield(default_factory=list)
    空缺逻辑: list[str] = dfield(default_factory=list)   # 论述为空/漏写的逻辑，须重试或人工补
    tokens: int = 0
    ok: bool = False
    error: str = ""
    内部审核备注: list[str] = dfield(default_factory=list)


_SYSTEM = """你是场外衍生品投资策略研报的"撰稿器"。根据论证计划与【真实数据】，为每条逻辑撰写论述与图表规格。
铁律：
1. 只能使用"可用数据"里给出的真实数字；绝对不得编造、估算或引用任何未给出的数字。
   `数据查询日`由页面统一展示，不要写入核心结论或作为分析段落前缀。字段另有报告期或日期区间时，
   按业务需要在数字旁说明（例如“2026年中报”“近20日”），查询日不能替代财报期或统计区间。
2. "缺失数据"的字段表示数据待补——不要为其臆造数值，**也不得把缺失字段当作论据去支撑任何结论**
   （例如资金流数据缺失时，不可写"资金逆势流入验证修复动能"）；应写明"（数据待补）"并保持中性。
2.1 **证伪义务（重要）**：给定的"具体论点"只是**待检验的假设**，不是既定结论。
   若真实数据与论点相悖——例如论点称"估值处历史低分位"而 PB 高达 22 倍，
   或论点称"分红改善"而现金分红为 0——必须**如实指出该逻辑当前不成立或需存疑**，
   禁止圆场、淡化或强行自洽。宁可写"数据不支持这一判断"，也不要写出与数据矛盾的论断。
   此时"结论"一句应写成中性或否定，而非照搬论点。
3. 论述专业、贴合场外衍生品策略研报口吻。**所有数据值已格式化为最终可读形式，
   请原样引用，不得再做任何换算、改写或改变量级。**
3.0 **不得把精确值改写成约数或区间。** 真值是"折价 22.5%"就写 22.5%，
   不许写成"超过20%""约两成""逾20%"。这类改写看似无害，实则有两处代价：
   ①校验器按真值逐个回指，改写后的数字对不上，会被标为可疑待复核；
   ②研报的说服力正来自精确——"22.5%"是测算结果，"超过20%"是印象。
3.0.1 **也不得自己算差值、比值、涨跌幅**——只能引用已给出的数字。
   两个值都给了也不行：29.87 与 23.21 不许写成"相差逾6倍"。
   这既是编造（6 不在任何字段里），又是**表述错误**——
   在投研语境里"相差6倍"指 6 倍数关系，而实际只差 6.66 个单位，意思完全不同。
   要表达差距就并列两个真值（"当前 29.87 倍 vs FY1 预测 23.21 倍"），
   或引用已给出的折价字段；**没给折价值就不要自己算**。
3.0 **每条逻辑要自拟一个「标题」——一句话说清这条论证，不是论点库的名字。**
   论点库给的是**论点类型名**（"估值历史低分位""困境反转""卖压释放"），
   那是分类标签，不是标题。直接印上去，三条逻辑看起来就像三个术语，
   读者读完标题仍不知道这篇在讲什么。
   要写成**有主语、有动作、有落点的一句话**，15~24 字，可含方向与时间：
     ✅ 「Q2深度回调砸出估值洼地，7月政策催化强势反转」
     ✅ 「盈利增速由负转正，困境反转获数据确认」
     ✅ 「大股东减持近尾声，筹码压力显著缓解」
     ❌ 「估值历史低分位」（这是论点名，不是标题）
     ❌ 「关于消费板块估值的分析」（等于没说）
3.0.0 **标题里数字最多出现一个，且必须搭配一个"动作/判断"。**
   实测放开后模型会退化成用数字填满字数——「板块估值处8.3%分位，股息率4.75%」
   两个数字并列，没有主语动作、没有落点，读者看完不知道你要说什么，
   还不如原来的论点名。数字是**证据**不是**观点**，标题的位置该留给观点。
     ✅ 「估值杀到8.3%分位，安全边际已现」　（一个数字 + 一个判断）
     ✅ 「盈利增速由负转正，困境反转获数据确认」　（零数字，全靠判断）
     ❌ 「板块估值处8.3%分位，股息率4.75%」　（两个数字并列，无判断）
   带数字时同样必须出自可用数据，不得编造。
3.0.1 **论述里把关键结论用 `**双星号**` 括起来加粗**，每条 1~2 处，不要多。
   加粗的应是**判断**（"**盈利改善并非单一项目拉动**"）或**关键数据关系**
   （"**FY1 较当前折价 44.5%**"），不是随便挑个词。
   加粗超过两处等于没有重点，反而更难读。
3.1 **每条论述 160~260 字，要有完整论证链条**，不要只摆一两个数字就收尾。
   （上限比早先放宽，是因为版面字号已同步下调；但**放宽的是论证深度、不是废话**——
   多出来的篇幅要用在"反证/归因/推论"这几步上，不是把同一个结论换句话再说一遍。）参考结构：
   现象（发生了什么）→ 反证或佐证（其它数据是否支持）→ 归因（为什么会这样）
   → 推论（对后市/配置意味着什么）。
   范例口吻："板块被减持力度排名靠前、股价跌幅较大——但基本面并未同步恶化。
   中报预告高增、PB 仅 1.37 倍（约 27% 分位），盈利改善尚未充分定价。
   减持导致的被动卖盘是股价下行的主因，而非基本面恶化；减持趋近尾声后，
   股价存在向基本面均值回归的动力。"
3.1.1 **首次提到板块时必须写全称，之后才可简称"板块"。**
   实测成品通篇写"近期板块年化波动率攀升至76.0%""板块归母净利同比13.75%"，
   **从头到尾没说这是哪个板块**——读者不知道在分析什么。
   第一句应写成"电子元件板块近期年化波动率攀升至76.0%"。
   内部数据锚点只是取数辅助，**不要在客户正文写“以某个股为代表”**；除非该公司本身
   是一条已选、且有直接证据支撑的公司案例。
3.1.2 **提到主题之外的公司、产品或机构时，须用一个从句交代它与本主题的关系。**
   实测有一条逻辑标题是"长鑫市占率破7%"，正文直接展开长鑫，
   而读者并不知道长鑫是谁、与引发本次需求的 SK 海力士是什么关系。
   应写成"国产存储厂商长鑫（SK海力士在通用 DRAM 的直接竞争者）市占率突破 7%…"。
   一句话说清"它是什么、与本主题什么关系"即可，不要展开介绍。
3.1.2a **研报证据边界是硬约束。** 若某条逻辑标为“公司级”，只能明确写成
   “某公司案例显示……”，不得替换主语为“行业/板块”，不得由该案例推出行业盈利、
   景气或整体方向；行业结论必须另有行业级、市场级或本次 ETF 真实成分数据支撑。
3.1.3 **有"分析ETF"时，它列出的那几个字段（波动率/涨跌幅分位/换手率/成交额分位）
   必须写成这只 ETF 自己的表现，不能笼统归给"板块"。**
   应写"消费ETF近3年年化波动率处82%分位"，不写"板块波动率处82%分位"——
   前者是这只可交易标的自己的真实价格数据，后者听起来像是板块整体聚合出来的，
   两者不是一回事，写错会让读者误以为所有数字都来自同一套聚合口径。
   反过来，PB/ROE/净利同比/分红这类**无论如何都是成分股整体法聚合**，
   写"板块PB处9%分位"没问题——它们本来就不是 ETF 自己的数据，
   聚合出来的作用是给"为什么该配置这只ETF"提供基本面理由，不是替 ETF 报数。
3.2 **"板块全景数据"里的字段可以引用**，用来把论证写厚（如讲估值时带上 PB 与分位、
   讲盈利时带上 ROE 与分红率）。但**不得偏离本条论点**去讲别的主题——
   全景数据是用来支撑本条论证的，不是让你把所有数字堆一遍。
3.3 有"成分股明细"时，**善用个股举例说明板块内部分化**
   （如"中信 +54.6%、中信建投 +99.0%，而国泰海通 -47.8%，板块内部盈利分化明显"）。
   这比只给一个聚合数字更有说服力。
3.4 **有"子行业明细"时，说明本板块是宽口径合并的，且论述必须覆盖到各子行业，
   不得只讲其中市值最大的那一个。** 这类板块（消费/大消费等）由若干一级行业合并而成，
   前几大成分股按市值排下来往往集中在同一个子行业（如消费板块前几大清一色白酒），
   只顺着它们写，成品就成了"标题写消费、内容全是白酒"的以偏概全。
   至少要点出各子行业之间的差异（谁强谁弱、估值与盈利是否背离）。
   口径本身（合并了哪几个子行业）不必写进正文——这是内部溯源信息，
   一页通面向客户，只呈现结论；口径已经完整记录在内部底稿里，不必重复。
3.5 **有"触发实体自身数据"时，三条逻辑里最多找一条跟事件本体真正相关的来提，
   不要每条逻辑都重复同一句开场白。** 这是需求由一家具体公司引发时才有的数据
   （如需求由 SK海力士业绩引发，这里就是 SK海力士自己的股价/估值），
   跟"板块全景数据"是两个不同的对象，绝不能混着引用或互相替代——
   "SK海力士自身PE 12倍"和"A股半导体板块PE 45倍"是两件事，写混了就是张冠李戴。
   事件本体一定会被交代到（核心结论会写，见 5.0.0），正文不必每条都重复；
   只有某条逻辑的论证本身用得上事件本体数据时才提它一次，
   且要写出真实的因果/传导关系，不能只是把同一句数据复述后接一句不相干的板块论述。
   例如某条逻辑本身在讲"板块盈利改善支撑估值"，跟事件本体的自身股价表现没有实质
   关联，就不要硬套一句"SK海力士区间涨跌幅-12.62%……"作为开场白——
   这种为了提而提、跟后面论证接不上的写法比不提更差。
   这个字段没给（多数板块类需求没有触发实体）时，不必强行编一个事件角度。
3.5.1 **有“已核验事件证据链”时，事件本体与本次 A 股行业/ETF 的因果连接只能按
该证据链写。** 不得把“同属科技/半导体”等概念相近自行扩写为供应链、竞争或受益关系；
内部推理须区分“事件事实”“产业机制”“A股对象暴露依据”“受控组合结论”与“A股市场响应”，但不要将这些
分类标签作为客户正文的固定开头。自然说明变量变化、影响渠道、获益/承压环节、市场定价与投资判断。
组合结论不是新的事实来源，只能按所附原文和适用边界表述；直接传导证据仍可作为兼容路径。
3.5.2 **客户报告不得出现 F1、M1、E1、C1 等内部证据编号，也不得评价“可信度/置信度
高、中、低”。** 这些属于内部审核信息，只保留在内部底稿。正文只陈述经确认的事实、
来源、传导关系、适用边界及仍待验证之处。
3.5.3 **客户报告是投资分析，不是证据审计报告。** 已通过审核的主传导链应落到产业变化、预期兑现、估值与
市场方向。不要反复说“存在证据跳跃”“因果关系不可靠”“未直接对应平台”等审核措辞；这些写入`内部审核备注`。
真正影响投资判断的限制应转成业务可观察条件（订单、出货、渗透率、盈利兑现等），不能掩盖重大不确定性，也不能
把没有证据支持的方向写成确定受益。缺乏具体公司产品进展时，只讨论已支持的产业环节，不自行填补关系。
3.5.4 **事件型客户正文必须用业务语言把传导关系讲明白。** 推荐顺序是：事件改变的关键变量 → 需求、价格、
产能或技术渠道 → 受影响的产业环节 → 本次行业/篮子/ETF为何承接该影响 → 投资含义。正文不得出现
“事件—机制—A股暴露”“传导链清晰/完整”“已通过证据审核”等内部流程用语。不要用“尚未直接证明获得订单或
收入”作为段落落点；若订单尚待兑现，写成“后续重点观察订单、出货或收入兑现”，且全篇最多用一句简短的观察条件。
正文篇幅应主要用于解释机会和影响渠道，不能把每段写成对传导关系的否定或免责声明。
4. 图表规格只描述"画什么"（图型、要展示的数据点、标题），不要自己画图或输出图片。
4.0 **`图表规格列表` 给 1~2 项。判断标准是"这条论述用到了几组不同性质的数据"，
   而不是"至少给一张就够了"。** 论述里每摆出一组读者需要看见的数据，就该配一张图。
   典型的一条逻辑往往正好 2 组：**板块层面的总量/分位**（gauge、number_cards）
   与**板块内部的个股分布**（bar、bar_line）——这是两件不同的事，各配一张。
   ⚠ 上限是 2 不是 3：一页通的硬约束是**一页**。实测每条 3 张时全篇 9 张图
   占 1125px，而整页可用高度约 1160px——光图就把版面吃满了，正文再短也放不下。
   两张恰好在版面上并排共一行，是最省纵向空间的形态；第三张必然独占一行，
   代价相当于 580 字正文。**宁可少一张图，也不要让成品变成两页。**
   ⚠ 最常被漏掉的是第二类：正文写了"贵州茅台净利同比+1.5%、五粮液+82.6%，
   而山西汾酒 -19.0%、泸州老窖 -19.3%，内部分化严重"，却不配图——
   这正是柱状图最该出场的地方（8 个标签一眼看出分化），只用文字等于浪费了数据。
   **凡正文里罗列了三个及以上同类可比的数（各成分股的净利同比/PB/涨跌幅等），
   就必须为它配一张 `bar`（或 `bar_line`，若同时有两列）。**
   **有"子行业明细"时，各子行业的横向对比图是必须的**——宽口径板块的读者
   首先要看到的就是这张图（哪个子行业强、哪个拖后腿），它比任何合并数字都重要。
   仍然禁止**为了凑数而重复**：同一批数据换个图型再画一遍、
   或把一张图拆成大同小异的两张，都是无效的图。区别在于**数据组是否不同**，
   不在于图型是否不同。
4.1 图型沿用"惯用图类型"，各自的数据点填法：
   - `number_cards`：2~4 个关键指标，每点 {标签, 值}
   - `bar`：同类可比的一组值（如各成分股净利同比），每点 {标签, 值}
   - `line`：**按时间先后**排列的序列（如近几期增速、利率走势），每点 {标签, 值}
   - `bar_line`：**背离类**专用，每点须给两列 {标签, 值, 值2}——
     `值`画柱（如各股区间涨跌幅）、`值2`画折线（如各股净利同比）。
     缺 `值2` 会退化成普通柱状图，等于浪费了这条论证最有力的呈现方式。
   - `gauge`：**分位类**专用（估值/波动率/拥挤度/持仓分位）。渲染成一条历史区间横条，
     标出当前位置与阈值线。每点 {标签, 值, 阈值, 实际值, 区间低, 区间高}：
     `值`填**分位数字本身（0~100，不带%）**，`阈值`填该论点的判定阈值（如 30），
     `实际值`填对应的原始值（如 "1.32倍"），`区间低/区间高`填历史区间两端。
     阈值与区间取不到就省略，只给 `值` 也能画。
     ⚠ `值`填错成原始值（如填 "1.32倍"）会导致整条画不出来——它是百分位不是价格。
   - `two_col`：**两组横向对比**专用（本板块 vs 同业、中外对标）。每点须带 `组` 字段
     标明属于哪一组，如 {组:"本板块", 标签:"证券", 值:"13.9倍"}、
     {组:"同业中位数", 标签:"保险", 值:"18.2倍"}。最多两组。
     可另给 `说明` 作为图下方的一句结论。
   - `contribution_bar`：同一主题篮子内的成分股**同一口径**涨跌幅/贡献，按数值排序；
     不是任意一组公司指标的通用替代品。每点 {标签, 值}，单位必须一致。
   - `histogram`：同一字段的足够长历史样本（至少 30 个观测值），用于展示分布与当前位置；
     不得把 2~4 个孤立指标伪装成“分布”。
   - `lollipop`：同单位、至少 3 个对象的横向排名，每点 `{标签, 值}`；仅当“排序/高低差异”
     是结论本身时使用，不能把它当作柱状图的装饰替换。
   - `dumbbell`：同一对象在**两个明确可比时点或情景**的变化，每点 `{标签, 值, 值2}`，
     且必须写 `可比时点:true`、`值名`、`值2名`；不得用于 ROE 与净利率等异质指标。
   - `waterfall`：可加总的增减项拆解，每点 `{标签, 值}`，且必须写 `可加总:true`；
     不可加总的同比、分位和估值不得使用。
   - `interval_band`：同口径的低值、高值和当前位置，每点 `{标签, 低, 高, 值}`，且必须写
     `可比区间:true`；适用于历史区间、一致预期范围等。
   - `heatmap`：同一篮子内、按**同一规则标准化为 0–100**的多指标扫描；写 `标准化:true`，
     `数据点`给标签、`系列`给各指标数组。原始 PB、ROE、增速不能混用同一色阶。
   - `treemap`：同一口径的权重/市值等构成，面积只编码 `{标签, 值}`；可另给 `颜色值`表示
     经验证的涨跌方向，面积不能被解释为贡献。
   - `bubble`：同一样本的三变量关系，每点 `{标签, x, y, 大小}`；x/y 是两个连续变量，
     `大小`只能是非负规模，必须提供 `x轴`、`y轴`、`大小轴`。
   - `evidence_flow`：事件型研究中已核验的“事件事实 → 传导依据 → A股主题影响”链，
     每点 {标签, 说明}，只可写已给出的传导证据；`说明`尽量用一条不超过 40 字的短句，
     避免把整段证据和公司名单塞进图中，完整依据留在正文与底稿；它不是数值趋势图。
4.1.1 **图表标题使用简洁的“对象＋指标/关系”题目，不使用带数值的结论句。** 例如“主题篮子近20日涨跌幅”
   “DRAM市场占有率”“成分股PB与净利润增速”；平台名和“20日”这类对象/时间标签可以保留，但不要把涨幅、
   市占率数值或“明显提升、支撑估值”等结论写进图题。分析逻辑的标题仍可是一句判断，不与图题混淆。为每张图给
   `数据截至`、`单位`、`样本口径` 与 `图表结论`。`数据截至`必须使用输入中的明确日期；
   缺少日期的数据不得进入客户图表，不得写“见底稿”。图上只高亮一个重点，其余数据弱化；
   不得使用彩虹色或以颜色替代数值/标签。
   `图表结论`另外记录分析含义，仅用于内部复核，不覆盖客户图题。
4.2 数据点的值**只能来自给你的真实数据**（可用数据/板块全景/成分股明细/研报依据），
   一个都不许编。画不出来就不给图表规格，宁可无图也不要假数据。
5. 核心结论综合全部逻辑，一段话，**120~180 字、3~4句**。先回答客户最关心的方向和主要机会，再说明
   最重要的驱动、市场是否已定价及关键风险。最多引用两项带单位的关键数据，不要求一定放数字；不要罗列
   PB、ROE、净利增速、资金流、波动率等一串指标，明细留给正文与图表。不得出现查询日期前缀或证据审计评价。
5.0.0 事件型核心结论先概括“事件改变了什么、主要影响哪个环节、机会与兑现条件”，不强制以事件主体的股价
   或波动率开头。只展开已经审核支持的主方向，备选方向至多一句点到，不把一页通写成多行业清单。
5.0 每条逻辑的 `结论` **不印进成品**，它是交给下游产品选择环节（OptionHelper）的输入。
   因此不要复述正文已说过的话（正文写了"高毛利红利期或走向终结"，
   结论再写一遍"红利期或退却"等于同一句说两遍），
   而要把这条逻辑**归结成市场状态的判断**，沿这四个维度讲：
   **方向倾向、时间尺度、波动率状态、风险边界（什么情况下这条判断失效）**。
5.0.1 ⚠ **严禁给出任何具体产品或结构建议。** 挂什么结构、什么期限、买方还是卖方，
   是 OptionHelper 依据实时市场参数决定的事，不是本环节该越权判断的。
   在这里写产品建议有两重危害：一是**越过定价直接给方案**，而我们手上既没有波动率曲面
   也没有报价，说"卖权收益厚"是没有依据的断言；二是下游会把它当输入，
   等于让一个不掌握定价信息的环节替定价环节做了决定。
   **禁止出现**：看涨价差、熊市价差、跨式、宽跨式、鲨鱼鳍、雪球、自动赎回、累购、
   敲入敲出、卖权/买权、买入看涨/看跌、短久期结构 等一切产品与结构名称，
   以及"建议构建…""可考虑参与…""宜采用…"这类操作建议句式。
   × 错："超跌后倾向短久期看涨结构；波动率处极高分位，卖权收益厚但需防继续下行"
   ✔ 对："本轮下跌由情绪驱动而非基本面恶化，20日涨跌幅处近3年3%分位；
        波动率处92%分位、显著高于三年均值；若后续盈利数据继续走弱，
        则超跌属于对基本面的正确定价，这条判断不成立"
5.1 **"各逻辑"里有几条，"逻辑正文"就必须输出几条，一条都不能少、不能留空。**
   逻辑漏写会让成品少掉整块内容。若某条实在缺数据支撑，也要写出来并如实说明
   数据不足，而不是跳过不写。
6. 某条逻辑带"研报依据"时：
   6.1 **必须引用其中"可引用的数字"里的具体数值**，不得只写"估值吸引""需求强劲"
       这类定性描述——那等于浪费了研报里的真数据。
   6.2 数字只能从"可引用的数字"里取，**不得从原文之外引入任何数字**。
   6.3 **不要在正文里写"据某某研报指出""某券商认为"这类字样。** 出处已由成品末尾的
       「数据来源」栏统一列出，正文里再点一遍既啰嗦又像在替第三方背书。
       直接陈述事实与数字即可（"长鑫在通用 DRAM 的全球市占率已突破 7%"）。
   6.4 **必须同时引用该条"可用数据"里的自有数字去印证或补充**，不能只复述研报。
       研报给的是**产业机制**（为什么会这样），我方数据给的是**市场状态**（它正在发生），
       两者合起来才是完整论证。例：研报称"长鑫市占率突破 7%，DRAM 高毛利红利将退却"，
       就该接上我方取到的该板块毛利率或盈利增速实际走势，看是否已现端倪。
       若自有数据与研报判断相悖，按铁律 2.1 如实指出分歧，不得掩饰。
只输出一个 JSON 对象，不要多余文字。"""


def _chart_type(logic_id: str, doc_cats: dict | None = None) -> str:
    """该条论点配什么图 —— 由**论点所属类别**决定（DESIGN §7.3）。

    逻辑id 就是论点库 id（V1/S3/R1…）。论点库文档没有"惯用图类型"列，
    故按类别映射（`thesis._CATEGORY_CHART`）；自由槽 id（free_*）查不到，回落数字卡片。

    研报观点的 id 形如 `doc_21`，同样查不到——但它**有类别**，
    须用 `doc_cats` 换成类别再查，否则整条研报逻辑都会掉进数字卡（实测踩过）。
    """
    from . import thesis as th

    cat = (doc_cats or {}).get(logic_id)
    return th.chart_type_of(cat or logic_id)


def _build_user_prompt(ma: MarketAnalysis) -> str:
    from .planner import DOC_FIELD_PREFIX, EVENT_FIELD_PREFIX

    packages = []
    for lw in ma.logics:
        lg = lw.logic
        pkg = {
            "逻辑id": lg.逻辑id,
            "标题": lg.标题,
            "具体论点": lg.具体论点,
            "方向倾向": lg.结构方向倾向,
            "惯用图类型": _chart_type(lg.逻辑id, getattr(ma, "doc_cats", None)),
            "可用数据": [
                _field_payload(f, ma)
                for f in lw.auto
                if not f.field.startswith(DOC_FIELD_PREFIX)
                and not f.field.startswith(EVENT_FIELD_PREFIX)
            ],
            "缺失数据": [f.field for f in lw.gaps],
        }
        # 研报依据单独成块。混在"可用数据"里时实测会被当成背景读读就过——
        # 那里的值都是"1.37倍"这种可直接照抄的短串，而研报原文是一整段话，
        # LLM 无从"原样引用"，结果把 2.6倍/7.0倍 这些真数字全退化成"估值吸引"。
        # 单独列出并显式给出可引用的数字，才用得上。
        cites = [f for f in lw.auto if f.field.startswith(DOC_FIELD_PREFIX)]
        if cites:
            pkg["研报依据_须引用其中数字"] = [
                {"出处": f"{f.source} {f.note}".strip(),
                 "原文": f.display,
                 "资料日期": f.as_of or getattr(ma, "数据查询日", ""),
                 "可引用的数字": _NUMS.findall(f.display or "")}
                for f in cites
            ]
            claim = next((c for c in getattr(ma, "doc_claims", []) if c.id == lg.逻辑id), None)
            if claim is not None:
                pkg["研报证据边界"] = {
                    "范围": getattr(claim, "证据范围", "公司级"),
                    "主体": getattr(claim, "证据主体", "") or "原文所述主体",
                    "规则": ("只能作为该公司案例，必须点名主体；不得外推为行业/板块结论，"
                             "不得用其决定整篇推荐方向。"
                             if getattr(claim, "证据范围", "") == "公司级" else
                             "仅可在该证据范围内表述，不得扩大外推。"),
                }
        event_cites = [f for f in lw.auto if f.field.startswith(EVENT_FIELD_PREFIX)]
        if event_cites:
            pkg["已确认事件传导主轴_只能依据所列原文和边界"] = [
                {"出处": f.source, "证据链": f.display, "规则": f.note}
                for f in event_cites
            ]
        packages.append(pkg)
    # 板块全景：摸底取到但没进任何一条逻辑"所需字段"的那些数据。
    # 此前 writer 每条逻辑只看得到自己的 2~3 个触发字段，而摸底实际取了 17 个——
    # PB/分位/ROE/股息率/分红率/波动率全躺在 fv_map 里没传过去，
    # 论述因此只能"两个数字一句话"，撑不起模板那种厚度。
    # 这些值本就在 field_values 里，validator 照常认，不新增溯源风险。
    detail = None
    subs = None
    trigger_data: dict[str, str] = {}
    transmission_data: dict[str, str] = {}
    mechanism_data: dict[str, str] = {}
    exposure_data: dict[str, str] = {}
    chain_data: dict[str, str] = {}
    panorama: dict[str, dict] = {}
    for name, fv in (ma.field_values or {}).items():
        if not isinstance(name, str) or name.startswith("__"):
            continue
        if (name.startswith(DOC_FIELD_PREFIX) or name.startswith(EVENT_FIELD_PREFIX)
                or not getattr(fv, "ok", False)):
            continue
        if name == "成分股明细":
            detail = fv.display
            continue
        if name == "子行业明细":
            subs = fv.display
            continue
        # 触发实体（#74）自己的数据单独拦下来，绝不能混进"板块全景数据"——
        # 那个池子是明确按"这是板块整体的数"来引用的，混进去等于把
        # SK海力士自己的PE说成半导体板块的PE，方向性质完全不同。
        if name.startswith("触发标的_"):
            trigger_data[name.removeprefix("触发标的_")] = fv.display or str(fv.value)
            continue
        if name.startswith("事件传导证据"):
            transmission_data[name.removeprefix("事件传导证据")] = fv.display or str(fv.value)
            continue
        if name.startswith("事件产业机制"):
            mechanism_data[name.removeprefix("事件产业机制")] = fv.display or str(fv.value)
            continue
        if name.startswith("A股暴露依据"):
            exposure_data[name.removeprefix("A股暴露依据")] = fv.display or str(fv.value)
            continue
        if name.startswith("事件组合传导链"):
            chain_data[name.removeprefix("事件组合传导链")] = fv.display or str(fv.value)
            continue
        panorama[name] = {
            "值": fv.display or str(fv.value),
            "数据日期或区间": fv.as_of or getattr(ma, "数据查询日", ""),
        }

    # 分析对象必须显式告诉 writer。此前 spec 里只有"主题"，没有板块名，
    # 于是正文通篇写"板块如何如何"却从不说是哪个板块——不是模型偷懒，是它根本不知道。
    sector = (ma.field_values or {}).get("__sector__") or ""
    etf_code = (ma.field_values or {}).get("__etf__") or ""
    from . import instruments as _inst
    etf_name = _inst.get(etf_code).简称 if etf_code and _inst.get(etf_code) else ""
    trigger_name = (ma.field_values or {}).get("__trigger_name__") or ""
    trigger_code = (ma.field_values or {}).get("__trigger_code__") or ""
    spec = {
        "主题": ma.plan.主题,
        "本次数据查询日_由页眉图表页脚展示_不要写入正文": getattr(ma, "数据查询日", ""),
        "分析对象_首次提及须写全称": {
            "板块": sector or "（未指定板块，按主题表述）",
        },
        # #74：需求由一家具体公司引发时（可能是境外标的），它自己的市场表现
        # 单独给一块，跟"板块全景数据"严格分开——铁律 3.5 要求写正文时必须
        # 把"事件本体自己怎么样"和"A股响应板块怎么反应"两条线连起来写，
        # 而不是只字不提事件本身、直接跳到"板块该怎么样"（用户实测发现的问题）。
        **({"触发实体自身数据_与板块全景数据严格区分": {
            "名称": trigger_name, "代码": trigger_code, "数据": trigger_data}}
           if trigger_code else {}),
        **({"已核验事件传导证据_只可按此写因果": transmission_data}
           if transmission_data else {}),
        **({"已核验产业机制原文": mechanism_data} if mechanism_data else {}),
        **({"已核验A股对象暴露原文": exposure_data} if exposure_data else {}),
        **({"分析师确认的组合传导链_只可引用所附原文和边界": chain_data}
           if chain_data else {}),
        # #73：波动率/涨跌幅分位/换手率/成交额分位这四个字段，只要这里给了 etf_code，
        # 就是这只 ETF 自己的真实价格数据，不是板块聚合出来的——写正文时必须归属给它
        # （"消费ETF近3年波动率处82%分位"），不能笼统写成"板块波动率"，见铁律 3.1.3。
        **({"分析ETF_下列字段是它自己的真实数据_须归属给它":
            {"代码": etf_code, "简称": etf_name,
             "字段": ["年化波动率", "波动率历史分位", "区间涨跌幅分位",
                     "换手率历史分位", "换手率近期高分位", "成交额历史分位"]}}
           if etf_code else {}),
        "类型": ma.plan.类型,
        "叙事主轴": ma.plan.叙事主轴,
        "整体方向": ma.plan.整体方向,
        "板块全景数据_可引用以充实论证_勿偏题": panorama,
        # 键名里点明"既可举例也可作图"：此前只写"可用于举例说明分化"，
        # 实测 writer 老老实实只拿它写正文举例，从不据此出图（#66）。
        **({"成分股明细_可举例说明分化_也可直接作bar图": detail} if detail else {}),
        # 宽口径板块才有。给它单独一个键并在铁律 3.4 里点名，
        # 否则合并口径的报告会通篇只讲市值最大的那个子行业（见 #67）。
        **({"子行业明细_本板块由这几个一级行业合并而成_须体现覆盖面": subs} if subs else {}),
        "各逻辑": packages,
        "输出格式": {
            "核心结论": "120~180字，先说投资判断，最多两项关键数据，无查询日期前缀",
            "内部审核备注": ["证据对应、适用边界或来源缺口等审核说明；不进入客户正文"],
            "推荐方向": "看涨|震荡|看跌|中性",
            "逻辑正文": [
                {
                    "逻辑id": "对应输入的逻辑id",
                    "标题": "一句话概括本条逻辑的论证，15~24字，见铁律3.0",
                    "论述": "分析文字，只用可用数据的数字，重点用**加粗**标出",
                    "图表规格列表": [
                        {
                            "类型": "沿用惯用图类型，或按下方数据形态另选",
                            "标题": "简洁的对象＋指标题目，例如主题篮子近20日涨跌幅，不含数据值和判断句",
                            "图表结论": "另行记录该图的分析含义，仅供内部复核，不覆盖标题",
                            "数据截至": "输入给出的明确日期或区间；不得写‘见底稿’",
                            "单位": "%、倍、亿元或双轴单位；没有明确单位则不生成该图",
                            "样本口径": "如‘主题研究篮子（8只）’；必须明确填写",
                            "数据点": [{"标签": "字段名或说明", "值": "真实值"}],
                            "说明": "可选",
                        }
                    ],
                    "结论": "一句话：这条逻辑对衍生品结构意味着什么（不进正文，供下游定结构）",
                }
            ],
        },
    }
    return json.dumps(spec, ensure_ascii=False, indent=2)


# 输出额度。#44 把每条论述的要求从"简洁"提到"120~200字+论证链条"后，
# 三条逻辑加核心结论、图表规格的输出量翻了几倍，默认额度可能不够——
# 而额度不足的表现恰恰是"漏写几条逻辑"，与模型偷懒难以区分，故显式给足。
#
# ⚠ 部分质量档是推理模型，思考过程也可能计入 max_tokens。
# 实测 `reasoning_tokens` 单次可占 2500~7000——#80 把正文放宽到 160~260 字、
# 核心结论定为 180~280 字之后，10000 的额度被推理吃掉大半，剩下的写不完 JSON，
# 稳定截断在 char 3300 附近（连撞 3 次，位置几乎不变，故一眼可知不是偶发）。
# 定额度时**必须按"推理 + 正文"两份一起算**，不能只估正文长度。
_MAX_TOKENS = 24000


def _parse(d: dict, ma: MarketAnalysis, rc: ReportContent) -> list[str]:
    """把 LLM 输出灌进 rc，返回本次的空缺逻辑 id。"""
    rc.核心结论 = _public_text(d.get("核心结论", "")) or rc.核心结论
    notes = d.get("内部审核备注") or []
    if isinstance(notes, str):
        notes = [notes]
    if isinstance(notes, list):
        for note in notes:
            text = str(note or "").strip()
            if text and text not in rc.内部审核备注:
                rc.内部审核备注.append(text)
    rc.推荐方向 = str(d.get("推荐方向", "")).strip() or rc.推荐方向
    got = {lc.逻辑id for lc in rc.logics if lc.论述}
    for it in d.get("逻辑正文", []):
        if not isinstance(it, dict):
            continue
        lid = str(it.get("逻辑id", "")).strip()
        body = _public_text(it.get("论述", ""))
        if lid in got:                       # 重试补回来的，不重复添加
            continue
        specs = it.get("图表规格列表")
        if not isinstance(specs, list):        # 兼容模型偶尔仍给单个对象
            single = it.get("图表规格")
            specs = [single] if isinstance(single, dict) and single else []
        specs = [s for s in specs if isinstance(s, dict) and s][:3]   # 硬上限 3 张
        rc.logics.append(LogicContent(
            逻辑id=lid, 论述=body,
            图表规格列表=specs,
            结论=_public_text(it.get("结论", "")),
            标题=_public_text(it.get("标题", "")),
        ))
        if body:
            got.add(lid)

    empty = [lc.逻辑id for lc in rc.logics if not lc.论述]
    missing = {lg.逻辑id for lg in ma.plan.logics} - {lc.逻辑id for lc in rc.logics}
    # 核心结论也算缺口。它不在"逻辑正文"里，此前完全不受漏写检查覆盖——
    # 模型一旦没给（截断或直接省略），成品顶部就是个空的结论框，而 rc.ok 仍为 True，
    # 一路无声地渲染出去（#68 实测撞到：一份 3 条逻辑齐全的报告核心结论整段为空）。
    # 摘要数字过密与漏写一样触发一次重写；不机械删除数字，以免损坏原句含义。
    head = [] if rc.核心结论 and len(_NUMS.findall(rc.核心结论)) <= 2 else ["核心结论"]
    return head + empty + sorted(missing)


def _chart_data_as_of(ma: MarketAnalysis) -> str:
    """从已验证字段中取可追溯的最新截止日，并以本次查询日兜底。"""
    dates: list[str] = []
    for value in (ma.field_values or {}).values():
        as_of = str(getattr(value, "as_of", "") or "").strip()
        match = re.search(r"\d{4}[-/]\d{1,2}[-/]\d{1,2}", as_of)
        if match:
            dates.append(match.group(0).replace("/", "-"))
    query_date = str(getattr(ma, "数据查询日", "") or "").strip()
    if query_date:
        dates.append(query_date)
    return sorted(dates)[-1] if dates else ""


def _chart_sample_scope(ma: MarketAnalysis) -> str:
    """图表不能暗示比实际更广的样本；优先使用明确的研究篮子口径。"""
    if ma.研究篮子口径:
        return ma.研究篮子口径
    basket = [str(x) for x in (ma.研究篮子 or []) if str(x)]
    if basket:
        return f"主题研究篮子（{len(basket)}只）"
    sector = (ma.field_values or {}).get("__sector__") or ""
    return f"{sector}整体口径" if sector else "见底稿"


def _chart_unit(spec: dict) -> str:
    """优先保留规格已声明的单位；否则只从真实的展示值推断，不做单位换算。"""
    if spec.get("单位"):
        return str(spec["单位"])
    if spec.get("类型") == "scatter":
        return f"{spec.get('x轴') or 'x轴'} × {spec.get('y轴') or 'y轴'}"
    if spec.get("类型") == "bar_line":
        return f"{spec.get('柱标签') or '左轴'} × {spec.get('线标签') or '右轴'}"
    if spec.get("x轴"):
        return str(spec["x轴"])
    units = set()
    for point in spec.get("数据点") or []:
        match = re.search(r"(万亿元|亿元|万元|万亿|亿|元|倍|%|个百分点|pct|bp)\s*$",
                          str((point or {}).get("值", "")).strip())
        if match:
            units.add(match.group(1))
    return next(iter(units)) if len(units) == 1 else "见坐标轴/数据卡"


def _chart_heading(spec: dict) -> str:
    """图题与分析结论分开；旧版数值句式仅降级为与图中真实轴名对应的题目。"""
    title = _public_text(spec.get("标题", ""))
    if str(spec.get("类型") or "") == "evidence_flow":
        title = re.sub(r"事件传导链$", "影响路径", title)
    judgement = re.search(r"支撑|受益|承压|有望|显著|明显|推动|带动|处于|存在分化|升至|降至|高于|低于", title)
    if title and not _NUMS.search(title) and len(title) <= 28 and not re.search(r"[。；！]", title) and not judgement:
        return title
    kind = str(spec.get("类型") or "")
    x_axis = _public_text(spec.get("x轴") or "")
    y_axis = _public_text(spec.get("y轴") or spec.get("柱标签") or spec.get("值名") or "")
    if kind in {"scatter", "bubble"}:
        return f"{x_axis or '横轴指标'}与{y_axis or '纵轴指标'}分布"
    if kind == "evidence_flow":
        return "事件影响传导路径"
    if kind == "number_cards":
        labels = [str(p.get("标签") or "") for p in spec.get("数据点") or [] if isinstance(p, dict)]
        return "与".join(labels[:2]) if labels and len("与".join(labels[:2])) <= 24 else "核心研究指标"
    defaults = {"gauge": "历史分位", "line": "历史走势", "hist_band": "历史走势", "histogram": "历史分布",
                "treemap": "样本权重构成", "heatmap": "主题篮子指标分布",
                "waterfall": "增减项拆解", "interval_band": "历史区间",
                "dumbbell": "两期指标对比", "bar_line": "指标对比"}
    return f"{y_axis}{defaults.get(kind, '对比')}" if y_axis else defaults.get(kind, "样本指标对比")


def _normalise_chart_specs(ma: MarketAnalysis, rc: ReportContent) -> None:
    """为 LLM 与程序生成的图表统一补齐审计元信息。

    这一步只补口径，不改数据点、不制造结论。渲染层再做量纲、时间轴等硬校验；
    两层分工让“模型写了不合规图”不会静默进入成品。
    """
    as_of = _chart_data_as_of(ma)
    scope = _chart_sample_scope(ma)
    for logic in rc.logics:
        for spec in logic.图表规格列表 or []:
            if not isinstance(spec, dict):
                continue
            original_title = str(spec.get("标题") or "")
            spec["标题"] = _chart_heading(spec)
            if original_title and spec["标题"] != original_title:
                spec.setdefault("内部原始图题", original_title)
            declared_as_of = str(spec.get("数据截至") or "").strip()
            if not re.search(r"\d{4}[-/]\d{1,2}[-/]\d{1,2}", declared_as_of):
                spec["数据截至"] = as_of
            spec.setdefault("样本口径", scope)
            spec.setdefault("单位", _chart_unit(spec))


def _chart_data_fingerprint(spec: dict) -> str:
    """识别同一组底层数据，忽略图型、标题和结论等展示差异。"""
    data = spec.get("数据点") or []
    series = spec.get("系列") or []
    if not data and not series:
        return ""
    payload = {
        "数据点": data,
        "系列": series,
        "x轴": spec.get("x轴") or "",
        "y轴": spec.get("y轴") or "",
        "柱标签": spec.get("柱标签") or "",
        "线标签": spec.get("线标签") or "",
    }
    try:
        return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    except (TypeError, ValueError):
        return repr(payload)


def _deduplicate_chart_data(rc: ReportContent) -> None:
    """跨论点去掉重复数据图，避免换个图题或图型重复表达同一件事。"""
    seen: set[str] = set()
    removed = 0
    for logic in rc.logics:
        unique: list[dict] = []
        for spec in logic.图表规格列表 or []:
            if not isinstance(spec, dict):
                continue
            fingerprint = _chart_data_fingerprint(spec)
            if fingerprint and fingerprint in seen:
                removed += 1
                continue
            if fingerprint:
                seen.add(fingerprint)
            unique.append(spec)
        logic.图表规格列表 = unique
    if removed:
        rc.内部审核备注.append(f"已自动移除 {removed} 张跨论点重复数据图。")


def write(ma: MarketAnalysis, client: DeepSeekClient | None = None) -> ReportContent:
    rc = ReportContent(主题=ma.plan.主题, 类型=ma.plan.类型)
    client = client or DeepSeekClient()
    if not client.available():
        rc.error = "未配置 DeepSeek key"
        return rc

    user = _build_user_prompt(ma)
    res = client.chat_json(_SYSTEM, user, temperature=0.4, max_tokens=_MAX_TOKENS)
    rc.tokens = client.total_tokens
    if not res.ok or not isinstance(res.data, dict):
        rc.error = res.error or "LLM 返回非预期结构"
        return rc

    gaps = _parse(res.data, ma, rc)

    # 漏写自动补一次。实测这是最常见的产出缺陷（#41/#44 各遇到一次），
    # 而它的后果是成品直接少掉整块内容——与其在终端提示"建议重跑"让人工再来一遍，
    # 不如就地只补缺的那几条（不重写已写好的，省 token 也避免已有内容被改坏）。
    if gaps:
        缺结论 = "核心结论" in gaps
        缺逻辑 = [g for g in gaps if g != "核心结论"]
        要求 = []
        if 缺逻辑:
            要求.append(f"遗漏了这些逻辑：{'、'.join(缺逻辑)}，"
                        f"请输出这几条的『逻辑正文』条目（格式同前，同样 160~260 字、要有论证链条）")
        # 补写提示必须按实际缺什么来写。此前无条件写死"核心结论也不必重写"，
        # 于是首轮就没给核心结论时，补写这一轮反而被明确告知别写，缺口永远补不回来。
        if 缺结论:
            detail = "数据过密，请重写" if rc.核心结论 else "整段缺失，请补出"
            要求.append(f"『核心结论』{detail}（120~180字，先回答投资判断，最多两项关键数据，无日期前缀），"
                        "并同时给出『推荐方向』字段")
        retry = (f"{user}\n\n【补写要求】上一次输出" + "；".join(要求) +
                 "。其余已写好的不必重复。" +
                 ("" if 缺结论 else "核心结论也不必重写。"))
        res2 = client.chat_json(_SYSTEM, retry, temperature=0.4, max_tokens=_MAX_TOKENS)
        rc.tokens = client.total_tokens
        if res2.ok and isinstance(res2.data, dict):
            gaps = _parse(res2.data, ma, rc)

    # 研报自带的配图数列**覆盖** LLM 自拟的图表规格。
    # 那些数已在 docs 里逐个校验过字面出现在研报原文，比让模型从散文里凑数列可靠得多；
    # 而图比文字更难被读者核对——编造的柱子和真的看起来一模一样，故不给模型这个机会。
    # 研报通道目前每条观点最多挂一个已校验数列，故覆盖后是单元素列表；
    # LLM 自拟的图（若有）舍弃，不与已校验数列混排——避免一真一假拼在一条逻辑下。
    charts = getattr(ma, "doc_charts", None) or {}
    for lc in rc.logics:
        if lc.逻辑id in charts:
            lc.图表规格列表 = [charts[lc.逻辑id]]

    # 系统按字段自动配的历史序列图，**追加**在 LLM 自拟的图之后（#71）。
    # 追加而非覆盖：两张图回答的是不同问题——LLM 那张讲"当前横截面"
    # （各子行业/各成分股怎么分布），自动这张讲"纵向历史"（当前值在三年里的位置）。
    # 一横一纵合起来才说得清一条估值或拥挤度的论证，这也正是 #65 允许多图的本意。
    auto = getattr(ma, "auto_charts", None) or {}
    if auto:
        用过: set[str] = set()
        可挂 = [lc for lc in rc.logics if lc.逻辑id not in charts]   # 研报数列那条不掺别的图

        def _attach(lc, key) -> bool:
            spec = auto.get(key)
            # 一页通实际只展示前两张；第三张即使挂上也会被版面层舍弃，不能让
            # 自动结构图“看似生成、实际永远不可见”。
            if not spec or key in 用过 or len(lc.图表规格列表) >= 2:
                return False
            if spec.get("标题") in {(s or {}).get("标题") for s in lc.图表规格列表}:
                return False
            lc.图表规格列表.append(spec)
            用过.add(key)
            return True

        # ① 按字段挂：该逻辑用到了哪个字段，就配那个字段的历史序列图
        字段 = {lg.逻辑id: list(lg.所需数据字段 or []) for lg in ma.plan.logics}
        for lc in 可挂:
            for f in 字段.get(lc.逻辑id, []):
                _attach(lc, f)

        # ② 板块结构类的图（成分股散点、子行业分组柱）**不属于任何单条逻辑的字段**，
        #    按①永远挂不上。它们描述的是整个板块的横截面，对哪条逻辑都成立，
        #    故挂给当前配图最少的那条，每份报告各出现一次，不重复也不遗漏。
        for key in ("子行业明细", "成分股明细", "成分股气泡", "主题篮子热力", "成分股权重"):
            if key not in auto or key in 用过 or not 可挂:
                continue
            _attach(min(可挂, key=lambda x: len(x.图表规格列表)), key)

    # 图题、截止日、单位与样本口径必须同时进入 LLM 自拟图、研报已校验图和
    # 程序自动图；不能只要求某一条来源遵守图表规范。
    _normalise_chart_specs(ma, rc)
    _deduplicate_chart_data(rc)

    # 补写后仍缺的，如实标记，绝不代笔编造内容。
    if "核心结论" in gaps and rc.核心结论:
        rc.内部审核备注.append("核心结论重写后仍超过两项带单位数据，请压缩摘要并复核交付。")
    rc.空缺逻辑 = gaps
    rc.ok = True
    return rc


if __name__ == "__main__":  # python -m core.writer
    from . import genres as gr, pipeline

    ma = pipeline.run("券商板块投资机会", gr.TYPE_SECTOR, "600030.SH")
    rc = write(ma)
    print(f"主题: {rc.主题} | 推荐方向: {rc.推荐方向} | ok={rc.ok} {rc.error}\n")
    print("【核心结论】", rc.核心结论, "\n")
    for lc in rc.logics:
        print(f"— {lc.逻辑id} —")
        print(f"  论述: {lc.论述}")
        for cs in lc.图表规格列表:
            print(f"  图表: [{cs.get('类型')}] {cs.get('标题')} 数据点={cs.get('数据点')}")
        print(f"  结论: {lc.结论}\n")
    print(f"累计 tokens（含规划+取数+撰写）: {rc.tokens}")
