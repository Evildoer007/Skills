"""DataFetcher Provider共用错误与最小约定。"""

from __future__ import annotations


class ProviderError(RuntimeError):
    code = "provider_error"


class ProviderUnavailable(ProviderError):
    code = "provider_unavailable"


class ProviderUnauthorized(ProviderError):
    code = "unauthorized"


class ProviderQuotaExceeded(ProviderError):
    code = "quota_exceeded"


class ProviderNoData(ProviderError):
    code = "no_data"


class ProviderFieldPermissionDenied(ProviderError):
    code = "field_permission_denied"


class ProviderMarketPermissionDenied(ProviderError):
    code = "market_permission_denied"


class ProviderInputError(ProviderError):
    code = "provider_input_error"
