"""仅负责65个结构的专属指标，不重复计算公共统计。"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
from runtime.contracts.contract_types import semantic_hash

from .common_metrics import event_happened, monitor_values, number_summary, paired_monitor_values
from .metric_profile_map import MetricProfileSpec, metric_profile_for, required_profile_output_keys


_OPTIONAL_DIAGNOSTIC_REQUIREMENTS: dict[str, dict[str, Any]] = {
    "zero_return_regions": {
        "status": "unavailable",
        "reason_code": "zero_return_regions_not_exposed_by_shared_contract_core",
        "producer": "runtime.contracts",
        "required_facts": [
            "settlement_variable_names",
            "zero_return_roots_or_regions",
            "root_domain_conditions",
            "price_unit_and_normalization",
        ],
    },
    "cashflow_leg_decomposition": {
        "status": "unavailable",
        "reason_code": "cashflow_leg_roles_not_exposed_by_shared_contract_core",
        "producer": "runtime.contracts.evaluate_contract",
        "required_facts": [
            "cashflow_leg_id",
            "cashflow_economic_role",
            "cashflow_leg_gross_return",
        ],
    },
    "periodic_purchase_cashflows": {
        "status": "unavailable",
        "reason_code": "periodic_purchase_cashflows_not_exposed_by_shared_contract_core",
        "producer": "runtime.contracts.evaluate_contract",
        "required_facts": [
            "observation_date",
            "observation_price",
            "period_purchase_quantity",
            "period_cashflow_gross_return",
        ],
    },
    "synchronous_path_coverage": {
        "status": "unavailable",
        "reason_code": "synchronous_path_coverage_not_exposed_by_path_replay",
        "producer": "modules.backtester.path_replay",
        "required_facts": [
            "observation_count_by_asset",
            "common_observation_count",
            "alignment_policy",
            "dropped_session_count_by_asset",
        ],
    },
}


def profile_for_product(product_id: str) -> MetricProfileSpec:
    return metric_profile_for(product_id)


@lru_cache(maxsize=None)
def metric_profile_hash(profile_spec: MetricProfileSpec) -> str:
    """绑定专属指标定义、映射和公共统计实现，供执行指纹审计。"""
    source_hashes = {
        filename: sha256(Path(__file__).with_name(filename).read_bytes()).hexdigest()
        for filename in ("common_metrics.py", "metric_profile_map.py", "metric_profiles.py")
    }
    return semantic_hash({"profile": asdict(profile_spec), "source_hashes": source_hashes})


def specialized_metrics(
    profile_spec: MetricProfileSpec,
    trades: Sequence[Any],
    *,
    terms: Mapping[str, Any],
    event_summary: Mapping[str, Any],
    monitor_summary: Mapping[str, Any],
    outcome_summary: Sequence[Mapping[str, Any]],
    three_outcome_summary: Sequence[Mapping[str, Any]],
    conditional_summary: Mapping[str, Any],
) -> dict[str, Any]:
    """仅从逐笔账本和通用统计派生结构独有观察。"""
    terminal = np.asarray([trade.terminal_performance for trade in trades if trade.terminal_performance is not None], dtype=float)
    result: dict[str, Any] = {"profile_id": profile_spec.profile_id}
    if profile_spec.profile_id == "terminal_payoff":
        result.update({
            "terminal_performance": number_summary(terminal),
            "terminal_performance_sign": _terminal_performance_sign(terminal),
            "terminal_segments": list(outcome_summary),
            "selected_path_case_gross_return": _path_case_gross_returns(trades),
        })
    elif profile_spec.profile_id in {"dual_knock_autocall", "coupon_autocall"}:
        result["events"] = _select_events(
            event_summary,
            ("tau_in", "tau_out", "tau_out_1", "tau_out_2", "tau_reset", "tau_hedge"),
        )
        if "tau_in" in event_summary:
            result["three_outcome_summary"] = list(three_outcome_summary)
            result["conditional_summary"] = dict(conditional_summary)
        if profile_spec.profile_id == "coupon_autocall":
            result["coupon_observations"] = _select_monitors(monitor_summary, ("n_coupon",))
            result["coupon_payment"] = _coupon_payment(trades)
    elif profile_spec.profile_id in {"single_knock_out", "single_knock_out_autocall"}:
        result.update({
            "events": _select_events(event_summary, ("tau_out", "tau_out_1", "tau_out_2")),
            "trigger_vs_untriggered": _event_outcomes(trades, ("tau_out", "tau_out_1", "tau_out_2")),
        })
    elif profile_spec.profile_id == "single_knock_in":
        result.update({"events": _select_events(event_summary, ("tau_in",)), "knock_in_outcomes": _knock_in_outcomes(trades)})
    elif profile_spec.profile_id == "touch_binary":
        result.update({
            "events": _select_events(event_summary, ("tau_touch",)),
            "touch_vs_untouched": _event_outcomes(trades, ("tau_touch",)),
        })
    elif profile_spec.profile_id == "airbag":
        result.update({
            "events": _select_events(event_summary, ("tau_in",)),
            "buffer_outcomes": _buffer_outcomes(trades),
            "knock_in_outcomes": _knock_in_outcomes(trades),
            "selected_path_case_gross_return": _path_case_gross_returns(trades),
        })
    elif profile_spec.profile_id == "accumulator":
        result.update({
            "events": _select_events(event_summary, ("tau_out",)),
            "accumulated_quantity": _select_monitors(monitor_summary, ("Q_acc", "n_out")),
            "gross_return_per_accumulated_unit": _gross_return_per_accumulated_unit(trades),
            "knock_out_vs_full_term": _accumulator_outcomes(trades),
            "contract_purchase_price": _finite_term(terms, "K"),
            "quantity_multiplier": _finite_term(terms, "m"),
        })
    elif profile_spec.profile_id == "variance_swap":
        realized = monitor_values(trades, "sigma_realized")
        strike = _finite_term(terms, "Ksig")
        result.update({
            "realized_volatility": _select_monitors(monitor_summary, ("sigma_realized",)),
            "realized_variance": number_summary((realized / 100.0) ** 2),
            "realized_volatility_vs_strike": {
                "strike_volatility": strike,
                "spread": number_summary(realized - strike) if strike is not None else number_summary([]),
            },
            "volatility_buckets": _volatility_buckets(realized, strike),
            "variance_gross_return": _gross_return_summary(trades),
        })
    elif profile_spec.profile_id == "range_accrual":
        n_in, n_obs = paired_monitor_values(trades, "n_in", "n_obs_actual")
        ratio = n_in / n_obs if len(n_in) and np.all(n_obs > 0) else np.asarray([], dtype=float)
        result.update({
            "range_observations": _select_monitors(monitor_summary, ("n_in", "n_obs_actual")),
            "in_range_observation_ratio": number_summary(ratio),
            "range_accrual_gross_return": _gross_return_summary(trades),
        })
    elif profile_spec.profile_id == "shark_fin":
        result.update({
            "events": _select_events(event_summary, ("tau_out", "tau_out_1", "tau_out_2")),
            "trigger_vs_untriggered": _event_outcomes(trades, ("tau_out", "tau_out_1", "tau_out_2")),
            "terminal_performance": number_summary(terminal),
            "selected_path_case_gross_return": _path_case_gross_returns(trades),
        })
    if "S0Vec" in terms:
        result["multi_underlying_terminal"] = _multi_underlying_terminal(trades)
    optional_diagnostics = _optional_diagnostics(profile_spec.profile_id, terms)
    if optional_diagnostics:
        result["optional_diagnostics"] = optional_diagnostics
    gaps = _required_output_gaps(profile_spec.profile_id, result)
    result["metric_coverage"] = {
        "status": "partial" if gaps else "complete",
        "gaps": gaps,
    }
    return result


def _select_events(source: Mapping[str, Any], names: Sequence[str]) -> dict[str, Any]:
    return {name: source[name] for name in names if name in source}


def _select_monitors(source: Mapping[str, Any], names: Sequence[str]) -> dict[str, Any]:
    return {name: source[name] for name in names if name in source}


def _required_output_gaps(profile_id: str, result: Mapping[str, Any]) -> list[str]:
    """验证既有专属指标投影；不在覆盖层补算或猜测任何事实。"""
    gaps: list[str] = []
    for key in required_profile_output_keys(profile_id):
        if key not in result:
            gaps.append(f"missing_required_output:{key}")
            continue
        value = result[key]
        if isinstance(value, (Mapping, Sequence)) and not isinstance(value, (str, bytes)) and not value:
            gaps.append(f"empty_required_output:{key}")
    return gaps


def _terminal_performance_sign(values: np.ndarray) -> dict[str, Any]:
    total = len(values)
    return {
        "positive_count": int(np.sum(values > 0)),
        "flat_count": int(np.sum(np.isclose(values, 0.0))),
        "negative_count": int(np.sum(values < 0)),
        "positive_rate": float(np.mean(values > 0)) if total else None,
        "negative_rate": float(np.mean(values < 0)) if total else None,
    }


def _coupon_payment(trades: Sequence[Any]) -> dict[str, Any]:
    paid: list[float] = []
    scheduled: list[float] = []
    rates: list[float] = []
    unpaid: list[float] = []
    for trade in trades:
        count = trade.events.get("n_coupon")
        schedule = trade.historical_contract.resolved_schedules.get("O_c", {})
        dates = schedule.get("dates", ()) if isinstance(schedule, Mapping) else ()
        if not isinstance(count, (int, float, np.number)) or not np.isfinite(float(count)) or not dates:
            continue
        paid_count, scheduled_count = float(count), float(len(dates))
        paid.append(paid_count)
        scheduled.append(scheduled_count)
        rates.append(paid_count / scheduled_count)
        unpaid.append(max(0.0, scheduled_count - paid_count))
    return {
        "paid_observation_count": number_summary(paid),
        "scheduled_observation_count": number_summary(scheduled),
        "observation_hit_rate": number_summary(rates),
        "unpaid_observation_count": number_summary(unpaid),
    }


def _knock_in_outcomes(trades: Sequence[Any]) -> dict[str, Any]:
    knocked = [trade for trade in trades if event_happened(trade.events.get("tau_in"))]
    not_knocked = [trade for trade in trades if not event_happened(trade.events.get("tau_in"))]
    return {
        "knock_in_gross_return": _gross_return_summary(knocked),
        "not_knock_in_gross_return": _gross_return_summary(not_knocked),
        "knock_in_terminal_performance": number_summary([trade.terminal_performance for trade in knocked if trade.terminal_performance is not None]),
        "not_knock_in_terminal_performance": number_summary([trade.terminal_performance for trade in not_knocked if trade.terminal_performance is not None]),
    }


def _buffer_outcomes(trades: Sequence[Any]) -> dict[str, Any]:
    values = np.asarray([trade.terminal_performance for trade in trades if trade.terminal_performance is not None], dtype=float)
    return {
        "terminal_performance": number_summary(values),
        "non_negative_terminal_rate": float(np.mean(values >= 0)) if len(values) else None,
        "negative_terminal_rate": float(np.mean(values < 0)) if len(values) else None,
    }


def _gross_return_per_accumulated_unit(trades: Sequence[Any]) -> dict[str, Any]:
    values = [
        float(trade.pnl) / float(quantity) / 100.0
        for trade in trades
        if isinstance((quantity := trade.events.get("Q_acc")), (int, float, np.number)) and float(quantity) > 0
    ]
    return _return_summary(values)


def _accumulator_outcomes(trades: Sequence[Any]) -> dict[str, Any]:
    """按共享解释器的tau_out划分提前结束和完整期限的已观察结果。"""
    knocked_out = [trade for trade in trades if event_happened(trade.events.get("tau_out"))]
    full_term = [trade for trade in trades if not event_happened(trade.events.get("tau_out"))]
    total = len(trades)
    return {
        "knock_out_count": len(knocked_out),
        "full_term_count": len(full_term),
        "knock_out_rate": len(knocked_out) / total if total else None,
        "knock_out_accumulated_quantity": _monitor_summary(knocked_out, "Q_acc"),
        "full_term_accumulated_quantity": _monitor_summary(full_term, "Q_acc"),
        "knock_out_gross_return": _gross_return_summary(knocked_out),
        "full_term_gross_return": _gross_return_summary(full_term),
    }


def _monitor_summary(trades: Sequence[Any], name: str) -> dict[str, float | None]:
    return number_summary(monitor_values(trades, name))


def _finite_term(terms: Mapping[str, Any], key: str) -> float | None:
    value = terms.get(key)
    return float(value) if isinstance(value, (int, float, np.number)) and np.isfinite(float(value)) else None


def _volatility_buckets(values: np.ndarray, strike: float | None) -> dict[str, Any]:
    if strike is None or not len(values):
        return {"below_strike_count": 0, "at_or_above_strike_count": 0, "below_strike_rate": None}
    below = int(np.sum(values < strike))
    return {
        "below_strike_count": below,
        "at_or_above_strike_count": int(len(values) - below),
        "below_strike_rate": below / len(values),
    }


def _event_outcomes(trades: Sequence[Any], event_names: Sequence[str]) -> dict[str, Any]:
    triggered = [
        trade for trade in trades
        if any(event_happened(trade.events.get(name)) for name in event_names)
    ]
    triggered_ids = {id(trade) for trade in triggered}
    untriggered = [trade for trade in trades if id(trade) not in triggered_ids]
    total = len(trades)
    return {
        "triggered_count": len(triggered),
        "untriggered_count": total - len(triggered),
        "triggered_rate": len(triggered) / total if total else None,
        "triggered_gross_return": _gross_return_summary(triggered),
        "untriggered_gross_return": _gross_return_summary(untriggered),
        "triggered_terminal_performance": _terminal_performance_summary(triggered),
        "untriggered_terminal_performance": _terminal_performance_summary(untriggered),
    }


def _gross_return_summary(trades: Sequence[Any]) -> dict[str, Any]:
    return _return_summary([trade.gross_contract_return for trade in trades])


def _terminal_performance_summary(trades: Sequence[Any]) -> dict[str, float | None]:
    return number_summary([trade.terminal_performance for trade in trades if trade.terminal_performance is not None])


def _path_case_gross_returns(trades: Sequence[Any]) -> list[dict[str, Any]]:
    """只按共享解释器选中的path/case汇总，不反推条款情形。"""
    grouped: dict[tuple[int, int], list[Any]] = {}
    for trade in trades:
        grouped.setdefault((int(trade.path_id), int(trade.case_id)), []).append(trade)
    total = len(trades)
    return [
        {
            "code": f"path_{path_id + 1}_case_{case_id + 1}",
            "count": len(items),
            "rate": len(items) / total if total else None,
            "gross_return": _gross_return_summary(items),
        }
        for (path_id, case_id), items in sorted(grouped.items())
    ]


def _multi_underlying_terminal(trades: Sequence[Any]) -> dict[str, Any]:
    """多标的只描述逐笔实测终值表现，不声称覆盖或相关性估计。"""
    by_asset_count: dict[str, int] = {}
    worst: list[float] = []
    best: list[float] = []
    dispersion: list[float] = []
    observed = 0
    for trade in trades:
        performances = {
            str(asset): float(value)
            for asset, value in trade.underlying_performances.items()
            if isinstance(value, (int, float, np.number)) and np.isfinite(float(value))
        }
        if not performances:
            continue
        observed += 1
        worst_value = min(performances.values())
        best_value = max(performances.values())
        # 同值时按资产ID稳定选择，避免统计随dict插入顺序改变。
        worst_asset = min(asset for asset, value in performances.items() if np.isclose(value, worst_value))
        by_asset_count[worst_asset] = by_asset_count.get(worst_asset, 0) + 1
        worst.append(worst_value)
        best.append(best_value)
        dispersion.append(best_value - worst_value)
    return {
        "underlying_count": max((len(trade.underlying_performances) for trade in trades), default=0),
        "observed_trade_count": observed,
        "worst_of_terminal_performance": number_summary(worst),
        "best_of_terminal_performance": number_summary(best),
        "cross_underlying_dispersion": number_summary(dispersion),
        "worst_underlying_selection": {
            "by_asset_count": dict(sorted(by_asset_count.items())),
            "by_asset_rate": {
                asset: count / observed if observed else None
                for asset, count in sorted(by_asset_count.items())
            },
        },
    }


def _return_summary(values: Sequence[float]) -> dict[str, Any]:
    """结构专属收益只公开百分比口径；100基准仅留在内部账本。"""
    return {"percent": number_summary(values)}


def _optional_diagnostics(profile_id: str, terms: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    """声明非核心诊断所缺的最小上游事实，不从产品公式或字段顺序反推。"""

    names: list[str] = []
    if profile_id == "terminal_payoff":
        names.append("zero_return_regions")
    if profile_id in {"airbag", "shark_fin"}:
        names.append("cashflow_leg_decomposition")
    if profile_id == "accumulator":
        names.append("periodic_purchase_cashflows")
    if "S0Vec" in terms:
        names.append("synchronous_path_coverage")
    return {name: deepcopy(_OPTIONAL_DIAGNOSTIC_REQUIREMENTS[name]) for name in names}
